### 要約 / 背景

[Flowable 7.2.0](https://github.com/flowable/flowable-engine/releases/tag/flowable-7.2.0) のオープンソース版には公式UIが付属していません。そこで、実用的なフロントエンドインターフェースを迅速に得るために、AIプログラミングアシスタント（[Codex](https://developers.openai.com/codex)）を利用し、Flowableのソースコードを基に`gpt-5.3-codex`を使用して機能的な管理画面を生成することを試みました。本稿では、Codexの使用手順と、そこから得られたAI支援開発の経験について記録します。

> 注記：AIの使用場所は合肥のローカルPCであり、AIに提供したファイルはFlowableのソースコードのみです。

### Codexのインストール

#### 環境準備
- **オペレーティングシステム**：Windows 11（ローカル開発）
- **Node.js**：v20+（[公式サイト](https://nodejs.org/en/download)からダウンロード）
- **Codex**：codex-cli 0.160.0 （[公式サイト](https://developers.openai.com/codex/quickstart?setup=cli)からダウンロード）
- **VSCode プラグイン**：Codex（OpenAI API Keyと併用）

#### Node のインストール

Node.js公式サイトから最新バージョンのNode.jsをダウンロードします。[公式ダウンロードリンク](https://nodejs.org/en/download)

![[images/Pasted image 20260302092924.png]]

インストールが成功したか確認します。成功していればバージョン番号が表示されるはずです。

```Bash
node -v
```

![[Pasted image 20260302093725.png]]

#### Codex のインストール

ターミナルで以下を実行します。

```Bash
npm install -g @openai/codex
```

インストールが成功したか確認します。成功していればバージョン番号が表示されるはずです。

```Bash
codex --version
```
![[images/Pasted image 20260302093837.png]]

#### Codex の設定

Codexの設定ファイルの場所（存在しない場合は新規作成します）
- `C:\users\あなたのユーザー名\.codex\config.toml`
- `C:\users\あなたのユーザー名\.codex\auth.json`

内容は以下の通りです。

**config.toml**

```toml
model = "gpt-5.3-codex"
model_reasoning_effort = "xhigh"
disable_response_storage = true
model_verbosity = "high"
network_access = true
windows_wsl_setup_acknowledged = true
```


**auth.json**

```json
{ "OPENAI_API_KEY": "sk-xxxx" }
```

設定が成功したか確認します。ターミナルを開き、`codex` と入力してCodexを起動します。設定が成功していれば、直接対話を開始できます。

![[images/Pasted image 20260302102932.png]]

#### VS Code プラグインの使用

拡張機能ストアで「Codex」を検索し、クリックしてインストールします。

![[images/Pasted image 20260227144901.png]]

インストールが完了すると、左側にCodexプラグインのエントリが表示されます。2種類のログイン方法があり、私はAPIキーを使用しています。
![[Pasted image 20260302155107.png|500]]

次に、自分のAPIキーを入力するだけです。
![[Pasted image 20260302155229.png|500]]

ログイン完了後、VSCodeでCodexを使用できます
![[Pasted image 20260302145100.png|500]]

### AIを使用したコード生成のプロセス

終始、自然言語でCodexと対話しながら、段階的に使用可能なUIを生成させました。

まず、全体的な要件を提示します。

> **ユーザー**：_[[#codexとの対話断片一#ユーザー：| 「適切な場所に新しいフォルダを作成し、flowable7の機能を正常に使用できるUIインターフェースを書いてください……完成したUIインターフェースには、flowableの主要機能である admin、idm、modeler、task などを含めてください……」]]_

AIはソースコードを分析した後、React+TypeScript+Viteベースのフロントエンドプロジェクトの骨格を生成し、基本機能を実装しました。

> **AI**：_[[#codexとの対話断片一#codex：| 「リポジトリ内に、**React + TypeScript + Vite + bpmn-js**を使用した、実行可能な Flowable 7 フロントエンドワークベンチを完成させました。お客様が要求された `admin / idm / modeler / task / console` の主要機能をカバーしています……」]]_

その後、IDM（アイデンティティ管理）モジュールに対して、より詳細な修正要件（テナントIDの削除、フィールドバリデーション、グループ管理、権限制御など）を提示しましたが、AIはFlowable REST APIに基づいてコードを適切に調整しました。以下は、典型的な反復対話の一例です。

> **ユーザー**：_[[#codexとの対話断片二#ユーザー：|「ここであなたにいくつかの要求を出します。まずrest apiに対応するインターフェースが提供されているかどうかを注意深く確認し、その後あなたが生成したフロントエンドコードを修正してください。まずIDM関連のページを修正する必要があります……」]]_
> **AI**：_[[#codexとの対話断片二#codex：|「お客様の要求に従い、まず `flowable-rest` インターフェースを確認し、その上でIDMページの調整を完了しました。また、実際の使用に影響を与える可能性のあるいくつかのインタラクションの問題も修正しました……」]]_

このような「要求-フィードバック」のサイクルを繰り返すことで、AIに段階的に期待するフロントエンドUIを構築させていきました。

### 経験のまとめ

1. [[#要件を明確にし、段階的に生成する]]
2. [[#アーキテクチャ設計を優先し、AIは詳細を実装する]]
3. [[#AIの検索能力を活用する]]
4. [[#サンプルを提供し、コミュニケーションコストを下げる]]
5. [[#Gitでバージョン管理を行う]]
6. [[#その他]]

#### 要件を明確にし、段階的に生成する

要件の記述は可能な限り詳細かつ正確に行うべきです。実践の中で、プロジェクト全体の生成要求を一度にAIに出すと、コンテキストが失われたりコード構造が混乱したりしやすいことがわかりました。そのため、要件を複数の独立したモジュール（Admin、IDM、Modelerなど）に分割し、各モジュールをさらにいくつかのサブタスク（例：「まずユーザーリストを実装し、その後グループ管理を追加する」）に分解し、段階的に検証と最適化を繰り返しました。IDMページを例にとると、6つの具体的な要求（テナントIDの削除、フィールドバリデーション、グループ管理など）を順次提示しましたが、AIは毎回正確に応答し、段階的な誘導の有効性を示しました。

#### アーキテクチャ設計を優先し、AIは詳細を実装する

AIにはグローバルなアーキテクチャの視野が欠けており、完全なコードを直接生成させると、結合度が高すぎる実装になりがちです。良い方法は、まず人間がプロジェクト構造、インターフェース契約、データモデルを設計し、その後にAIに既定のフレームワーク内で具体的な機能を実装させるというものです。例えば、当初はadmin、idm、modeler、taskなどの機能を分けることだけを要求し、分離方法を明確に指定しませんでした。その結果、AIはデフォルトで「シングルページのタブ状態切り替え」というレイアウトを生成しました。そこで「ルーティング化」を明確に要求したところ、AIは迅速に各モジュールを独立したルーティングに調整し、全体的なアーキテクチャの一貫性を保ちました。

#### AIの検索能力を活用する

AIのオンライン検索能力を最大限に活用し、成熟したソリューションを推薦させます。DMNエディタが必要になった際、AIは最初に簡素なインターフェースを自己生成しましたが、その出来は芳しくありませんでした。そこでAIに「オンラインで比較的成熟したツールパッケージがないか探してみてください。現在のものはあまりに簡素すぎます。あるいはflowable6 UIのフロントエンドを参考に再設計しても構いません」と指示しました。AIはすぐに[`dmn-js`](https://github.com/bpmn-io/dmn-js)（プロフェッショナルなDMN編集ライブラリ）を見つけ出し、統合後のインターフェースの機能と操作性は大幅に向上しました。これは、AIに検証済みのオープンソースツールを探させる方が、ゼロから生成させるよりも信頼性が高い場合が多いことを示しています。

#### サンプルを提供し、コミュニケーションコストを下げる

テキストだけの説明では、期待する成果を正確に伝えきれないことがあります。要件に参考画像やサンプルコードを添付することで、AIの生成結果の適合度が著しく向上することがわかりました。例えば、テキストによる説明とFlowableの機能紹介だけでは、AIが生成するインターフェースは期待から乖離していました。しかし、Flowable 6の公式UIのコード断片を参照として提供した後、AIはそのデザインパターンを正確に分析し、Flowable 7のREST APIに基づいて、スタイルが類似し機能が充実したフロントエンドページを生成することができ、その後の調整回数は大幅に減少しました。

#### Gitでバージョン管理を行う

AIによる修正が常に正しいとは限らず、時には正常なコードを誤って削除したり、新しいエラーを混入させたりすることがあります。そのため、毎回のコミット前にGitで変更を記録し、問題が発生した場合に迅速にロールバックできるようにしました。例えば、ある権限制御機能の修正中に、AIが誤ってAPIベースパスを書き換え、他のページにアクセスできなくなる事態が発生しました。正常な前のバージョンにロールバックし、AIに再修正を指示することで、重複する作業やデバッグ時間を回避できました。この習慣は、開発プロセス全体を通じて何度もリスクを回避し、プロジェクトの安定性を保証するのに役立ちました。

#### その他

- **MCPとSkillsの活用**：ブラウザを操作できるSkillsを組み合わせて使用しようとしています。例えば、[microsoft/playwright-cli](https://github.com/microsoft/playwright-cli)などです。より適切なMCPツールやSkillsが揃えば、生成される効果はさらに向上するでしょう。

- **忍耐強く、反復的に最適化する**：AIが生成する内容は何度かの修正を必要としますが、全体的な効率は手動コーディングよりもはるかに高いと言えます。


### 付録

以下は、codexとの対話記録の一部です。

#### codexとの対話断片一
##### ユーザー：
> 你可以看到在这个项目中缺少一个前端页面。请你在合适的地方新建一个文件夹，写一个能够正常使用flowable7功能的ui界面，使用的语言要是近期活跃的，不要使用已经不再更新的语言。完成的ui界面要有flowable中最主要的功能：admin，idm，modeler，task等。你可以先从网上找到flowable6.8.1的ui进行借鉴然后再一步一步创建自己ui。最后呈现的结果要能做到：管理用户，创建、发布BPMN，能够发起流程，相应的可以处理流程中的task，还要有控制台能够实时观察任何状态信息。

##### codex：
> 已在仓库里完成一个可运行的 Flowable 7 前端工作台，使用的是 **React + TypeScript + Vite + bpmn-js**（活跃技术栈），并覆盖你要求的 `admin / idm / modeler / task / console` 主功能。
>
> **新增目录**
> - `ui/flowable7-ui`
>
> **核心实现文件**
> - `ui/flowable7-ui/src/App.tsx`
> - `ui/flowable7-ui/src/lib/api.ts`
> - `ui/flowable7-ui/src/pages/AdminPage.tsx`
> - `ui/flowable7-ui/src/pages/IdmPage.tsx`
> - `ui/flowable7-ui/src/pages/ModelerPage.tsx`
> - `ui/flowable7-ui/src/pages/TaskPage.tsx`
> - `ui/flowable7-ui/src/pages/ConsolePage.tsx`
> - `ui/flowable7-ui/src/styles.css`
> - `ui/flowable7-ui/README.md`
>
> **你要求的能力对应情况**
> 1. 管理用户
> - 已实现 `IDM` 页面，支持用户查询、新增、编辑、删除。
> - 对接接口：`/identity/users`。
>
> 1. 创建、发布 BPMN
> - 已实现 `Modeler` 页面，内置 `bpmn-js` 画布，可新建 BPMN、导入/导出 XML。
> - 支持发布到流程引擎（deployment）。
> - 对接接口：`/repository/deployments`、`/repository/models`、`/repository/models/{id}/source`。
>
> 1. 发起流程
> - 已实现 `Task` 页面发起流程实例。
> - 对接接口：`/runtime/process-instances`。
>
> 1. 处理流程任务
> - 已实现任务列表、选择任务、`claim`、`complete`。
> - 对接接口：`/runtime/tasks`、`/runtime/tasks/{id}`。
>
> 1. 控制台实时观察状态
> - 已实现 `Console` 页面，支持自动轮询与周期配置。
> - 监控流程实例、任务、作业、死信作业、定时作业、挂起作业，并显示 HTTP/UI 实时日志流。
> - 对接接口：`/runtime/process-instances`、`/runtime/tasks`、`/management/jobs`、`/management/deadletter-jobs`、`/management/timer-jobs`、`/management/suspended-jobs`。
>
> 1. Admin 主功能
> - 已实现引擎概览、流程定义管理（启用/挂起）、部署列表（级联删除）。
> - 对接接口：`/management/engine`、`/repository/process-definitions`、`/repository/deployments`。
>
> **构建验证**
> - 我已经在该目录执行过：
> - `npm install`
> - `npm run build`
> - 构建通过（有一个 chunk size 提示，属于 `bpmn-js` 体积导致的常见警告，不影响运行）。
>
> **如何启动**
> 1. `cd ui/flowable7-ui`
> 2. `npm install`
> 3. `npm run dev`
> 4. 打开 `http://localhost:5173`
>
> 默认 API Base 已设为 `/flowable-rest/service`，开发代理在 `ui/flowable7-ui/vite.config.ts`，默认转发到 `http://localhost:8080`。可在页面顶栏直接改 API 地址和账号密码。
>
> **关于你提到“参考 flowable6.8.1 UI”**
> - 我按 Flowable 6.x 的 `Admin/IDM/Modeler/Task` 功能分区重建了页面组织和操作流，但底层改成直接调用你这个 Flowable 7 仓库里的 REST 接口。
> - 根据公开资料可得（这是基于资料的推断）：Flowable 7 已不再提供旧版开源 UI 应用，因此采用“自建前端 + 官方 REST API”是当前可持续方案。
>
> 参考链接：
> - https://github.com/flowable/flowable-engine/releases
> - https://forum.flowable.org/t/flowable-ui-7-1-0-version-alternative/12226
> - https://forum.flowable.org/t/flowable-ui-app-maven-repository-does-not-have-7-0-0-support/10880
> - https://repo.maven.apache.org/maven2/org/flowable/flowable-spring-boot-starter-ui-admin/6.8.1/
>
> 如果你愿意，我下一步可以继续做两件事：
> 1. 把这个前端接入你当前 Java 工程的静态资源打包流程（打成同一个可部署包）。
> 2. 给 `Modeler` 加 BPMN 属性面板与校验规则（比如 task assignee、候选组、表单 key 的可视化配置）。
>

#### codexとの対話断片二
##### ユーザー：
> 现在我给你提出以下要求，你需要先仔细查看rest api中是否提供了对应的接口，然后修改你生成的前端代码。
> 你需要先对IDM相关的页面进行修改。
> 1. 删除无用字段 Tenant ID
> 2. Display Name 不应该由用户编辑，他应该自动根据 First Name 和 Last Name 生成
> 3. 设置 User ID，Name, Email，Password 为必填字段，若未填写不允许添加用户。
> 4. 查询时支持模糊搜索
> 5. 在该页面提供组的管理，要基本含有以下功能
> 	- 创建组（id，名称）
> 	- 修改（名称）
> 	- 删除
> 	- 一览（组名称）
> 	- 组成员一览
> 		- 过滤
> 		- 添加组成员
> 		- 删除组成员
> 6. 在该页面提供权限控制的管理，要基本含有以下功能
> 	- 访问idm应用
> 		- 用户
> 			- 一览（id，邮箱，名称）
> 			- 添加
> 			- 删除
> 		- 组
> 			- 一览（id，名称）
> 			- 添加
> 			- 删除
> 	- 访问console应用，功能同上
> 	- 访问modeler应用，功能同上
> 	- 访问Task应用，功能同上
> 	- 访问rest api，功能同上


##### codex：
> 已按你的要求先核对 `flowable-rest` 接口，再完成 IDM 页面调整，并修复了一些实际会影响使用的交互问题。
>
> **REST API 核对结果**
> - 用户查询/创建接口存在：`/identity/users`
>   参考 `modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/UserCollectionResource.java:98`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/UserCollectionResource.java:149`
> - 用户支持按组查询 `memberOfGroup`：
>   `modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/UserCollectionResource.java:87`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/UserCollectionResource.java:129`
> - 用户模糊查询参数存在（`firstNameLike/displayNameLike` 等）：
>   `modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/UserCollectionResource.java:83`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/UserCollectionResource.java:85`
> - 组查询/创建接口存在：`/identity/groups`，且支持 `nameLike`
>   `modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/GroupCollectionResource.java:89`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/GroupCollectionResource.java:121`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/GroupCollectionResource.java:78`
> - 组成员增删接口存在：
>   `modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/GroupMembershipCollectionResource.java:47`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/identity/GroupMembershipResource.java:43`
> - 引擎属性接口存在（用于保存 ACL 配置）：
>   `modules/flowable-rest/src/main/java/org/flowable/rest/service/api/management/EnginePropertiesResource.java:66`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/management/EnginePropertiesResource.java:102`、`modules/flowable-rest/src/main/java/org/flowable/rest/service/api/management/EnginePropertiesResource.java:128`
>
> **已完成的 IDM 前端调整**
> - 用户管理
>   - 删除 Tenant ID 输入（页面上已无该字段）。
>   - Display Name 改为只读自动生成（由 First Name + Last Name 计算）。
>     见 `ui/flowable7-ui/src/pages/IdmPage.tsx:482`、`ui/flowable7-ui/src/pages/IdmPage.tsx:512`
>   - User ID / Name(First+Last) / Email / Password（创建时）做必填校验，并在按钮层面禁用提交。
>     见 `ui/flowable7-ui/src/pages/IdmPage.tsx:144`、`ui/flowable7-ui/src/pages/IdmPage.tsx:311`、`ui/flowable7-ui/src/pages/IdmPage.tsx:539`
>   - 模糊搜索已支持（用户、组、组成员过滤）。
>     见 `ui/flowable7-ui/src/pages/IdmPage.tsx:177`、`ui/flowable7-ui/src/pages/IdmPage.tsx:186`、`ui/flowable7-ui/src/pages/IdmPage.tsx:192`
> - 组管理
>   - 创建（id/name）、修改（name）、删除、列表已实现。
>     见 `ui/flowable7-ui/src/pages/IdmPage.tsx:344`、`ui/flowable7-ui/src/pages/IdmPage.tsx:611`
>   - 组成员列表/过滤/添加/删除已实现。
>     见 `ui/flowable7-ui/src/pages/IdmPage.tsx:402`、`ui/flowable7-ui/src/pages/IdmPage.tsx:421`、`ui/flowable7-ui/src/pages/IdmPage.tsx:670`
> - 权限控制（应用访问）
>   - IDM / Console / Modeler / Task / REST API 的 用户/组 授权列表、添加、删除均已实现。
>     见 `ui/flowable7-ui/src/pages/IdmPage.tsx:720`、`ui/flowable7-ui/src/pages/IdmPage.tsx:434`、`ui/flowable7-ui/src/pages/IdmPage.tsx:467`
>   - 配置通过引擎属性 `flowable7.ui.app-access.acl` 持久化（创建/更新兼容处理）。
>     见 `ui/flowable7-ui/src/pages/IdmPage.tsx:27`、`ui/flowable7-ui/src/pages/IdmPage.tsx:278`
> - API 层补齐
>   - 新增 group CRUD、group member 增删、engine property 读写方法。
>     见 `ui/flowable7-ui/src/lib/api.ts:49`、`ui/flowable7-ui/src/lib/api.ts:53`、`ui/flowable7-ui/src/lib/api.ts:58`
>   - 新增类型 `GroupItem`、`PermissionAppKey`、`AppAccessAcl`。
>     见 `ui/flowable7-ui/src/lib/types.ts:44`、`ui/flowable7-ui/src/lib/types.ts:50`、`ui/flowable7-ui/src/lib/types.ts:52`
> - 样式补齐
>   - 增加权限卡片布局相关样式，避免权限区 UI 堆叠混乱。
>     见 `ui/flowable7-ui/src/styles.css:471`、`ui/flowable7-ui/src/styles.css:488`、`ui/flowable7-ui/src/styles.css:495`
>
> **额外修复**
> - 修复了创建用户时密码处理的细节问题（避免空格密码覆盖）。
> - 补了 ACL 增删失败的异常提示和 UI 日志，避免“点击后无反馈”。
>
> **验证结果**
> - 已执行构建：`npm run build`（目录 `ui/flowable7-ui`）
> - 结果：通过（仅有 Vite 大包体积 warning，无编译错误）。
>
> **说明**
> - Flowable REST 本身没有“应用访问授权（idm/console/modeler/task/rest-api）”的专用管理接口，所以这部分采用 `engine-properties` 持久化配置实现。如果你下一步要“真正拦截页面/接口访问”，还需要在前端路由和后端鉴权层接入这份 ACL。
>
> 如果你要，我下一步可以直接把这份 ACL 接到 `App.tsx` 的 tab 可见性和页面访问拦截上（按当前登录用户及其组实时判断）。