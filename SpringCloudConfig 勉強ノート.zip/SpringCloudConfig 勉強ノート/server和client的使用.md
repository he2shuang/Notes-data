# 远程准备

在远程仓库`https://gitee.com/muo-yan/spring_cloud_config_repo.git`中有如下两个文件作为配置文件：`test_config.yml`、`test_config-dev.yml`。

`test_config.yml`
```
server:
  port: 9000
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka
my:
  args:
    i: 10
    str: '测试字符串'
spring:
  application:
    name: first-config-client
```

`test_config-dev.yml`
```
server:
  port: 9001
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka
my:
  args:
    i: 20
    str: '测试字符串222'
spring:
  application:
    name: first-config-client-dev
```

# 设置Server

`pom`文件中引入所需的依赖

```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-config-server</artifactId>  
</dependency>
```

如果运行时出现问题，则需要在父项目中有如下设置

```xml
<dependencyManagement>  
    <dependencies>        <dependency>            <groupId>org.springframework.cloud</groupId>  
            <artifactId>spring-cloud-dependencies</artifactId>  
            <version>${spring-cloud.version}</version>  
            <type>pom</type>  
            <scope>import</scope>  
        </dependency>        <dependency>            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-starter-web</artifactId>  
            <version>3.2.7</version>  
        </dependency>        <dependency>            <groupId>org.slf4j</groupId>  
            <artifactId>slf4j-api</artifactId>  
            <version>2.0.17</version>  
        </dependency>        <dependency>            <groupId>org.slf4j</groupId>  
            <artifactId>slf4j-log4j12</artifactId>  
            <version>2.0.7</version>  
        </dependency>    </dependencies></dependencyManagement>  
  
<build>  
    <plugins>        <plugin>            <groupId>org.springframework.boot</groupId>  
            <artifactId>spring-boot-maven-plugin</artifactId>  
        </plugin>    </plugins></build>

```

`pom`文件设置好以后，可以定义主函数，这里需要使用`@EnableConfigServer`。

```java
@SpringBootApplication  
@EnableConfigServer
public class CloudConfigServerApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(CloudConfigServerApplication.class, args);  
    }  
}
```

SpringCloudConfig Server 需要在`resources/application.yml`文件中设置远程仓库的uri

```yml
server:  
  port: 8888  
spring:  
  application:  
    name: first-config-server  
  cloud:  
    config:  
      server:  
        git:  
          uri: https://gitee.com/muo-yan/spring_cloud_config_repo.git
```


运行项目之后，可以访问地址`localhost:8888/test_config/deault/master`来测试 Server 是否搭建成功，成功时的返回值应该如下图所示

![[Pasted image 20251113131502.png]]

其中HTTP服务有以下形式的资源：
```
/{application}/{profile}[/{label}]
/{application}-{profile}.yml
/{label}/{application}-{profile}.yml
/{application}-{profile}.properties
/{label}/{application}-{profile}.properties
```

![[Pasted image 20251113132108.png]]
![[Pasted image 20251113132136.png]]
# 设置Client

`pom`文件中引入所需的依赖

```xml
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-config</artifactId>  
</dependency>  
<dependency>  
    <groupId>org.springframework.cloud</groupId>  
    <artifactId>spring-cloud-starter-bootstrap</artifactId>  
</dependency>  
<dependency>  
    <groupId>org.springframework.boot</groupId>  
    <artifactId>spring-boot-starter-web</artifactId>  
    <version>3.2.7</version>  
</dependency>
```

`pom`文件设置好以后，可以定义主函数。

```java
@SpringBootApplication  
public class CloudConfigClientApplication {  
    public static void main(String[] args) {  
        SpringApplication.run(CloudConfigClientApplication.class, args);  
    }  
}
```

SpringCloudConfig Client 可以在`resources/bootstrap.yml`文件中设置 Server 的uri
```yml
spring:  
  cloud:  
    config:  
#      import: "configserver:http://localhost:8888"  
      uri: http://localhost:8888  
      name: test_config  
      label: master  
      profile: dev  
  application:  
    name: first-config-client-local  
  
  
  autoconfigure:  
    exclude:  
      - org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration  
      - org.springframework.boot.autoconfigure.task.TaskSchedulingAutoConfiguration
```

要想测试远程仓库中的配置有没有用到在这个Client上，可以设置一个controller
```java
@RestController  
public class MyController {  
    @Value("${my.args.i:99}")  
    private int i;  
    @Value("${my.args.str:derault-str}")  
    private String str;  
    @Value("${spring.application.name}")  
    private String name;  
  
    @RequestMapping("/test")  
    public String test() {  
        return "test，i=" + i + ", str=" + str + ", name=" + name;  
    }  
}
```

设置完成之后，启动 Server 和 Client 项目，然后访问端口`http://localhost:9001/test` 进行测试。正常情况下应该会有类似下图的返回结果。这就说明远端的配置文件成功在Client中应用了。

![[Pasted image 20251113133141.png]]

