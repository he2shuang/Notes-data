对于 Spring Cloud Bus，最常用且对初学者最友好的选择是 **RabbitMQ**。它比 Kafka 更轻量，安装和配置也更简单，非常适合本地开发和学习。

下面我将为你提供一个从零开始，在本地安装 RabbitMQ 并集成到 Spring Cloud 项目中以实现全局热刷新的完整步骤。

---

### 第一步：安装 RabbitMQ


#### 使用 Docker 安装 (强烈推荐)

如果你还没有安装 Docker，请先去 Docker 官网下载并安装 [Docker Desktop](https://www.docker.com/products/docker-desktop/)。

1.  **拉取并运行 RabbitMQ 容器**：
    打开你的命令行工具（终端、PowerShell 或 CMD），然后复制并运行下面这行命令：

    ```bash
    docker run -d --name my-rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3-management
    ```

2.  **命令解释**：
    *   `docker run -d`: 在后台（detached mode）运行容器。
    *   `--name my-rabbitmq`:给容器取一个名字，方便管理。
    *   `-p 5672:5672`: 将本机的 `5672` 端口映射到容器的 `5672` 端口。这是 RabbitMQ 用来进行消息通信的 AMQP 协议端口。
    *   `-p 15672:15672`: 将本机的 `15672` 端口映射到容器的 `15672` 端口。这是 RabbitMQ 的**管理后台 UI** 端口。
    *   `rabbitmq:3-management`: 使用带有管理插件的官方 RabbitMQ 镜像。

3.  **验证安装**：
    *   等待命令执行完毕（大概一分钟左右）。
    *   打开浏览器，访问 `http://localhost:15672`。
    *   你应该能看到 RabbitMQ 的登录界面。
    *   使用默认的用户名和密码登录：
        *   **用户名**: `guest`
        *   **密码**: `guest`
    *   如果能成功登录并看到管理后台，说明 RabbitMQ 已经安装并成功运行了！



### 第二步：在 Spring Cloud 项目中集成 RabbitMQ

现在 RabbitMQ 已经跑起来了，你需要让你的微服务（Config Server 和所有 Client）知道它的存在。

1.  **添加 Maven 依赖**：
    在你**所有**需要参与热刷新的微服务模块的 `pom.xml` 文件中（包括 `config-server` 和 `config-client`），添加 Spring Cloud Bus AMQP (RabbitMQ) 的依赖：

    ```xml
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-bus-amqp</artifactId>
    </dependency>
    ```

2.  **添加 Actuator 依赖**：
    确保所有模块的 `pom.xml` 中都有 Actuator 依赖，因为 `/bus-refresh` 端点是它提供的。
    ```xml
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>
    ```

3.  **配置连接信息**：
    在你**所有**微服务模块的 `application.yml` (或 `bootstrap.yml`) 文件中，添加 RabbitMQ 的连接配置。

    ```yaml
    spring:
      rabbitmq:
        host: localhost
        port: 5672
        username: guest
        password: guest
    ```
    (因为你是在本地用默认用户，所以就是这个配置。)

4.  **暴露 `bus-refresh` 端点**：
    在你**所有**微服务模块的 `application.yml` 中，确保 Actuator 的端点是暴露的。

    ```yaml
    management:
      endpoints:
        web:
          exposure:
            include: '*' # 为了方便，可以先暴露所有端点，* 包括了 bus-refresh
    ```

---

### 第三步：执行并验证全局热刷新

现在万事俱备，可以开始验证了。

1.  **启动所有服务**：
    *   启动你的 Config Server。
    *   启动你的 Config Client (可以启动多个实例来更好地观察效果)。

2.  **初始状态验证**：
    访问客户端的 `/test` 接口（例如 `http://localhost:9000/test`），确认它返回的是当前 Git 仓库中的配置值。

3.  **修改配置**：
    去你的 Gitee 仓库，修改 `test_config.yml` 文件中的 `my.args.str` 的值，比如改成 "全局刷新成功了!"。然后 **Commit & Push**。

4.  **触发全局刷新**：
    打开一个新的命令行工具，向**任意一个**微服务实例发送 `/bus-refresh` POST 请求。可以是 Config Server，也可以是任何一个 Client。
    例如，如果你的 Config Server 运行在 8888 端口：

    ```bash
    curl -X POST http://localhost:8888/actuator/bus-refresh
    ```
    或者向你的客户端（假设运行在9000端口）发送：
    ```bash
    curl -X POST http://localhost:9000/actuator/bus-refresh
    ```
    你只需要**调用一次**！

5.  **观察日志**：
    *   你会看到你发送请求的那个服务的日志有响应。
    *   **关键是**，立即去看**其他**服务实例的日志，你会看到类似 `Received remote refresh request` 的日志信息。这说明它们通过 RabbitMQ 收到了刷新指令。
    *   接着，你会看到它们去 Config Server 拉取新配置的日志。

6.  **最终验证**：
    再次访问客户端的 `/test` 接口 (`http://localhost:9000/test`)。你会发现，页面返回的内容已经变成了 **"全局刷新成功了!"**，并且你根本没有重启过任何服务！

至此，你就成功地在本地搭建并实现了一整套 Spring Cloud Config 的全局热刷新机制。