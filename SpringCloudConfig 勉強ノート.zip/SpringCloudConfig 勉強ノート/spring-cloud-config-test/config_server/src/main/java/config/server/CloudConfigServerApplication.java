package config.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * EnableConfigServer - 开启SpringCloud中的Config服务器。自动提供Config服务器相关的所有功能。
 * 启动时，同步启动 Tomcat，默认端口8080。
 * 一般配置中心服务器端口定义为：8888。因为Config客户端默认查找的Config服务器的地址就是：
 * http://localhost:8888
 *  Config Server 的功能是，处理ConfigClient的请求，并访问Git，实现配置文件的查询。Pull后，
 *  在本地缓存，并将下载的配置发送给Config Client
 *
 *
 */

@SpringBootApplication
@EnableConfigServer
public class CloudConfigServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(CloudConfigServerApplication.class, args);
    }
}
