package config.client.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
    @Value("${my.args.i:99}")
    private int i;
    @Value("${my.args.str:derault-str}")
    private String str;
    @Value("${spring.application.name}")
    private String name;

    @RequestMapping("/test")
    public String test() {
        return "test，i=" + i + ", str=" + str + ", name=" + name;
    }
}
