
**配置 Checkpoint 和端到端的 Exactly-Once 语义**。这是 Flink 最强大的特性之一，也是生产环境的关键保障。通过Checkpoint和Kafka的事务机制，共同保障端到端的Exactly-Once语义。

在发生故障并恢复后，**每条输入消息恰好被处理一次**，即：
- **没有丢失**：所有已发送到 `input-topic` 的消息最终都会出现在 `output-topic`。
- **没有重复**：`output-topic` 中不会出现相同内容的重复消息（除了业务上允许的重复内容，但应该每条只出现一次）。

| **Checkpoint管理Offset** | Flink将Kafka消费的offset作为算子状态的一部分，持久化到Checkpoint中，而非依赖Kafka自动提交。                              |
| :--------------------- | :----------------------------------------------------------------------------------------- |
| **Producer幂等性**        | Kafka Producer的幂等性通过为消息分配唯一序列号，确保同一消息在分区内不会重复写入                                            |
| **Kafka事务与2PC**        | Flink在Checkpoint时开启Kafka事务，将数据写入未提交的事务中。Checkpoint成功后，通过两阶段提交（2PC）提交事务，实现端到端的Exactly-Once。 |



### 1. 修改代码，启用 Checkpoint 并配置 Exactly-Once

更新 `KafkaToKafkaJob.java`，在创建 `StreamExecutionEnvironment` 之后添加以下配置：


```
// 启用 Checkpoint，间隔 5 秒
env.enableCheckpointing(5000);
// 设置 Checkpoint 模式为 EXACTLY_ONCE
env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
// 设置两次 Checkpoint 之间的最小间隔（避免过密）
env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
// 设置 Checkpoint 超时时间 60 秒
env.getCheckpointConfig().setCheckpointTimeout(60000);
// 同一时间只允许一个 Checkpoint
env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
```

同时，修改 Kafka Sink 的投递保证为 `EXACTLY_ONCE`，并启用事务。在 Flink Sink 中设置合适的事务超时。

```
Properties kafkaProps = new Properties();
kafkaProps.setProperty("transaction.timeout.ms", "900000"); // 15分钟

KafkaSink<String> sink = KafkaSink.<String>builder()
        .setBootstrapServers(bootstrapServers)
        .setRecordSerializer(KafkaRecordSerializationSchema.builder()
                .setTopic(outputTopic)
                .setValueSerializationSchema(new SimpleStringSchema())
                .build()
        )
		// 设置 EXACTLY_ONCE 语义
        .setDeliveryGuarantee(DeliveryGuarantee.EXACTLY_ONCE)
        .setKafkaProducerConfig(kafkaProps) 
        .build();
```

Flink Kafka Sink 默认的事务超时时间是 **1小时（3600000 ms）**，而你的 Kafka broker 配置的 `transaction.max.timeout.ms` 默认是 **15分钟（900000 ms）**，因此必须在这里修改事务超时时间。

在构建 `KafkaSink` 时，通过 `setKafkaProducerConfig` 传递 `transaction.timeout.ms` 属性，使其小于 broker 的限制（如 15 分钟）。


在IDE中不方便模拟**持久化 Checkpoint**，在本地，我们可以用 Docker Compose 搭建一个包含 MinIO（模拟 S3 分布式存储）和 ZooKeeper 的 Flink 高可用集群，整个架构如下图所示，通过它你可以完整地验证 JobManager 的高可用切换和 Exactly-Once 语义：


```mermaid
flowchart TD
    Client[Client] -->|提交作业| FlinkHA[Flink HA 集群]
    FlinkHA -->|主 JobManager 故障时| ZK[ZooKeeper]
    ZK -->|通知并选举| FlinkHA
    
    subgraph MinIO
        direction LR
        S1[存储桶]
    end
    
    FlinkHA -->|读写元数据/状态/HA数据| MinIO
    FlinkHA -->|读写 Checkpoint| MinIO
```

启动 MinIO 后，访问 `http://localhost:9001` 并用 `minioadmin/minioadmin` 登录，创建一个名为 `flink` 的存储桶。后续 Flink 的 Checkpoint 和 HA 元数据都会存入这个桶中。

将你的作业代码打包成 JAR 包。由于集群是容器化的，最简单的办法是把 JAR 包复制到 JobManager 容器里再提交。


```bash
mvn clean package    
# 假设你的 JAR 包名为 flink-kafka-demo-1.0-SNAPSHOT.jar
docker cp target/flink-kafka-demo-1.0-SNAPSHOT.jar jobmanager1:/tmp/
# 进入 jobmanager1 容器
docker exec -it jobmanager1 bash
# 提交作业
./bin/flink run -d /tmp/flink-kafka-demo-1.0-SNAPSHOT.jar
```

### 2. 观察与验证

- **检查 MinIO 存储**：访问 `http://localhost:9001`，在 `flink` 存储桶下，你应该能看到 `checkpoints` 和 `ha` 目录，其中存放了作业的 Checkpoint 和 HA 元数据。

- **验证 Exactly-Once**：

##### 1. 发送第一批消息并等待 Checkpoint
向 `input-topic` 发送 **带序号** 的消息，例如：
```
msg-1
msg-2
msg-3
```
等待至少一次 Checkpoint 完成（通过 Flink Web UI 的 `Checkpoints` 标签页观察，看到 `Completed` 计数增加）。这确保 Flink 已经将这三条消息的消费偏移量和处理状态持久化到 MinIO。

##### 2. 触发故障（TaskManager 宕机）
执行以下命令停止 TaskManager 容器：
```bash
docker stop taskmanager
```

##### 3. 在故障期间继续发送消息
向 `input-topic` 再发送三条消息：
```
msg-4
msg-5
msg-6
```
此时 Flink 作业无法消费这些消息，它们会积压在 Kafka 中。

##### 4. 恢复 TaskManager
重新启动 TaskManager：
```bash
docker start taskmanager
```
Flink 会自动检测到 TaskManager 重新加入，并从最近一次成功的 Checkpoint（包含 msg-1,2,3 的偏移量）恢复任务。恢复后，它会继续消费积压的 msg-4,5,6。

##### 5. 观察最终输出
检查 `output-topic` 中的消息。看到恰好 **6 条消息**，内容为大写的：
```
MSG-1
MSG-2
MSG-3
MSG-4
MSG-5
MSG-6
```
**没有重复**，**没有遗漏**。
![[Pasted image 20260407145532.png]]

![[Pasted image 20260407145608.png]]

## 原理回顾

- **Flink Checkpoint** 记录了 Kafka 的消费偏移量。只要 Checkpoint 完成，恢复时就能从该偏移量继续消费，避免重复消费已经处理过的消息。
- **Kafka 事务** 确保输出到 `output-topic` 的消息只有在 Checkpoint 成功后才提交，避免了部分写入导致的重复或丢失。
- **外部存储（MinIO）** 保证了 Checkpoint 数据在容器重启后依然存在。

![[Pasted image 20260407150434.png]]

![[Pasted image 20260407150416.png]]
![[Pasted image 20260407151535.png]]