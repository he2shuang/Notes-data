package com.example;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

import java.util.Map;

import org.apache.beam.runners.flink.FlinkPipelineOptions;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KafkaEttPipeline {

    public interface KafkaPipelineOptions extends FlinkPipelineOptions {
    @Description("Kafka bootstrap servers")
    @Default.String("broker1:9092")
    String getBootstrapServers();
    void setBootstrapServers(String servers);

    @Description("Input Kafka topic")
    @Default.String("input-topic")
    String getInputTopic();
    void setInputTopic(String topic);

    @Description("Output Kafka topic")
    @Default.String("output-topic")
    String getOutputTopic();
    void setOutputTopic(String topic);
    
    @Description("Maximum number of records to read in batch mode. -1 means no limit (read all).")
    @Default.Long(-1)
    Long getBatchMaxRecords();
    void setBatchMaxRecords(Long maxRecords);
}

    private static final Logger LOG = LoggerFactory.getLogger(KafkaEttPipeline.class);

    // 具体的なビジネスロジックを処理するDoFnを定義します。ここではメッセージのvalueを大文字に変換します
    static class UppercaseTransformFn extends DoFn<KV<Long, String>, KV<Long, String>> {
        @ProcessElement
        public void processElement(@Element KV<Long, String> element, OutputReceiver<KV<Long, String>> out) {
            Long key = element.getKey();
            String originalValue = element.getValue();
            String upperValue = originalValue.toUpperCase();
            LOG.info("Transformed: key={}, original={}, uppercase={}",
                     key, originalValue, upperValue);
            out.output(KV.of(key, upperValue));
        }
    }

    public static void main(String[] args) {
        // 1. Pipelineオブジェクトを作成
        KafkaPipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(KafkaPipelineOptions.class);

        Pipeline pipeline = Pipeline.create(options);

        // 2. ソース: Kafkaのinputトピックからデータを読み取る
        //    KafkaIO.read() は PCollection<KafkaRecord<Long, String>> を返す
        //    .withoutMetadata() はコレクションをよりシンプルな PCollection<KV<Long, String>> に変換する
        var kafkaRead = KafkaIO.<Long, String>read()
                .withBootstrapServers(options.getBootstrapServers())
                .withTopic(options.getInputTopic())
                .withKeyDeserializer(LongDeserializer.class)
                .withValueDeserializer(StringDeserializer.class);

        // バッチ処理モード（--streaming=false）の場合、境界のないデータソースを境界のあるデータソースに変換します
        if (!options.isStreaming()) {
            long maxRecords = options.getBatchMaxRecords();
            if (maxRecords == -1) {
                maxRecords = Long.MAX_VALUE;
            }
            LOG.info("Running in BATCH mode, limiting read to {} records from Kafka", maxRecords);
            kafkaRead = kafkaRead.withConsumerConfigUpdates(Map.of("auto.offset.reset", "earliest")).withMaxNumRecords(maxRecords);
        } else {
            LOG.info("Running in STREAMING mode, will consume messages continuously");
        }
        
        // kafkaRead.withoutMetadata(): Kafkaのメタデータ（オフセット、パーティションなど）を破棄する
        PCollection<KV<Long, String>> inputData = pipeline.apply("ReadFromKafka", kafkaRead.withoutMetadata());

        // 3. 処理: データを処理する
        PCollection<KV<Long, String>> validTransactions = inputData
            .apply("UppercaseTransactions", ParDo.of(new UppercaseTransformFn()));

        // 4. シンク: 処理済みの有効トランザクションをKafkaのoutputトピックに書き戻す
        validTransactions.apply("WriteToKafka", KafkaIO.<Long, String>write()
            .withBootstrapServers(options.getBootstrapServers())
            .withTopic(options.getOutputTopic())
            .withKeySerializer(LongSerializer.class)
            .withValueSerializer(StringSerializer.class)
        );

        // 5. Pipelineを実行
        pipeline.run();
    }
}