
## [Beam Java クイックスタート](https://beam.apache.org/get-started/quickstart/java/)

### GitHubリポジトリのクローン

[apache/beam-starter-java](https://github.com/apache/beam-starter-java) GitHubリポジトリをクローンまたはダウンロードし、`beam-starter-java`ディレクトリに移動します。

```
git clone https://github.com/apache/beam-starter-java.git
cd beam-starter-java
```

### クイックスタートの実行

**Gradle**: Gradleを使用してクイックスタートを実行するには、次のコマンドを実行します。

```
gradle run --args='--inputText=Greetings'
```

**Maven**: Mavenを使用してクイックスタートを実行するには、次のコマンドを実行します。

```
mvn compile exec:java -Dexec.args=--inputText='Greetings'
```

上記のコマンドはPowerShell環境でエラーになる場合があります。その場合は次のコマンドを使用してください。

```
mvn compile exec:java "-Dexec.args=--inputText=Greetings"
```

出力例は以下のようになります。

```
Hello
World!
Greetings
```

行の順序は異なる場合があります。

### コードの確認

このクイックスタートのメインコードファイルは **App.java** ([GitHub](https://github.com/apache/beam-starter-java/blob/main/src/main/java/com/example/App.java)) です。このコードは以下の手順を実行します。

1. Beamパイプラインを作成する。
2. 初期の`PCollection`を作成する。
3. `PCollection`に変換を適用する。
4. Direct Runnerを使用してパイプラインを実行する。

#### パイプラインの作成

コードは最初にパイプラインオブジェクトを作成します。パイプラインオブジェクトは、実行される変換のグラフを構築します。

```java
var options = PipelineOptionsFactory.fromArgs(args).withValidation().as(Options.class);
var pipeline = Pipeline.create(options);
```

`PipelineOptions`オブジェクトを使用すると、パイプラインにさまざまなオプションを設定できます。この例で示されている`fromArgs`メソッドはコマンドライン引数を解析するために使用され、コマンドラインからパイプラインオプションを設定できるようにします。

#### 初期PCollectionの作成

`PCollection`抽象化は、分散可能な複数要素のデータセットを表現します。Beamパイプラインは、初期の`PCollection`を埋めるためのデータソースを必要とします。データソースは有界（既知の固定サイズを持つ）または無界（サイズに制限がない）にすることができます。

この例では、[`Create.of`](https://beam.apache.org/releases/javadoc/current/org/apache/beam/sdk/transforms/Create.html)メソッドを使用して、メモリ内の文字列配列から`PCollection`を作成します。結果の`PCollection`には、文字列「Hello」、「World!」、およびユーザーが提供した入力文字列が含まれます。

```java
return pipeline
  .apply("Create elements", Create.of(Arrays.asList("Hello", "World!", inputText)))
```

#### PCollectionへの変換の適用

変換は、`PCollection`内の要素を変更、フィルタリング、グループ化、分析、またはその他の方法で処理できます。この例では、[`MapElements`](https://beam.apache.org/releases/javadoc/current/org/apache/beam/sdk/transforms/MapElements.html)変換を使用しています。これはコレクションの要素を新しいコレクションにマッピングします。

```java
.apply("Print elements",
    MapElements.into(TypeDescriptors.strings()).via(x -> {
      System.out.println(x);
      return x;
    }));
```

ここで、
- `into` は出力コレクションの要素のデータ型を指定します。
- `via` は、入力コレクションの各要素に対して呼び出されて出力コレクションを作成するマッピング関数を定義します。

この例では、マッピング関数は元の値をそのまま返すラムダ式です。また、副作用として値を `System.out` に出力します。

#### パイプラインの実行

これまでのセクションで示したコードはパイプラインを定義していますが、まだデータは処理されていません。データを処理するには、パイプラインを実行する必要があります。

```java
pipeline.run().waitUntilFinish();
```

Beam [ランナー](https://beam.apache.org/documentation/basics/#runner) は、特定のプラットフォーム上でBeamパイプラインを実行します。この例では[Direct Runner](https://beam.apache.org/releases/javadoc/2.3.0/org/apache/beam/runners/direct/DirectRunner.html)を使用しています。これはランナーが指定されていない場合のデフォルトです。Direct Runnerはローカルマシン上でパイプラインを実行し、主にテストと開発を目的としており、効率性は最適化されていません。詳細については[Using the Direct Runner](https://beam.apache.org/documentation/runners/direct/)を参照してください。

本番ワークロードでは通常、Apache Flink、Apache Spark、Google Cloud Dataflowなどのビッグデータ処理システム上でパイプラインを実行する分散ランナーを使用します。これらのシステムは大規模な並列処理をサポートしています。
