# 1.下载安装XAMPP

下载网址：[XAMPP Installers and Downloads for Apache Friends](https://www.apachefriends.org/zh_cn/index.html)

![[Download and install XAMPP.png]]

问题1：MySQL启动失败

![[MySQL failed to start.png]]

3306端口已被占用，点击MySQL的config选择my.ini打开文件，将文件中的所有port改为3316后保存，重新启动MySQL成功。

![[MySQL restarted successfully.png]]

# 2.下载安装Drupal

## 1.下载安装

下载网址：[drupal 11.3.5 | Drupal.org](https://www.drupal.org/project/drupal/releases/11.3.5)

![[Download and install Drupal.png]]

下载解压后，将解压的文件复制到目录C:\xampp\htdocs中，并重命名为drupal-gfg

![[Copy and rename the folder as drupal-gfg.png]]

浏览器访问：[http://localhost:80](http://localhost:80)，如下图则启动成功

![[Access localhost in the browser.png]]

问题2：浏览器访问localhost显示如图

![[Browser access to localhost display.png]]

xampp的mysql默认密码为空，但是使用空密码时无法登录，因此修改mysql密码。

使用命令mysql -u root -p -P 3316 登录mysql，命令ALTER USER 'root'@'localhost' IDENTIFIED BY 'new_password'修改密码，找到C:\xampp\phpMyAdmin\config.inc.php文件，修改其中的密码为新密码。

![[Change MySQL password.png]]

## 2.创建数据库

![[Create database.png]]

创建成功后访问[http://localhost/drupal-gfg/](http://localhost/drupal-gfg)

进入网页后，语言选择为简体中文，安装方式选择为标准

![[Language.png]]

检查安装需求显示如图

![[Check installation requirements.png]]

打开Apache配置

![[Apache Configuration.png]]

将zend_extension前的分号;删除，并修改为zend_extension=php_opcache.dll

将extension=gd前的分号;删除，保存文件，重新启动Apache，刷新drupal-gfg页面，进入下一步设置数据库

![[Set up the database.png]]

设置网站

![[Set up website.png]]

完成配置后，网站成功显示

![[Website Display.png]]

问题3：创建数据库drupal-gfg成功后访问[http://localhost/drupal-gfg/](http://localhost/drupal-gfg)，显示如图

![[Browser access to the drupal-gfg webpage display.png]]

已知下载安装的Drupal版本为11.3.5。在 C:\xampp\htdocs 目录下创建 info.php 文件，内容为 <?php phpinfo(); ?> ，然后通过浏览器访问 [http://localhost/info.php](http://localhost/info.php)，即可看到完整的 PHP 版本信息。XAMPP中的php版本为8.2.12，php版本不支持当前Drupal版本，降低为Drupal 10.5.5后即可成功。

![[PHP version in XAMPP.png]]