# 1. 安装 curl
## 1.1 下载并解压 curl

下载地址：[curl for Windows](https://curl.se/windows/)

下载后解压文件，此处我的解压地址为 `D:\devsoft`。

## 1.2 配置环境变量

鼠标右键`此电脑-> 属性 -> 高级系统设置 -> 环境变量`，找到系统变量，单击 `Path -> 编辑 -> 新建`，然后将解压缩后的 curl 文件 bin 目录下的路径复制上去，然后点击确定。

![[config path.png]]

使用 `curl www.baidu.com` 测试效果，

![[test curl.png]]

# 2. 部署流程定义

启动 Tomcat，通过执行命令 `curl --user rest-admin:test http://localhost:8080/flowable-rest/service/management/engine` 验证应用运行正常，如果能获得正确的 json 响应，则说明REST API已经启动并在工作。。

![[test start.png]]

使用 REST API 部署流程定义时，需要将一个 .bpmn20.xml 文件（或对于多个流程引擎，一个 .zip文件）作为 ’multipart/formdata’ 上传，使用命令 `curl --user rest-admin:test -F "file=@C:\Eclipse\workspace\holidayrequest\src\main\resources\holiday-request.bpmn20.xml"  http://localhost:8080/flowable-rest/service/repository/deployments` 部署。

![[deploy.png]]

要验证流程定义已经正确部署，可以使用命令 `curl --user rest-admin:test http://localhost:8080/flowable-rest/service/repository/process-definitions` 请求流程定义的列表：

![[process definitions.png]]

# 3. 启动流程实例

通过REST API启动流程实例类似于通过Java API 进行流程：提供了一个 key 来标识要使用的流程定义以及初始流程变量的映射，且使用命令中需要添加转义符号 “\”，`curl --user rest-admin:test -H "Content-Type: application/json" -X POST -d "{\"processDefinitionKey\":\"holidayRequest\",\"variables\":[{\"name\":\"employee\",\"value\":\"John Doe\"},{\"name\":\"nrOfHolidays\",\"value\":7}]}" http://localhost:8080/flowable-rest/service/runtime/process-instances` 。

![[post success.png]]

# 4. 任务列表和完成任务

当流程实例启动后，第一个任务会指派给 “managers” 组。要获取这个组的所有任务，可以通过REST API进行任务查询：
`curl --user rest-admin:test -H "Content-Type: application/json" -X POST -d "{\"candidateGroup\":\"managers\"}" http://localhost:8080/flowable-rest/service/query/tasks` 。

![[task query.png]]

使用命令 `curl --user rest-admin:test -H "Content-Type: application/json" -X POST -d "{\"action\":\"complete\",\"variables\":[{\"name\":\"approved\",\"value\":true}]}" http://localhost:8080/flowable-rest/service/runtime/tasks/295b5ece-3965-11f1-848b-b0ac82b06e00` 完成任务，若发生错误提示无法找到服务任务引用的 CallExternalSystemDelegate 类，则需要将该类放在应用的 classpath 下。将其打包为 jar，放在 Tomcat 的 webapps 目录下的 flowable-rest 目录下的 WEB-INF/lib 目录下。重启应用，重新执行命令即可在 Tomcat 中看到 CallExternalSystemDelegate 的输出字符串。