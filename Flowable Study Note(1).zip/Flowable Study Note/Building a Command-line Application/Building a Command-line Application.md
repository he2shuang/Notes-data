
将构建的例子是一个简单的请假（holiday request）流程：雇员（employee）申请几天的假期，经理（manager）批准或驳回申请。会模拟将申请注册到某个外部系统，并给雇员发送结果邮件。

# 1. 创建流程引擎

首先，我们通过 `File → New → Maven Project` 创建一个新的 Maven 项目：

![[create maven project.png]]

在下一个界面，勾选 “create a simple project (skip archetype selection)”

![[project setting1.png]]

然后填写 “Group Id” 和  “Artifact id”

![[project setting2.png]]

我们现在有一个空的 Maven 项目，将在此添加两个依赖关系：Flowable 流程引擎和内存数据库 H2。将以下内容添加到 pom.xml 文件中：

```
<dependencies> 
	<dependency> 
		<groupId>org.flowable</groupId> 
		<artifactId>flowable-engine</artifactId> 
		<version>7.0.0</version> 
	</dependency> 
	<dependency> 
		<groupId>com.h2database</groupId> 
		<artifactId>h2</artifactId> 
		<version>2.1.214</version> 
	</dependency> 
</dependencies>
```

如果依赖的 JAR 因某种原因不会自动检索，你可以右键点击项目并选择 `Maven → Update Project` 强制手动刷新（但通常不需要这样做）。在项目中，“Maven Dependencies” 下，你现在应该能看到 flowable-engine 和其他各种（传递性）依赖。

创建一个新的 Java 类，并添加一个常规的 Java 主方法：

```
package org.flowable; 

public class HolidayRequest { 

	public static void main(String[] args) {
	
	} 
	 
}
```

实例化一个 ProcessEngine 实例，

```
package org.flowable; 

import org.flowable.engine.ProcessEngine; 
import org.flowable.engine.ProcessEngineConfiguration; 
import org.flowable.engine.impl.cfg.StandaloneProcessEngineConfiguration; 

public class HolidayRequest { 

	public static void main(String[] args) { 
		ProcessEngineConfiguration cfg = new 
			StandaloneProcessEngineConfiguration() 
				.setJdbcUrl("jdbc:h2:mem:flowable;DB_CLOSE_DELAY=-1") 
				.setJdbcUsername("sa") .setJdbcPassword("") 
				.setJdbcDriver("org.h2.Driver") 
	.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE); 
		
		ProcessEngine processEngine = cfg.buildProcessEngine(); 	
	} 
	
}
```

右键点击类文件，选择 `Run As → Java Application`。应用程序运行无碍，但控制台中除了日志未正确配置的消息外，没有显示任何有用信息。Flowable 内部使用 SLF4J 作为日志框架。在这个例子中，我们将使用 log4j 日志器而非 SLF4j，因此在 pom.xml 文件中添加以下依赖关系：

```
<dependency> 
	<groupId>org.slf4j</groupId> 
	<artifactId>slf4j-api</artifactId> 
	<version>2.0.7</version> 
</dependency> 
<dependency> 
	<groupId>org.slf4j</groupId> 
	<artifactId>slf4j-reload4j</artifactId> 
	<version>2.0.7</version> 
</dependency>
```

Log4j 需要一个属性文件来配置。将 log4j.properties 文件添加到 `src/main/resources` 文件夹中，内容如下：

```
log4j.rootLogger=DEBUG, CA 
log4j.appender.CA=org.apache.log4j.ConsoleAppender 
log4j.appender.CA.layout=org.apache.log4j.PatternLayout 
log4j.appender.CA.layout.ConversionPattern= %d{hh:mm:ss,SSS} [%t] %-5p %c %x - %m%n
```

重新运行应用。会看到关于引擎启动和数据库模式创建的详细日志。

![[rerun app.png]]

# 2. 部署流程定义

将以下 XML 保存在名为 holiday-request.bpmn20.xml 的文件中，存放于 `src/main/resources` 文件夹中。

```
<?xml version="1.0" encoding="UTF-8"?> 
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
	xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" 
	xmlns:omgdc="http://www.omg.org/spec/DD/20100524/DC" 
	xmlns:omgdi="http://www.omg.org/spec/DD/20100524/DI" 
	xmlns:flowable="http://flowable.org/bpmn" 
	typeLanguage="http://www.w3.org/2001/XMLSchema" 
	expressionLanguage="http://www.w3.org/1999/XPath" 
	targetNamespace="http://www.flowable.org/processdef"> 
	
	<process id="holidayRequest" name="Holiday Request" isExecutable="true"> 
	
		<startEvent id="startEvent"/> 
		<sequenceFlow sourceRef="startEvent" targetRef="approveTask"/> 
		
		<userTask id="approveTask" name="Approve or reject request"/> 
		<sequenceFlow sourceRef="approveTask" targetRef="decision"/> 
		
		<exclusiveGateway id="decision"/> 
		<sequenceFlow sourceRef="decision" targetRef="externalSystemCall"> 
			<conditionExpression xsi:type="tFormalExpression"> 
				<![CDATA[ ${approved} ]]> 
			</conditionExpression> 
		</sequenceFlow> 
		<sequenceFlow sourceRef="decision" targetRef="sendRejectionMail"> 
			<conditionExpression xsi:type="tFormalExpression"> 
				<![CDATA[ ${!approved} ]]> 
			</conditionExpression> 
		</sequenceFlow> 
		
		<serviceTask id="externalSystemCall" name="Enter holidays in external system" flowable:class="org.flowable.CallExternalSystemDelegate"/> 
		<sequenceFlow sourceRef="externalSystemCall" 
			targetRef="holidayApprovedTask"/> 
		
		<userTask id="holidayApprovedTask" name="Holiday approved"/> 
		<sequenceFlow sourceRef="holidayApprovedTask" targetRef="approveEnd"/> 
		
		<serviceTask id="sendRejectionMail" name="Send out rejection email" 
			flowable:class="org.flowable.SendRejectionMail"/> 
		<sequenceFlow sourceRef="sendRejectionMail" targetRef="rejectEnd"/> 
		
		<endEvent id="approveEnd"/> 
		
		<endEvent id="rejectEnd"/> 
		
	</process> 
	
</definitions>
```

要向 Flowable 引擎部署流程定义，使用 RepositoryService，该服务可从 ProcessEngine 对象中检索。通过 RepositoryService，通过传递 XML 文件的位置并调用 deploy() 方法来实际执行，创建新的部署：

```
RepositoryService repositoryService = processEngine.getRepositoryService(); 
Deployment deployment = repositoryService.createDeployment() 
	.addClasspathResource("holiday-request.bpmn20.xml") .deploy();
```

我们现在可以通过查询 API 来验证进程定义是否被引擎知晓（并对 API 有所了解）。这通过通过 RepositoryService 创建一个新的 ProcessDefinitionQuery 对象来实现。

```
ProcessDefinition processDefinition = 
	repositoryService.createProcessDefinitionQuery() 
		.deploymentId(deployment.getId()) 
		.singleResult(); 
System.out.println("Found process definition : " + processDefinition.getName());
```

# 3. 启动流程实例

要启动流程实例，我们需要提供一些初始的流程变量。通常，你会通过向用户展示的表单获取这些信息，或者在自动触发进程时通过 REST API。在这个例子中，我们会保持简单，使用 java.util.Scanner 类在命令行中简单地输入一些数据：

```
Scanner scanner= new Scanner(System.in); 

System.out.println("Who are you?"); 
String employee = scanner.nextLine(); 

System.out.println("How many holidays do you want to request?"); 
Integer nrOfHolidays = Integer.valueOf(scanner.nextLine()); 

System.out.println("Why do you need them?"); 
String description = scanner.nextLine();
```

接下来，我们可以通过 RuntimeService 启动流程实例。收集到的数据会以 java.util.Map 实例的形式传递，其中密钥是用于后续检索变量的标识符。进程实例通过密钥启动。该键匹配 BPMN 2.0 XML 文件中设置的 id 属性，在此例中为 holidayRequest。

```
<process id="holidayRequest" name="Holiday Request" isExecutable="true"> 

RuntimeService runtimeService = processEngine.getRuntimeService(); 

Map<String, Object> variables = new HashMap<String, Object>(); 
variables.put("employee", employee); 
variables.put("nrOfHolidays", nrOfHolidays); 
variables.put("description", description); 
ProcessInstance processInstance = 
	runtimeService.startProcessInstanceByKey("holidayRequest", variables);
```

当流程实例启动时，会创建一个执行并放入启动事件中。之后，该执行会按照序列流前往用户任务，等待管理者批准，并执行用户任务的行为。这种行为会在数据库中创建一个任务，之后可以通过查询找到。用户任务处于等待状态，引擎会停止执行任何后续任务，返回 API 调用。

# 4. 另一个话题：事务

在 Flowable 中，数据库事务扮演了关键角色，用于保证数据一致性，并解决并发问题。当调用 Flowable API 时，默认情况下，所有操作都是同步的，并处于同一个事务下。这意味着，当方法调用返回时，会启动并提交一个事务。

流程启动后，会有一个数据库事务从流程实例启动时持续到下一个等待状态。在这个例子里，指的是第一个用户任务。当引擎到达这个用户任务时，状态会持久化至数据库，提交事务，并返回 API 调用处。

在 Flowable 中，当一个流程实例运行时，总会有一个数据库事务从前一个等待状态持续到下一个等待状态。数据持久化之后，可能在数据库中保存很长时间，甚至几年，直到某个 API 调用使流程实例继续执行。请注意当流程处在等待状态时，不会消耗任何计算或内存资源，直到下一次 API 调用。

在这个例子中，当第一个用户任务完成时，会启动一个数据库事务，从用户任务开始，经过排他网关（自动逻辑），直到第二个用户任务。或通过另一条路径直接到达结束。

# 5. 查询与完成任务

在更真实的应用中，会有一个用户界面，员工和经理可以登录查看任务列表。通过这些，他们可以检查存储为流程变量的进程实例数据，并决定对任务的处理方式。在这个例子中，我们将通过执行通常位于驱动 UI 的服务调用后的 API 调用来模拟任务列表。

我们还没有为用户任务配置好分配。我们希望第一个任务分配给“经理（managers）”组，第二个用户任务分配给假期的原始请求者。为此，在第一个任务中添加 candidateGroups 属性：

```
<userTask id="approveTask" name="Approve or reject request" 
	flowable:candidateGroups="managers"/>
```

并如下所示为第二个任务添加 assignee 属性。请注意我们没有像上面的 “managers” 一样使用静态值，而是使用一个流程变量动态指派。这个流程变量是在流程实例启动时传递的：

```
<userTask id="holidayApprovedTask" name="Holiday approved" 
	flowable:assignee="${employee}"/>
```

要获得实际的任务列表，我们通过 TaskService 创建一个任务查询，并配置查询只返回 “managers” 组的任务：

```
TaskService taskService = processEngine.getTaskService(); 
List<Task> tasks = 
	taskService.createTaskQuery().taskCandidateGroup("managers").list(); 
System.out.println("You have " + tasks.size() + " tasks:"); 
for (int i=0; i<tasks.size(); i++) { 
	System.out.println((i+1) + ") " + tasks.get(i).getName()); 
}
```

利用任务标识符，我们现在可以获取具体的进程实例变量，并在屏幕上显示实际请求：

```
System.out.println("Which task would you like to complete?"); 
int taskIndex = Integer.valueOf(scanner.nextLine()); 
Task task = tasks.get(taskIndex - 1); 
Map<String, Object> processVariables = taskService.getVariables(task.getId()); 
System.out.println(processVariables.get("employee") + " wants " + 
	processVariables.get("nrOfHolidays") + " of holidays. Do you approve this?");
```

运行结果如下：

![[console display.png]]

经理现在就可以完成任务了。在现实中，这通常意味着由用户提交一个表单。表单中的数据作为流程变量传递。在这里，我们在完成任务时传递带有 “approved” 变量（这个名字很重要，因为之后会在顺序流的条件中使用！）的 map 来模拟：

```
boolean approved = scanner.nextLine().toLowerCase().equals("y"); 
variables = new HashMap<String, Object>(); 
variables.put("approved", approved); 
taskService.complete(task.getId(), variables);
```

# 6. 编写 JavaDelegate

还有最后一块拼图还没实现：我们没有实现请求批准时自动执行的逻辑。在 BPMN 2.0 XML 中，这是一个服务任务，内容如下：

```
<serviceTask id="externalSystemCall" name="Enter holidays in external system" 
	flowable:class="org.flowable.CallExternalSystemDelegate"/>
```

在现实中，这个逻辑可以做任何事情：向某个系统发起一个HTTP REST服务调用，或调用某个使用了好几十年的系统中的遗留代码。

创建一个新类（Eclipse 中的 `File → New → Class`），将 org.flowable 作为包名，CallExternalSystemDelegate 作为类名。让类实现org.flowable.engine.delegate.JavaDelegate 接口，并实现执行方法：

```
package org.flowable; 

import org.flowable.engine.delegate.DelegateExecution; 
import org.flowable.engine.delegate.JavaDelegate; 

public class CallExternalSystemDelegate implements JavaDelegate { 

	public void execute(DelegateExecution execution) { 
		System.out.println("Calling the external system for employee " + 
			execution.getVariable("employee")); 
	}
	
}
```

当执行到达服务任务时，BPMN 2.0 XML 中引用的类会被实例化并调用。

现在运行示例时，会显示日志消息，表明自定义逻辑确实被执行：

![[complete.png]]

![[complete display.png]]

# 7. 历史数据处理

如果希望显示流程实例已经执行的时间，就可以从 ProcessEngine 获取 HistoryService，并创建历史活动（historical activities）的查询。

```
HistoryService historyService = processEngine.getHistoryService(); 
List<HistoricActivityInstance> activities = 
	historyService.createHistoricActivityInstanceQuery() 
		.processInstanceId(processInstance.getId()) 
		.finished() 
		.orderByHistoricActivityInstanceEndTime().asc() 
		.list(); 
		
for (HistoricActivityInstance activity : activities) { 
	System.out.println(activity.getActivityId() + " took " 
		+ activity.getDurationInMillis() + " milliseconds"); 
}
```

再运行一次示例，我们现在在控制台看到类似的内容：

![[historical data.png]]
