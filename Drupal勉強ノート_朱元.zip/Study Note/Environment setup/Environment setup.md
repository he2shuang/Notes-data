# 1.下载安装XAMPP

下载网址：[XAMPP Installers and Downloads for Apache Friends](https://www.apachefriends.org/zh_cn/index.html)

![[Download and install XAMPP.png]]

问题1：MySQL 启动失败

![[MySQL failed to start.png]]

3306端口已被占用，点击 MySQL 的 config 选择 my.ini 打开文件，将文件中的所有 port 改为3316后保存，重新启动 MySQL 成功。

![[MySQL restarted successfully.png]]

# 2.下载安装Drupal

## 1.下载安装

下载网址：[drupal 11.3.5 | Drupal.org](https://www.drupal.org/project/drupal/releases/11.3.5)

![[Download and install Drupal.png]]

下载解压后，将解压的文件复制到目录 `C:\xampp\htdocs` 中，并重命名为 drupal-gfg

![[Copy and rename the folder as drupal-gfg.png]]

浏览器访问：[http://localhost:80](http://localhost:80)，如下图则启动成功

![[Access localhost in the browser.png]]

问题2：浏览器访问 localhost 显示如图

![[Browser access to localhost display.png]]

xampp 的 mysql 默认密码为空，但是使用空密码时无法登录，因此修改 mysql 密码。

使用命令 `mysql -u root -p -P 3316` 登录mysql，命令 `ALTER USER 'root'@'localhost' IDENTIFIED BY 'new_password'` 修改密码，找到 `C:\xampp\phpMyAdmin\config.inc.php` 文件，修改其中的密码为新密码。

![[Change MySQL password.png]]

## 2.创建数据库

![[Create database.png]]

创建成功后访问 [http://localhost/drupal-gfg/](http://localhost/drupal-gfg)

进入网页后，语言选择为简体中文，安装方式选择为标准

![[Language.png]]

检查安装需求显示如图

![[Check installation requirements.png]]

打开 Apache 配置

![[Apache Configuration.png]]

将 zend_extension 前的分号;删除，并修改为 `zend_extension=php_opcache.dll`

将 extension=gd 前的分号;删除，保存文件，重新启动 Apache，刷新 drupal-gfg 页面，进入下一步设置数据库

![[Set up the database.png]]

设置网站

![[Set up website.png]]

完成配置后，网站成功显示

![[Website Display.png]]

问题3：创建数据库 drupal-gfg 成功后访问 [http://localhost/drupal-gfg/](http://localhost/drupal-gfg) ，显示如图

![[Browser access to the drupal-gfg webpage display.png]]

已知下载安装的 Drupal 版本为11.3.5。在 `C:\xampp\htdocs` 目录下创建 info.php 文件，内容为 `<?php phpinfo(); ?>` ，然后通过浏览器访问 [http://localhost/info.php](http://localhost/info.php)，即可看到完整的 PHP 版本信息。XAMPP 中的 php 版本为8.2.12，php 版本不支持当前 Drupal 版本，降低为 Drupal 10.5.5 后即可成功。

![[PHP version in XAMPP.png]]