# 1. 使用 RestUI 模块获取实体的 json 数据
## 1.1 安装 RestUI 模块

使用命令 `composer require drupal/restui` 安装模块，并在扩展中启用 HTTP Basic Authentication、REST UI、RESTful Web Services 和 Serialization 模块。

## 1.2 打开你要获取的实体 API 权限

进入 `配置 → Web 服务 → REST` 选择要获取数据的实体，点击启用，勾选 json、GET 和 basic_auth 后保存配置。

![[get json config.png]]

## 1.3 获取实体的 json 数据

打开 Postman，添加新的 request，方法选择 GET，输入 URL，例如获取内容的 json 数据时 http://localhost/drupal-gfg/node/8?_format=json ，在 Auth Type 中选择 Basic Auth 并输入网站的管理员账号和密码，点击 Send 后即可得到 json 数据，如图

![[get node.png]]

# 2. 使用 RestUI 模块创建实体
## 2.1 打开你要获取的实体 API 权限

进入 `配置 → Web 服务 → REST` 选择要获取数据的实体，点击启用，勾选 json、POST 和 basic_auth 后保存配置。

![[create config.png]]

## 2.2 创建实体

打开 Postman，添加新的 request，方法选择 POST，输入 URL，例如获取内容的 json 数据时 http://localhost/drupal-gfg/node?_format=json ，在 Auth Type 中选择 Basic Auth 并输入网站的管理员账号和密码，在 Body 中选择为 JSON 格式，输入创建实体时需要的数据，点击 Send 后即可创建实体，如图

![[create node.png]]

# 3. 使用 RestUI 模块实现多站点content同步（手动）
