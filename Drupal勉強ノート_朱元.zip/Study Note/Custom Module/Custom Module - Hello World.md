# 1. 创建模块文件夹

创建模块文件夹，并放在`C:\xampp\htdocs\drupal-gfg\modules`目录下

![[Folder.png]]

# 2. 编写 hello_world.info.yml 文件内容

文件内容如图所示，

![[info.png]]

打开前端，显示报错，如图，

![[error1.png]]

将文件中的`core`改为`core_version_requirement`后，打开前端，能看见模块被正常识别。

![[module recognize.png]]

# 3. 编写 hello_world.module 文件内容

文件内容如图所示，

![[module.png]]

实现Hook函数hook_help()，从而模块可以向用户提供整个模块或特定页面的文档。开发者帮助通常应通过代码中的函数头注释或特殊的 API 示例文件提供。该钩子提供的页面特定帮助信息会出现在帮助模块（由核心帮助模块提供）中，如果该模块显示在该页面。模块概述帮助信息由帮助模块显示。你可以从 `/admin/help` 页面或延伸页面访问。

`use Drupal\Core\Routing\RouteMatchInterface;` 用于导入一个类的全限定名称，以便在当前文件中可以直接使用简短类名 `RouteMatchInterface`，而无需每次都写完整的命名空间路径。

`Drupal\Core\Routing\RouteMatchInterface` 是 Drupal 核心提供的一个接口，位于 `core/lib/Drupal/Core/Routing/` 目录下。该接口定义了获取当前路由信息的方法，例如获取当前路由名称、路由参数、当前匹配的对象等。

`$route_name`：如需页面特定帮助，请使用模块 `routing.yml` 文件中识别的路由名称。模块概述帮助时，路线名称将以 `help.page.modulename` 的形式出现。

`$route_match`：当前路由匹配。这可以用来为共享相同路径的不同页面生成不同的帮助输出。

`return $output;` 如果路由名称是 `help.page.hello_world`，返回值是一个 HTML 字符串，用于在模块帮助页面上显示说明内容。`$output` 是一个字符串变量，通过 `.=` 运算符拼接了带有翻译函数的 HTML 片段。`t('About')` 和 `t('This is an example module.')` 将文本标记为可翻译，便于多语言支持。如果路由名称不是 `help.page.hello_world`，函数直接结束，没有返回值，此时不会显示任何额外帮助内容。

# 4. 编写 hello_world.routing.yml 文件内容

文件内容如图所示，

![[routing.png]]

# 5. 编写 HelloWorldController.php 文件内容

文件内容如图所示，

![[controller.png]]

# 6. 编写 hello_world.services.yml 文件内容

文件内容如图所示，

![[services.png]]

# 7. 编写 HelloWorldService.php 文件内容

文件内容如图所示，

![[service.png]]

# 8. 在 HelloWorldController.php 文件注入依赖service

文件内容如图所示，

![[update controller.png]]

由于没有写方法 `helloWorld2()` 和 `helloWorld3()` 导致无法加载界面，查看 Drupal 日志发现错误。

![[error2.png]]

于是将方法 `helloWorld2()` 和 `helloWorld3()` 补全。

![[final controller.png]]

重新清空缓存，访问 `/hello` 页面。

![[module display.png]]