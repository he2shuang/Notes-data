# 1. 下载 XDebug

[Xdebug: Downloads](https://xdebug.org/download)

![[xdebug download.png]]

根据 php 版本选择下载，我的 php 版本为8.2，选择了 php 8.2 ts 版本下载。将下载好的 dll 文件放到 `C:\xampp\php\ext` 目录下，并重命名为 php_xdebug.dll。

# 2. 配置 php.ini 文件

打开 XAMPP，打开 Apache 的 php.ini 文件，在文件末尾添加代码：

```
[xdebug]
zend_extension=C:/xampp/php/ext/php_xdebug.dll
xdebug.client_port = 9003
xdebug.client_host = localhost
xdebug.log = C:/xampp/php/xdebug.log
xdebug.mode=trace,debug,develop
xdebug.start_with_request=yes
xdebug.output_dir = C:/xampp/php/tmp
xdebug.force_display_errors = 1
xdebug.remote_enable = 1
xdebug.remote_autostart = 1
```

保存文件，并重启 Apache。

# 3. 配置 IDE（VS Code）

打开 VS Code，安装相关扩展。

![[vs code extensions.png]]

在 VS Code 中打开 Drupal 的项目文件夹，在根目录下创建 `.vscode/launch.json` 文件，文件内容如下，

![[launch.png]]

保存文件后，可以在 Drupal 中想调试的代码处打上断点，即可实现调试。