进入第二阶段，你需要从单节点扩展到**多节点集群**，这样才能真正理解副本、ISR、`acks=all` 等核心机制。同时，你仍然可以在 Docker 环境中完成所有实验，只需要修改 `docker-compose.yml` 启动三个 broker 即可。

---

## 一、环境升级：搭建 KRaft 三节点集群

### 1. 修改 docker-compose.yml
将原来的 `broker` 服务替换为三个服务：`broker1`、`broker2`、`broker3`。注意每个节点的 `NODE_ID`、`CONTROLLER_QUORUM_VOTERS` 和 `ADVERTISED_LISTENERS` 的配置。

**完整配置如下**（请备份原文件后替换）：

```yaml
services:
  broker1:
    image: apache/kafka:latest
    hostname: broker1
    container_name: broker1
    ports:
      - "9092:9092"
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_NODE_ID: 1
      KAFKA_PROCESS_ROLES: broker,controller
      # 监听配置：内部通信使用 29092，控制器使用 29093，对外使用 9092
      KAFKA_LISTENERS: PLAINTEXT://broker1:29092,CONTROLLER://broker1:29093,PLAINTEXT_HOST://0.0.0.0:9092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://broker1:29092,PLAINTEXT_HOST://172.18.24.79:9092   # 修改为你的 WSL IP
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT,CONTROLLER:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      # 控制器投票者：三个节点，使用内部地址
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@broker1:29093,2@broker2:29093,3@broker3:29093
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 3          # 保持与原配置一致（单副本）
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_TRANSACTION_STATE_LOG_MIN_ISR: 2
      KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR: 3
      KAFKA_LOG_DIRS: /tmp/kraft-combined-logs
      CLUSTER_ID: "MkU3OEVBNTcwNTJENDM2Qk"               # 集群 ID 保持一致

  broker2:
    image: apache/kafka:latest
    hostname: broker2
    container_name: broker2
    ports:
      - "9093:9092"
    environment:
      KAFKA_BROKER_ID: 2
      KAFKA_NODE_ID: 2
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_LISTENERS: PLAINTEXT://broker2:29092,CONTROLLER://broker2:29093,PLAINTEXT_HOST://0.0.0.0:9092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://broker2:29092,PLAINTEXT_HOST://172.18.24.79:9093   # 使用不同主机端口
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT,CONTROLLER:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@broker1:29093,2@broker2:29093,3@broker3:29093
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 3
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_TRANSACTION_STATE_LOG_MIN_ISR: 2
      KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR: 3
      KAFKA_LOG_DIRS: /tmp/kraft-combined-logs
      CLUSTER_ID: "MkU3OEVBNTcwNTJENDM2Qk"

  broker3:
    image: apache/kafka:latest
    hostname: broker3
    container_name: broker3
    ports:
      - "9094:9092"
    environment:
      KAFKA_BROKER_ID: 3
      KAFKA_NODE_ID: 3
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_LISTENERS: PLAINTEXT://broker3:29092,CONTROLLER://broker3:29093,PLAINTEXT_HOST://0.0.0.0:9092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://broker3:29092,PLAINTEXT_HOST://172.18.24.79:9094
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT,CONTROLLER:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@broker1:29093,2@broker2:29093,3@broker3:29093
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 3
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_TRANSACTION_STATE_LOG_MIN_ISR: 2
      KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR: 3
      KAFKA_LOG_DIRS: /tmp/kraft-combined-logs
      CLUSTER_ID: "MkU3OEVB

  kafka-ui:
    image: ghcr.io/kafbat/kafka-ui:latest
    container_name: kafka-ui
    ports:
      - "8888:8080"
    environment:
      KAFKA_CLUSTERS_0_NAME: local
      # 内部通信使用三个 broker 的内部地址（Docker 网络内）
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: broker1:29092,broker2:29092,broker3:29092
      DYNAMIC_CONFIG_ENABLED: "true"
    depends_on:
      - broker1
      - broker2
      - broker3
```

**关键变化说明**：
- 每个 broker 都既是 `broker` 又是 `controller`（KRaft 模式允许合并角色）。
- 通过 `CONTROLLER_QUORUM_VOTERS` 声明三个控制器节点。
- 主机端口分别映射为 9092、9093、9094，方便从宿主机连接不同的 broker。



### 2. 启动集群
```bash
cd /home/limeng/kafka-docker
docker compose down    # 停止旧容器
docker compose up -d   # 启动三节点集群
```

### 3. 验证集群
```bash
# 查看所有容器
docker ps

# 进入任意 broker 查看集群信息
docker exec -it broker1 bash
cd /opt/kafka/bin
./kafka-broker-api-versions.sh --bootstrap-server localhost:9092
```

---

## 二、深入核心机制（结合集群实践）

### 1. 存储与持久化

#### 分区与副本机制（Leader / Follower）
创建主题时指定副本因子（例如 2）：
```bash
./kafka-topics.sh --create --topic replicated-topic \
  --bootstrap-server localhost:9092 \
  --partitions 3 \
  --replication-factor 2
```
查看主题详情，观察每个分区的 Leader 和 ISR 列表：
```bash
./kafka-topics.sh --describe --topic replicated-topic --bootstrap-server localhost:9092
```
你会看到类似：
```
Topic: replicated-topic Partition: 0    Leader: 2       Replicas: 2,3   Isr: 2,3        Elr:    LastKnownElr:
Topic: replicated-topic Partition: 1    Leader: 3       Replicas: 3,1   Isr: 3,1        Elr:    LastKnownElr:
Topic: replicated-topic Partition: 2    Leader: 1       Replicas: 1,2   Isr: 1,2        Elr:    LastKnownElr:
```
- **Leader**：处理该分区所有读写请求的 broker。
- **Replicas**：副本所在的所有 broker。
- **ISR**：同步副本集合，只有与 Leader 保持同步的副本才在 ISR 中。

**模拟 Leader 切换**：停止 Leader 所在的 broker（例如 broker2），观察分区 Leader 是否自动切换到其他 ISR 中的 broker。
```
Topic: replicated-topic Partition: 0    Leader: 3       Replicas: 2,3   Isr: 3  Elr:    LastKnownElr:
Topic: replicated-topic Partition: 1    Leader: 3       Replicas: 3,1   Isr: 3,1        Elr:    LastKnownElr:
Topic: replicated-topic Partition: 2    Leader: 1       Replicas: 1,2   Isr: 1  Elr:    LastKnownElr:
```


#### 消息日志结构（Segment 文件、索引）
进入某个 broker 的数据目录，查看实际存储的日志文件：
```bash
# 在宿主机上查看（假设数据挂载到 ./data1）
ls -l /home/limeng/kafka-docker/data1/
```
你会看到类似 `00000000000000000000.log` 和 `00000000000000000000.index` 的文件，分别对应消息日志和偏移量索引。

> 需要修改`docker-compose.yml`，在每个broker的最后设置`volumes`
> ```
>   volumes:
>     - ./data1:/tmp/kraft-combined-logs
> ```
#### 消息不丢失与数据一致性（ISR、acks 参数）
在集群环境下，可以通过调整生产者 `acks` 和主题的 `min.insync.replicas` 来观察不同可靠性级别的效果。

**设置主题的最小同步副本数**：
```bash
./kafka-configs.sh --bootstrap-server localhost:9092 \
  --entity-type topics --entity-name replicated-topic \
  --alter --add-config min.insync.replicas=2
```

### 2. 生产端与消费端核心参数模拟

#### 生产者参数：`acks`、`retries`、`batch.size`、`linger.ms`

#### acks
[生产者配置 | Apache Kafka --- Producer Configs | Apache Kafka](https://kafka.apache.org/42/configuration/producer-configs/#producerconfigs_acks)

生产者在认为一个请求完成之前，要求领导者已收到的确认数量。这控制了所发送记录的持久性。允许以下设置：
- `acks=0` 如果设置为零，那么生产者将完全不会等待服务器的任何确认。记录会立即添加到套接字缓冲区并被视为已发送。在这种情况下，无法保证服务器已收到记录，且 `retries` 配置不会生效（因为客户端通常不会知道任何故障）。每条记录返回的偏移量将始终设置为 `-1` 。
- `acks=1` 这意味着领导者会将记录写入其本地日志，但会在不等待所有追随者完全确认的情况下进行响应。在这种情况下，如果领导者在确认记录后、追随者复制记录之前立即发生故障，那么记录将会丢失。
- `acks=all` 这意味着领导者将等待完整的同步副本集确认记录。这保证了只要至少有一个同步副本保持活动状态，记录就不会丢失。这是可用的最强保证。这相当于 acks=-1 设置。
请注意，启用幂等性要求此配置值必须为 'all'。如果设置了冲突的配置且未显式启用幂等性，则幂等性将被禁用。

**模拟 `acks=0`**（可能丢消息）：
```bash
./kafka-console-producer.sh --topic replicated-topic \
  --bootstrap-server localhost:9092 \
  --producer-property acks=0
```
发送几条消息，然后模拟 broker 故障（例如停止 Leader），观察是否有消息丢失。

**模拟 `acks=1`**（Leader 确认，可能丢消息）：
```bash
./kafka-console-producer.sh --topic replicated-topic \
  --bootstrap-server localhost:9092 \
  --producer-property acks=1
```

**模拟 `acks=all`**（等待所有 ISR 确认）：
```bash
./kafka-console-producer.sh --topic replicated-topic \
  --bootstrap-server localhost:9092 \
  --producer-property acks=all
```
当 ISR 数量小于 `min.insync.replicas` 时，生产者会抛出 `NotEnoughReplicasException`，确保数据不会写入不安全的副本集。

**观察批处理参数**：
- 设置 `linger.ms` 为 500（延迟 500ms 再发送），`batch.size` 为 16384，观察生产端吞吐量变化（可用 `kafka-producer-perf-test.sh` 进行压测）。
#### `retries`
[生产者配置 retries | Apache Kafka --- Producer Configs | Apache Kafka](https://kafka.apache.org/42/configuration/producer-configs/#producerconfigs_retries)

因瞬时错误导致请求失败时的重试次数。设置大于零的值将导致客户端重新发送任何因可能瞬时错误而发送失败的记录。请求将重试这么多次，直到成功、因非瞬时错误失败或 `delivery.timeout.ms` 过期。请注意，这种自动重试在收到错误时只会重新发送相同的记录。设置为零将禁用此自动重试行为，以便将瞬时错误传播给应用程序处理。用户通常应倾向于不设置此配置，而是使用 `delivery.timeout.ms` 来控制重试行为。启用幂等性要求此配置值大于 0。如果设置了冲突的配置且未显式启用幂等性，则幂等性将被禁用。

#### `batch.size`
[生产者配置 batch.size | Apache Kafka --- Producer Configs | Apache Kafka](https://kafka.apache.org/42/configuration/producer-configs/#producerconfigs_batch.size)

当多条记录被发送至同一分区时，生产者会尝试将记录批量合并为更少的请求。这有助于提升客户端和服务端的性能。此配置项用于控制默认的批量大小（以字节为单位）。不会尝试批量处理超过此大小的记录。
注意：此设置给出了要发送的批次大小的上限。如果该分区累积的字节数少于这个值，我们将等待 `linger.ms` 时间，以期待更多记录的出现。

#### `linger.ms`

[生产者配置 linger.ms | Apache Kafka --- Producer Configs | Apache Kafka](https://kafka.apache.org/42/configuration/producer-configs/#producerconfigs_linger.ms)
此设置给出了批处理延迟的上限：一旦某个分区积累了 `batch.size` 字节的记录，无论此设置如何，都会立即发送；但是，如果该分区积累的字节数少于这个值，我们将“逗留”指定的时间，等待更多记录出现。此设置默认为 5（即 5 毫秒延迟）。例如，增加 `linger.ms=50` 会减少发送的请求数量，但在无负载情况下发送记录时，会增加最多 50 毫秒的延迟。在 Apache Kafka 4.0 中，默认值从 0 更改为 5，因为尽管增加了延迟时间，但更大批量的效率提升通常会导致生产者延迟相似或更低。

#### 五、测试批处理参数 `linger.ms` 和 `batch.size`

批处理参数主要用于提高生产者的吞吐量，通过延迟发送来积累更多消息，从而减少网络请求次数。测试时可以使用 Kafka 自带的性能测试工具 `kafka-producer-perf-test.sh`。

##### 1. 准备：创建测试主题

```bash
./kafka-topics.sh --create --topic perf-test \
  --bootstrap-server localhost:9092 \
  --partitions 6 \
  --replication-factor 3
```
##### 2. 基准测试：默认批处理参数（[linger.ms](https://linger.ms/)=0，batch.size=16384）

```bash

./kafka-producer-perf-test.sh \
  --topic perf-test \
  --num-records 500000 \
  --record-size 1000 \
  --throughput -1 \
  --producer-props bootstrap.servers=localhost:9092 \
    acks=1 \
    linger.ms=0 \
    batch.size=16384
```

观察输出中的 `records/sec`（吞吐量）和 `avg latency`（平均延迟）。

##### 3. 测试 `linger.ms=500`（延迟 500ms 积累批次）

```bash
./kafka-producer-perf-test.sh \
  --topic perf-test \
  --num-records 500000 \
  --record-size 1000 \
  --throughput -1 \
  --producer-props bootstrap.servers=localhost:9092 \
    acks=1 \
    linger.ms=500 \
    batch.size=16384
```

比较吞吐量和延迟的变化：`linger.ms` 增大通常会提高吞吐量（因为批次更大），但会增加单条消息的延迟。

##### 4. 测试 `batch.size=32768`（增大批次大小）

```bash
./kafka-producer-perf-test.sh \
  --topic perf-test \
  --num-records 500000 \
  --record-size 1000 \
  --throughput -1 \
  --producer-props bootstrap.servers=localhost:9092 \
    acks=1 \
    linger.ms=0 \
    batch.size=32768
```

观察吞吐量是否提升（如果消息生产速率快，更大批次能减少请求次数）。

> **注意**：`kafka-producer-perf-test.sh` 是 Kafka 自带的性能测试工具，它可以方便地测试不同参数组合下的吞吐量和延迟。测试时，`--throughput -1` 表示不限流，尽可能快地发送消息。

测试结果：
```
broker1:/opt/kafka/bin$ ./kafka-producer-perf-test.sh \
  --topic perf-test \
  --num-records 500000 \
  --record-size 1000 \
  --throughput -1 \
  --producer-props bootstrap.servers=localhost:9092 \
    acks=1 \
    linger.ms=0 \
    batch.size=16384
Option --producer-props has been deprecated and will be removed in a future version. Use --command-property instead.
33537 records sent, 6556.6 records/sec (6.25 MB/sec), 1279.0 ms avg latency, 3392.0 ms max latency.
38528 records sent, 7704.1 records/sec (7.35 MB/sec), 4720.2 ms avg latency, 5853.0 ms max latency.
28672 records sent, 5725.2 records/sec (5.46 MB/sec), 3831.7 ms avg latency, 5604.0 ms max latency.
29856 records sent, 5964.0 records/sec (5.69 MB/sec), 6573.4 ms avg latency, 7554.0 ms max latency.
30912 records sent, 5714.9 records/sec (5.45 MB/sec), 5137.0 ms avg latency, 6625.0 ms max latency.
36640 records sent, 7328.0 records/sec (6.99 MB/sec), 5293.5 ms avg latency, 6724.0 ms max latency.
25536 records sent, 5026.8 records/sec (4.79 MB/sec), 5269.5 ms avg latency, 7075.0 ms max latency.
29280 records sent, 5832.7 records/sec (5.56 MB/sec), 6247.1 ms avg latency, 7398.0 ms max latency.
14688 records sent, 2847.1 records/sec (2.72 MB/sec), 6343.2 ms avg latency, 8925.0 ms max latency.
10864 records sent, 2172.8 records/sec (2.07 MB/sec), 10362.6 ms avg latency, 13090.0 ms max latency.
19056 records sent, 3808.2 records/sec (3.63 MB/sec), 11655.6 ms avg latency, 14942.0 ms max latency.
37344 records sent, 7415.4 records/sec (7.07 MB/sec), 6177.2 ms avg latency, 14273.0 ms max latency.
47296 records sent, 9387.9 records/sec (8.95 MB/sec), 4180.4 ms avg latency, 6799.0 ms max latency.
50656 records sent, 10119.1 records/sec (9.65 MB/sec), 3158.5 ms avg latency, 4442.0 ms max latency.
54176 records sent, 10796.3 records/sec (10.30 MB/sec), 3099.2 ms avg latency, 4094.0 ms max latency.
500000 records sent, 6455.527869 records/sec (6.16 MB/sec), 4848.87 ms avg latency, 14942.00 ms max latency, 4589 ms 50th, 9750 ms 95th, 14032 ms 99th, 14890 ms 99.9th.
broker1:/opt/kafka/bin$ ./kafka-producer-perf-test.sh \
  --topic perf-test \
  --num-records 500000 \
  --record-size 1000 \
  --throughput -1 \
  --producer-props bootstrap.servers=localhost:9092 \
    acks=1 \
    linger.ms=500 \
    batch.size=16384
Option --producer-props has been deprecated and will be removed in a future version. Use --command-property instead.
38144 records sent, 7621.2 records/sec (7.27 MB/sec), 765.4 ms avg latency, 2177.0 ms max latency.
35456 records sent, 6959.0 records/sec (6.64 MB/sec), 4259.0 ms avg latency, 6763.0 ms max latency.
47008 records sent, 9199.2 records/sec (8.77 MB/sec), 3899.4 ms avg latency, 7237.0 ms max latency.
56992 records sent, 10907.6 records/sec (10.40 MB/sec), 3016.7 ms avg latency, 4248.0 ms max latency.
44448 records sent, 8859.5 records/sec (8.45 MB/sec), 3753.5 ms avg latency, 5015.0 ms max latency.
49632 records sent, 9343.4 records/sec (8.91 MB/sec), 3266.9 ms avg latency, 4030.0 ms max latency.
43328 records sent, 8665.6 records/sec (8.26 MB/sec), 3926.1 ms avg latency, 5706.0 ms max latency.
53312 records sent, 10662.4 records/sec (10.17 MB/sec), 2814.2 ms avg latency, 4434.0 ms max latency.
36416 records sent, 7194.0 records/sec (6.86 MB/sec), 4417.1 ms avg latency, 5921.0 ms max latency.
41936 records sent, 8039.9 records/sec (7.67 MB/sec), 4468.3 ms avg latency, 5778.0 ms max latency.
42768 records sent, 8553.6 records/sec (8.16 MB/sec), 3840.5 ms avg latency, 5226.0 ms max latency.
500000 records sent, 8557.394445 records/sec (8.16 MB/sec), 3486.72 ms avg latency, 7237.00 ms max latency, 3611 ms 50th, 5136 ms 95th, 6037 ms 99th, 6987 ms 99.9th.
Cbroker1:/opt/kafka/bin./kafka-producer-perf-test.sh \ \
  --topic perf-test \
  --num-records 500000 \
  --record-size 1000 \
  --throughput -1 \
  --producer-props bootstrap.servers=localhost:9092 \
    acks=1 \
    linger.ms=0 \
    batch.size=32768
Option --producer-props has been deprecated and will be removed in a future version. Use --command-property instead.
36897 records sent, 7315.0 records/sec (6.98 MB/sec), 541.1 ms avg latency, 2831.0 ms max latency.
65664 records sent, 12807.5 records/sec (12.21 MB/sec), 2331.6 ms avg latency, 3911.0 ms max latency.
51392 records sent, 10272.2 records/sec (9.80 MB/sec), 3514.7 ms avg latency, 6044.0 ms max latency.
59840 records sent, 11929.8 records/sec (11.38 MB/sec), 2784.4 ms avg latency, 4044.0 ms max latency.
62080 records sent, 12416.0 records/sec (11.84 MB/sec), 2506.0 ms avg latency, 3963.0 ms max latency.
45056 records sent, 9011.2 records/sec (8.59 MB/sec), 2873.2 ms avg latency, 4538.0 ms max latency.
56512 records sent, 11302.4 records/sec (10.78 MB/sec), 3487.1 ms avg latency, 4800.0 ms max latency.
54784 records sent, 10928.4 records/sec (10.42 MB/sec), 3136.0 ms avg latency, 3972.0 ms max latency.
500000 records sent, 11159.717882 records/sec (10.64 MB/sec), 2637.53 ms avg latency, 6044.00 ms max latency, 2662 ms 50th, 4211 ms 95th, 5031 ms 99th, 5869 ms 99.9th.
```

#### 消费者参数：`enable.auto.commit`、`auto.offset.reset`、`max.poll.records`

**模拟自动提交与手动提交**：
使用消费者组命令观察偏移量提交行为。

1. **自动提交**（默认）：
   ```bash
   ./kafka-console-consumer.sh --topic replicated-topic \
     --bootstrap-server localhost:9092 \
     --group test-group --from-beginning
   ```
   消费几条消息后按 `Ctrl+C` 退出。再重新启动同一消费者组，消息不会重复消费（因为偏移量已自动提交）。

2. **模拟手动提交**（通过编程方式，这里用 `kafka-console-consumer` 无法手动提交，但可以用 `kafka-consumer-groups.sh` 重置偏移量来模拟）：
   ```bash
   # 重置消费者组偏移量到指定位置
   ./kafka-consumer-groups.sh --bootstrap-server localhost:9092 \
     --group test-group --topic replicated-topic \
     --reset-offsets --to-earliest --execute
   ```
   这样可以让消费者组从头开始消费，模拟手动提交失败导致的重复消费场景。

**`auto.offset.reset` 参数**：
当消费者组没有已提交的偏移量时，决定从何处开始消费：
- `earliest`：从最早的消息开始
- `latest`：从最新消息开始（默认）
- `none`：如果没有偏移量则抛出异常

可以在启动消费者时指定：
```bash
./kafka-console-consumer.sh --topic replicated-topic \
  --bootstrap-server localhost:9092 \
  --group test-group \
  --consumer-property auto.offset.reset=earliest
```

**`max.poll.records`**：
限制每次拉取的最大消息数，防止单次处理时间过长导致 rebalance。在 Java 客户端中常用，命令行工具可忽略。

### 3. KRaft 模式关键点

- **元数据存储**：所有元数据（主题、分区、配置等）都存储在 Kafka 内部主题 `__cluster_metadata` 中，不再依赖 ZooKeeper。
- **控制器选举**：通过 Raft 协议在控制器节点中选举 Leader，负责管理集群元数据。
- **查看控制器**：在 UI 中可以看到哪个 broker 是当前控制器（Controller），或者通过命令：
  ```bash
  ./kafka-metadata-quorum.sh --bootstrap-server localhost:9092 describe --status
  ```

### 4. 实践任务

#### 任务一：模拟 acks 参数下的可靠性差异
1. 创建主题 `test-acks`，副本因子 3，`min.insync.replicas=2`。
2. 启动生产者，分别设置 `acks=0`、`acks=1`、`acks=all`，同时用消费者持续消费。
3. 在发送消息过程中，手动停止其中一个副本（不是 Leader），观察：
   - `acks=all` 是否因为 ISR 减少而失败
   - 停止 Leader 时，`acks=1` 是否导致消息丢失
4. 记录观察结果，理解不同 acks 的权衡。




#### 任务二：模拟消费者手动提交偏移量，验证重复消费或丢失消费
1. 使用一个消费者组消费主题，消费过程中手动重置偏移量（模拟提交失败）：
   ```bash
   # 消费者正常消费
   ./kafka-console-consumer.sh --topic replicated-topic \
     --bootstrap-server localhost:9092 \
     --group test-group --from-beginning
   ```
   按 `Ctrl+C` 停止。
2. 重置该消费者组的偏移量到更早的位置：
   ```bash
   ./kafka-consumer-groups.sh --bootstrap-server localhost:9092 \
     --group test-group --topic replicated-topic \
     --reset-offsets --to-offset 5 --execute
   ```
3. 再次启动同一个消费者组，观察是否重复消费了之前已经处理过的消息（模拟重复消费）。
4. 再尝试将偏移量向后移动（例如 `--to-offset 20`），模拟消息丢失场景。

---

## 三、环境注意事项

- **数据持久化**：三个 broker 的数据目录分别挂载，便于独立查看日志文件。
- **端口映射**：宿主机可以分别访问 9092、9093、9094 连接到不同的 broker，学习客户端如何连接集群。
- **重启集群**：实验过程中可能需要停止某些 broker，用 `docker compose stop broker1` 即可，之后用 `docker compose start broker1` 恢复。
- **清理数据**：如需彻底重置环境，删除 `data1`、`data2`、`data3` 目录后重新启动。

---

## 四、下一步

完成上述实践后，你对 Kafka 的存储、副本、一致性、生产消费参数的理解会更加深刻。后续还可以深入：
- 动态调整分区、副本重分配
- 使用 Kafka Streams 进行流处理
- 配置认证与授权（SASL/SSL）

如果在实验过程中遇到任何问题（比如无法连接、权限问题、命令报错），随时告诉我，我们一起排查。