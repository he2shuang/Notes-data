## 简单使用

假设有一个电商系统，用户下单后需要执行以下操作：
- 发送订单确认邮件
- 发送短信通知
- 更新积分

这些操作耗时较长，且不应该影响订单主流程的响应速度。因此，我们将这些操作放到 Kafka 中异步执行。

**架构**：
- 订单服务（生产者）：订单创建成功后，发送消息到 `order-events` 主题。
- 通知服务（消费者）：监听 `order-events` 主题，处理邮件、短信等。

**pom文件中引入**
```
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-kafka</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-kafka-test</artifactId>
            <scope>test</scope>
        </dependency>
```

application.yml
```
server:
  port: 8081
  
spring:
  application:
    name: demo
  kafka:
    bootstrap-servers: 172.18.24.79:9092, 172.18.24.79:9093, 172.18.24.79:9094
    producer:
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
      # 生产者核心参数
      acks: all
      retries: 2
    # 削峰填谷：生产者提高吞吐
    #   acks: 0               # 0: 不等待任何确认
    #   linger-ms: 10         # 延迟发送，批量凑合
      batch-size: 16384     # 批量发送大小
      buffer-memory: 33554432
    consumer:
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.springframework.kafka.support.serializer.JsonDeserializer
      # 消费者核心参数
      # 关闭自动提交
      enable-auto-commit: false
      auto-commit-interval: 1000
      auto-offset-reset: earliest

      # 限流：每次最多拉取10条消息
      max-poll-records: 10
      group-id: seckill-group
      properties:
        spring.json.trusted.packages: "com.example.kafka.dto"
  
    listener:
      # 监听器核心参数
      # 手动确认模式
      ack-mode: manual
      # 消费者线程数，并行处理
      concurrency: 5
      missing-topics-fatal: false
  
# 自定义死信主题后缀
app:
  kafka:
    dlt-suffix: .DLT
```
Spring Boot 自动配置的 `JsonDeserializer` 默认只信任 `java.util` 和 `java.lang` 包，无法反序列化你的自定义类。**`JsonDeserializer` 信任包** 通过 `spring.json.trusted.packages: "*"` 生效，反序列化不再报错。

**生产者**
```
    private final KafkaTemplate<String, OrderEvent> kafkaTemplate;
    private static final String TOPIC_ORDERS = "orders";
  
    /**
     * 发送消息（异步）
     */
    public String sendOrder(OrderEvent order) {
        CompletableFuture<SendResult<String, OrderEvent>> future =
            kafkaTemplate.send(TOPIC_ORDERS, order.getUserId(), order);
        future.whenComplete((result, ex) -> {
            if (ex == null) {
                log.info("消息发送成功: orderId={}, partition={}, offset={}",
                    order.getOrderId(),
                    result.getRecordMetadata().partition(),
                    result.getRecordMetadata().offset());
            } else {
                log.error("消息发送失败: orderId={}", order.getOrderId(), ex);
            }
        });
        return null;
    }
```
**解释**：
- `kafkaTemplate.send(topic, key, data)` 发送一条消息到指定主题。key 用于决定消息进入哪个分区（相同 key 进同一分区）。
- 发送是异步的，默认会立即返回，实际发送在后台完成。


**消费者**
```
    @KafkaListener(
        topics = "orders",
        groupId = "order-group"
    )
    public void consumeOrder(ConsumerRecord<String, OrderEvent> record,
                             Acknowledgment ack) {
        try {
            OrderEvent order = record.value();
            log.info("收到订单消息: orderId={}, userId={}, amount={}, partition={}, offset={}",
                order.getOrderId(),
                order.getUserId(),
                order.getAmount(),
                record.partition(),
                record.offset());
            // 模拟业务处理
            processOrder(order);
            
            // 模拟可能的失败：如果订单金额 > 1000，认为邮件服务异常（用于测试重试）
            if (order.getAmount() > 1000) {
                throw new RuntimeException("模拟邮件发送失败，触发重试");
            }
            
            // 手动确认消息
            ack.acknowledge();
            log.info("订单处理完成: orderId={}", order.getOrderId());
        } catch (Exception e) {
            log.error("订单处理失败: {}", e.getMessage(), e);
            // 不确认消息，会触发重试机制
            // 注意：不调用 ack.acknowledge() 即可
            throw new RuntimeException(e);
        }
    }
```
**解释**：
- `@KafkaListener` 指定要监听的主题（`topics`）和消费者组（`groupId`）。同一个组内的消费者会分摊分区消费。
- 方法参数可以是 `ConsumerRecord`，它包含了消息的元数据（如分区、偏移量）和值。也可以直接写 `Order order`，但这样会丢失元数据，一般用 `ConsumerRecord`。
- 当消息到达时，该方法被自动调用。

设置死信
```
    @Bean
    public DefaultErrorHandler errorHandler(KafkaTemplate<String, Object> kafkaTemplate) {
        // 创建 DeadLetterPublishingRecoverer，用于将失败消息发送到死信主题
        // 这里自定义了死信主题的命名规则：原主题名 + dltSuffix（如 .DLT）
        DeadLetterPublishingRecoverer recoverer = new DeadLetterPublishingRecoverer(
            kafkaTemplate,
            (consumerRecord, exception) -> {
                // 重试耗尽后的回调：记录死信消息
                log.error("消息重试耗尽，将发送到死信队列: topic={}, offset={}, value={}",
                    consumerRecord.topic(),
                    consumerRecord.offset(),
                    consumerRecord.value());
                // 自定义死信主题的 TopicPartition
                String deadLetterTopic = consumerRecord.topic() + dltSuffix;
                return new TopicPartition(deadLetterTopic, consumerRecord.partition());
            }
        );
  
        // 重试策略：最多重试 3 次（注意参数：间隔毫秒，重试次数）
        // 这里传 2 表示除第一次外再重试 2 次，总共 3 次尝试
        FixedBackOff backOff = new FixedBackOff(1000L, 2);
        // 创建错误处理器，并指定死信主题的后缀（默认为 .DLT）
        DefaultErrorHandler errorHandler = new DefaultErrorHandler(recoverer, backOff);
        // 配置不重试的异常类型（直接进死信）
        errorHandler.addNotRetryableExceptions(IllegalArgumentException.class);
        return errorHandler;
    }
  
    /**
     * 监听器容器工厂
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object>
            kafkaListenerContainerFactory(
                ConsumerFactory<String, Object> consumerFactory,
                DefaultErrorHandler errorHandler) {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
            new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);
        factory.setCommonErrorHandler(errorHandler);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        // 并发数：决定有多少个消费者线程
        factory.setConcurrency(3);
        return factory;
    }
```

消费死信（实际就是消费者）
```
    @KafkaListener(
        topics = "orders.DLT",
        groupId = "dlt-group"
    )

    public void consumeDeadLetter(ConsumerRecord<String, Object> record,
                                   Acknowledgment ack) {
        log.error("收到死信消息: topic={}, value={}, 原始topic={}",
            record.topic(),
            record.value(),
            record.headers().lastHeader("kafka_dlt_original_topic"));
        // 死信消息的其他处理逻辑：
        // 1. 记录到数据库
        // 2. 发送告警通知
        // 3. 人工介入处理
        ack.acknowledge();
    }
```

#### 1. 重试机制
- **作用**：当消费者处理消息失败时，自动重新尝试消费，避免因临时错误（如网络抖动、数据库连接失败）导致消息丢失。
- **Spring Kafka 实现**：通过 `DefaultErrorHandler` 配置重试策略（间隔、次数），并可以指定哪些异常不重试。
- **重试与偏移量**：重试期间消息不会提交偏移量，所以会反复消费直到成功或进入死信。这是“至少一次”语义的体现。

#### 2. 死信队列（DLQ）
- **作用**：当消息经过重试仍无法成功处理时，将其移入一个专门的死信主题，避免阻塞正常消息消费，同时保留失败消息以便后续分析和人工介入。
- **Spring Kafka 实现**：`DefaultErrorHandler` 在重试耗尽后，自动将消息发布到死信主题（原主题名 + `.DLT`），并附带原始主题名、异常信息等 Header。
- **死信消费者**：可以单独监听死信主题，处理失败消息（如记录日志、发送告警、存入数据库）。

#### 3. 手动确认与自动提交
- **手动确认**：在 `@KafkaListener` 方法中引入 `Acknowledgment` 参数，成功时调用 `ack.acknowledge()` 提交偏移量。失败时不调用，消息会重新消费。
- **自动提交**：默认情况下，Spring Kafka 在 `AckMode.BATCH` 或 `AckMode.RECORD` 等模式下自动提交。手动确认模式让我们更精确控制，配合重试机制效果更好。

## 场景说明：削峰填谷（Traffic Shaving）

**业务背景**：在秒杀、抢购、大促等活动中，瞬间会有大量请求涌入系统。如果直接处理，数据库、后端服务可能因压力过大而崩溃。Kafka 可以作为消息缓冲区，将突发的流量先暂存起来，然后由后端消费者以稳定的速率处理，从而保护下游系统。

**核心思想**：
- **削峰**：将瞬时高峰请求先写入 Kafka（写操作很快），避免直接冲击业务逻辑。
- **填谷**：消费者以可控的速率从 Kafka 拉取消息，平滑处理，让系统负载保持在安全范围内。

**Kafka 角色**：消息缓冲区（队列），具有高吞吐、持久化的特性。

**Spring Kafka 关键点**：
- 生产者配置高吞吐（如 `acks=0`、`linger.ms` 适当调大、批量发送）。
- 消费者配置限流（`max.poll.records` 限制每次拉取数量，`concurrency` 控制并发，手动提交确保处理完再确认）。

---

## 完整代码示例：秒杀场景削峰填谷

### 1. 项目结构
```
src/main/java/com/example/kafka/
├── SeckillApplication.java          # 启动类
├── controller/
│   └── SeckillController.java       # 秒杀入口
├── service/
│   ├── SeckillProducerService.java  # 生产者（将秒杀请求写入Kafka）
│   └── SeckillConsumerService.java  # 消费者（处理秒杀逻辑）
├── config/
│   └── KafkaConfig.java             # Kafka配置（生产者、消费者、重试等）
└── dto/
    └── SeckillRequest.java          # 秒杀请求DTO
```

### 2. 依赖（pom.xml）
与之前相同，只需 Spring Kafka 和 Web 即可。

### 3. 配置文件 `application.yml`
```yaml
spring:
  kafka:
    bootstrap-servers: 172.18.24.79:9092,172.18.24.79:9093,172.18.24.79:9094
    producer:
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
      # 削峰填谷：生产者提高吞吐
      acks: 0                 # 不等待确认，最快速度
      linger-ms: 10           # 延迟发送，批量凑合
      batch-size: 16384       # 批次大小
    consumer:
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.springframework.kafka.support.serializer.JsonDeserializer
      properties:
        spring.json.trusted.packages: "*"
      group-id: seckill-group
      auto-offset-reset: earliest
      enable-auto-commit: false
      # 限流：每次最多拉取10条消息
      max-poll-records: 10
    listener:
      ack-mode: manual        # 手动确认，控制处理进度
      concurrency: 3          # 3个消费者线程，并行处理

# 自定义主题名
app:
  kafka:
    seckill-topic: seckill-requests
```

**关键点**：
- `acks=0`：生产者不等待任何确认，吞吐量最高，但可能丢消息（削峰场景可接受，因为秒杀失败可以提示用户重试）。
- `max-poll-records=10`：消费者每次拉取最多10条消息，避免一次性拉取过多导致处理压力过大。
- `concurrency=3`：3个线程并发消费，提高处理能力，但仍受限于处理速度。
- `enable-auto-commit=false` + `ack-mode=manual`：让消费者在处理完一条消息后才确认，确保消息不丢失，同时便于控制速率。

### 4. 秒杀请求 DTO
```java
package com.example.kafka.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SeckillRequest {
    private String userId;
    private String productId;
    private Long timestamp;
}
```

### 5. 生产者服务（秒杀入口）
```java
package com.example.kafka.service;

import com.example.kafka.dto.SeckillRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class SeckillProducerService {

    private final KafkaTemplate<String, SeckillRequest> kafkaTemplate;

    @Value("${app.kafka.seckill-topic}")
    private String topic;

    /**
     * 将秒杀请求发送到 Kafka，快速返回
     */
    public void sendSeckillRequest(SeckillRequest request) {
        // 使用 productId 作为 key，保证同一商品的请求进入同一分区，便于后续处理
        kafkaTemplate.send(topic, request.getProductId(), request)
                .whenComplete((result, ex) -> {
                    if (ex == null) {
                        log.info("秒杀请求已写入Kafka: userId={}, productId={}, partition={}",
                                request.getUserId(), request.getProductId(),
                                result.getRecordMetadata().partition());
                    } else {
                        log.error("秒杀请求写入Kafka失败: userId={}, productId={}",
                                request.getUserId(), request.getProductId(), ex);
                        // 实际中可以记录失败，返回给用户失败信息
                    }
                });
    }
}
```

### 6. 消费者服务（秒杀处理）
```java
package com.example.kafka.service;

import com.example.kafka.dto.SeckillRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class SeckillConsumerService {

    // 模拟库存服务（实际可注入Service）
    private int stock = 100;   // 初始库存100件

    @KafkaListener(topics = "${app.kafka.seckill-topic}",
                   groupId = "seckill-group",
                   containerFactory = "seckillKafkaListenerContainerFactory")
    public void consume(ConsumerRecord<String, SeckillRequest> record, Acknowledgment ack) {
        SeckillRequest request = record.value();
        log.info("处理秒杀请求: userId={}, productId={}, partition={}, offset={}",
                request.getUserId(), request.getProductId(),
                record.partition(), record.offset());

        // 模拟限流：每个请求处理耗时100ms（控制处理速率，约10条/秒）
        try {
            TimeUnit.MILLISECONDS.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // 扣减库存（模拟业务）
        synchronized (this) {   // 简单同步，实际可用 Redis 或分布式锁
            if (stock > 0) {
                stock--;
                log.info("扣减库存成功，剩余库存: {}", stock);
                // 成功处理：可以发送成功通知给用户（例如WebSocket）
            } else {
                log.warn("库存不足，秒杀失败: userId={}", request.getUserId());
                // 失败处理：记录日志，可发送失败通知
            }
        }

        // 手动确认消息
        ack.acknowledge();
    }
}
```

**说明**：
- 消费者使用 `@KafkaListener` 监听秒杀主题，容器工厂 `seckillKafkaListenerContainerFactory` 将在后面配置。
- 我们模拟了业务处理耗时 100ms，这样单个消费者线程每秒最多处理 10 条消息。配合 `concurrency=3`，整体处理能力约 30 条/秒。
- 库存扣减使用 `synchronized` 模拟，实际应使用 Redis 原子操作或数据库乐观锁。

### 7. Kafka 配置类（包含消费者工厂和限流设置）
我们需要自定义一个 `ConcurrentKafkaListenerContainerFactory`，以便设置 `max.poll.records` 等参数。但 Spring Boot 自动配置的 `KafkaListenerContainerFactory` 会读取 `application.yml` 中的配置，其实也可以直接使用默认的，只要我们在 `application.yml` 中配置了 `max-poll-records` 和 `concurrency`，它就会生效。但是为了更清晰地展示，我们可以显式创建。

为了简化，我们可以不写专门的配置类，因为 `application.yml` 中的 `max-poll-records` 和 `concurrency` 会被自动应用到默认的工厂。但是，如果我们想手动控制更细粒度，比如不同的监听器使用不同的配置，就需要自定义。

这里我们使用 Spring Boot 自动配置，所以不需要额外配置类。但为了与之前的异步处理区分，我们可以创建一个独立的 `SeckillKafkaConfig`，但这不是必须的。

为了确保 `max-poll-records` 生效，注意配置键是 `spring.kafka.consumer.max-poll-records`，不是 `max.poll.records` 直接写（在 yaml 中可以直接用 `max-poll-records`，因为 Spring Boot 会将连字符转换为驼峰）。已在 `application.yml` 中配置了。

### 8. 启动类
```java
package com.example.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeckillApplication {
    public static void main(String[] args) {
        SpringApplication.run(SeckillApplication.class, args);
    }
}
```

### 9. 控制器（REST 入口）
```java
package com.example.kafka.controller;

import com.example.kafka.dto.SeckillRequest;
import com.example.kafka.service.SeckillProducerService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/seckill")
@RequiredArgsConstructor
public class SeckillController {

    private final SeckillProducerService producerService;

    @PostMapping
    public String seckill(@RequestBody SeckillRequest request) {
        // 可加一些前置校验（如用户是否已秒杀过等）
        request.setTimestamp(System.currentTimeMillis());
        producerService.sendSeckillRequest(request);
        return "秒杀请求已接收，请稍后查看结果";
    }
}
```

---

### 如何模拟削峰填谷效果

#### 1. 启动 Kafka 集群
确保三节点 Kafka 已启动（IP: 172.18.24.79，端口 9092-9094）。

#### 2. 启动 Spring Boot 应用

#### 3. 使用压测工具发送大量请求
可以使用 `curl` 循环发送，或使用 JMeter、Apache Bench (ab)。

**快速模拟**：在 WSL 或 Windows 终端执行以下命令（发送 200 次请求）：
```bash
for i in {1..200}; do
  curl -X POST http://localhost:8080/seckill \
    -H "Content-Type: application/json" \
    -d "{\"userId\":\"user$i\",\"productId\":\"product1\"}" &
done
```
注意：`&` 会使命令后台执行，瞬间并发很多请求。

#### 4. 观察日志
- 生产者会快速打印“秒杀请求已写入Kafka”的日志（因为 `acks=0`，写入很快）。
- 消费者日志会显示缓慢地处理每条消息，每处理一条间隔约 100ms，总体处理速率约 30 条/秒（3个线程）。
- 库存从 100 逐渐减少，直到耗尽。
- 可以看到虽然生产者瞬间接收了 200 个请求，但消费者平稳地处理，没有压垮应用。

#### 5. 验证 Kafka 中的堆积
在 Kafka UI 中查看 `seckill-requests` 主题，可以看到消息的 `offset` 和 `lag`（未消费消息数）。初始 lag 会很大，然后逐渐减少。这直观体现了“削峰填谷”。

---

#### 关键参数调整说明

| 参数 | 作用 | 削峰填谷推荐值 |
|------|------|----------------|
| `acks=0` | 生产者不等待确认，最高吞吐 | `0` 或 `1`（若允许丢失少量消息） |
| `linger.ms` | 延迟发送，积累批次 | 10~50ms，提高吞吐 |
| `batch.size` | 批次大小 | 16384 或更大 |
| `max.poll.records` | 每次拉取最大消息数 | 10~50，限制消费压力 |
| `concurrency` | 消费者线程数 | 根据服务器 CPU 核心数设置，一般 3~10 |
| 业务处理耗时 | 模拟限流 | 可根据下游处理能力设置（如 100ms） |

##### 扩展思考

- **动态限流**：可以根据消费者处理能力动态调整 `max.poll.records` 或使用 `Consumer` API 手动控制拉取速度。
- **分布式库存**：实际场景中库存应在 Redis 或数据库中原子扣减，避免并发问题。
- **失败处理**：秒杀失败的消息可以进入死信队列，记录日志，后续补偿。

通过这个例子，你可以直观地理解 Kafka 如何通过缓冲和限流来应对突发流量，保护后端系统。

#### 压力测试结果
![[Pasted image 20260326165659.png]]

![[Pasted image 20260326165748.png]]
![[Pasted image 20260326165907.png]]
## 数据管道场景说明

**业务背景**：在大型系统中，各种日志（应用日志、用户行为日志、系统监控数据）需要被收集、处理并存储到多个下游系统，例如：
- Elasticsearch：用于日志搜索与分析
- HDFS / 对象存储：用于长期归档
- 实时计算引擎：用于流式处理
- 数据库：用于业务分析

Kafka 作为数据管道，可以接收来自多个生产者的数据，并让多个消费者组独立消费，从而实现数据的“一次写入，多处消费”。同时，Kafka 的高吞吐和持久化能力保证了数据不丢失，并能在峰值时缓冲数据。

**Kafka 角色**：数据管道（消息总线）

**Spring Kafka 关键点**：
- 生产者：可配置批量发送（`linger.ms`、`batch.size`）以提高吞吐，同时可根据业务选择 `acks` 级别。
- 消费者：不同消费者组可以独立消费同一主题，实现数据分发；每个消费者可根据下游写入能力调整消费速率（`max.poll.records`、`concurrency`）。
- 序列化：通常使用 JSON 格式，便于下游解析。

---

### 完整代码示例：日志收集管道

#### 1. 项目结构
```
src/main/java/com/example/datapipe/
├── DataPipeApplication.java          # 启动类
├── controller/
│   └── LogController.java            # 接收日志的HTTP接口
├── dto/
│   └── LogEntry.java                 # 日志实体
├── service/
│   ├── LogProducerService.java       # 发送日志到Kafka
│   └── consumers/
│       ├── ElasticsearchConsumer.java # 写入Elasticsearch的消费者
│       └── HdfsConsumer.java          # 写入HDFS的消费者
└── config/
    └── KafkaConfig.java               # 可选的配置类（如需自定义）
```

#### 2. 依赖（pom.xml）
```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.2.0</version>
</parent>

<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.kafka</groupId>
        <artifactId>spring-kafka</artifactId>
    </dependency>
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
</dependencies>
```

#### 3. 配置文件 `application.yml`
```yaml
spring:
  kafka:
    bootstrap-servers: 172.18.24.79:9092,172.18.24.79:9093,172.18.24.79:9094
    producer:
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
      # 数据管道生产者配置：高吞吐，适当批量
      acks: 1                     # 等待leader确认，平衡可靠性与吞吐
      linger-ms: 10               # 延迟10ms发送，便于批量
      batch-size: 16384           # 批次大小
      compression-type: snappy    # 可选压缩，节省带宽
    consumer:
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.springframework.kafka.support.serializer.JsonDeserializer
      properties:
        spring.json.trusted.packages: "*"
      auto-offset-reset: earliest
      enable-auto-commit: false   # 手动提交，确保至少一次
      max-poll-records: 100       # 每次拉取100条，可调
    listener:
      ack-mode: manual            # 手动确认

# 主题名称
app:
  kafka:
    log-topic: app-logs
```

#### 4. 日志实体类
```java
package com.example.datapipe.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LogEntry {
    private String level;       // INFO, WARN, ERROR
    private String service;     // 服务名称
    private String message;
    private LocalDateTime timestamp;
}
```

#### 5. 生产者服务
```java
package com.example.datapipe.service;

import com.example.datapipe.dto.LogEntry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class LogProducerService {

    private final KafkaTemplate<String, LogEntry> kafkaTemplate;

    @Value("${app.kafka.log-topic}")
    private String topic;

    /**
     * 异步发送日志到Kafka
     */
    public void sendLog(LogEntry logEntry) {
        // 使用服务名作为key，同一服务的日志进入同一分区（可选）
        kafkaTemplate.send(topic, logEntry.getService(), logEntry)
                .whenComplete((result, ex) -> {
                    if (ex == null) {
                        log.debug("日志发送成功: service={}, level={}, offset={}",
                                logEntry.getService(), logEntry.getLevel(),
                                result.getRecordMetadata().offset());
                    } else {
                        log.error("日志发送失败: {}", logEntry, ex);
                    }
                });
    }
}
```

#### 6. 消费者1：写入 Elasticsearch（模拟）
```java
package com.example.datapipe.service.consumers;

import com.example.datapipe.dto.LogEntry;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ElasticsearchConsumer {

    @KafkaListener(topics = "${app.kafka.log-topic}",
                   groupId = "es-consumer-group",
                   containerFactory = "kafkaListenerContainerFactory")
    public void consume(ConsumerRecord<String, LogEntry> record, Acknowledgment ack) {
        LogEntry logEntry = record.value();
        // 模拟写入 Elasticsearch
        log.info("写入Elasticsearch: service={}, level={}, message={}",
                logEntry.getService(), logEntry.getLevel(), logEntry.getMessage());
        // 实际中这里调用ES客户端索引文档
        // 处理成功后手动确认
        ack.acknowledge();
    }
}
```

#### 7. 消费者2：写入 HDFS（模拟）
```java
package com.example.datapipe.service.consumers;

import com.example.datapipe.dto.LogEntry;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class HdfsConsumer {

    @KafkaListener(topics = "${app.kafka.log-topic}",
                   groupId = "hdfs-consumer-group",
                   containerFactory = "kafkaListenerContainerFactory")
    public void consume(ConsumerRecord<String, LogEntry> record, Acknowledgment ack) {
        LogEntry logEntry = record.value();
        // 模拟写入 HDFS
        log.info("写入HDFS: service={}, level={}, message={}",
                logEntry.getService(), logEntry.getLevel(), logEntry.getMessage());
        // 实际中这里写文件或调用HDFS API
        ack.acknowledge();
    }
}
```

#### 8. 控制器（接收HTTP日志）
```java
package com.example.datapipe.controller;

import com.example.datapipe.dto.LogEntry;
import com.example.datapipe.service.LogProducerService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/logs")
@RequiredArgsConstructor
public class LogController {

    private final LogProducerService logProducerService;

    @PostMapping
    public String sendLog(@RequestBody LogEntry logEntry) {
        // 补充时间戳
        if (logEntry.getTimestamp() == null) {
            logEntry.setTimestamp(LocalDateTime.now());
        }
        logProducerService.sendLog(logEntry);
        return "日志已接收";
    }
}
```

#### 9. 启动类
```java
package com.example.datapipe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataPipeApplication {
    public static void main(String[] args) {
        SpringApplication.run(DataPipeApplication.class, args);
    }
}
```

---

### 运行与测试

#### 1. 启动 Kafka 集群
确保三节点 Kafka 已运行（IP 172.18.24.79，端口 9092-9094）。

#### 2. 启动 Spring Boot 应用

#### 3. 发送日志消息
使用 curl 或 Postman 发送 POST 请求：
```bash
curl -X POST http://localhost:8080/logs \
  -H "Content-Type: application/json" \
  -d '{"level":"INFO","service":"order-service","message":"用户下单成功"}'
```

#### 4. 观察日志
控制台会输出两个消费者的日志：
```
写入Elasticsearch: service=order-service, level=INFO, message=用户下单成功
写入HDFS: service=order-service, level=INFO, message=用户下单成功
```
说明同一份数据被两个消费者组分别消费，实现了数据分发。

#### 5. 批量发送测试
为了提高吞吐，可以模拟发送大量日志（例如循环发送）。Kafka 生产者会按照配置批量发送，减少网络开销。观察生产者日志中的批量效果（可开启 debug 日志）。

---

### 数据管道关键点解析

#### 1. 多消费者组实现数据分发
- 两个消费者使用不同的 `groupId`（`es-consumer-group` 和 `hdfs-consumer-group`），它们独立消费同一主题的所有分区，互不影响。
- 每个消费者组内部的多个消费者（若设置 `concurrency` > 1）会分摊分区，实现并行消费。

#### 2. 批量发送优化
- `linger.ms=10`：生产者在发送前等待最多10ms，以累积更多消息形成批次，提高吞吐。
- `batch.size=16384`：批次大小，达到该大小时也会立即发送。
- `compression-type=snappy`：压缩消息，节省带宽和存储。

#### 3. 手动提交确保至少一次
- `enable-auto-commit=false` 和手动 `ack.acknowledge()` 确保消息被成功写入下游后才提交偏移量，避免数据丢失（但可能导致重复消费，需幂等处理）。

#### 4. 限流保护下游
- 消费者可以通过 `max-poll-records` 控制每次拉取的消息数，避免一次性拉取过多导致下游压力过大。
- 如果下游写入较慢，可以适当降低 `concurrency` 或增加处理时间。

#### 5. 扩展性
- 如果需要增加新的存储（如 Redis、数据库），只需新增一个消费者组，无需修改生产者和已有消费者，完全解耦。

---

### 进阶：数据管道中的错误处理与死信

在实际数据管道中，如果某个消费者处理失败（例如 ES 连接异常），可以配置重试和死信队列，避免阻塞正常消费。这可以复用之前学习的 `DefaultErrorHandler` 和 `DeadLetterPublishingRecoverer`。例如，为 ElasticsearchConsumer 单独配置错误处理器，将失败消息发送到死信主题，以便后续补偿。

---

通过这个示例，你已经体验了 Kafka 作为数据管道的典型用法：统一收集数据，然后分发到多个下游系统，并利用批量和限流优化性能。

压力测试结果：
![[Pasted image 20260326165532.png]]
![[Pasted image 20260326165551.png]]