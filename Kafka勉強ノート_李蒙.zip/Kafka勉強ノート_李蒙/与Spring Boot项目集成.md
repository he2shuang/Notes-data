
pom文件中引入
```
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-kafka</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-kafka-test</artifactId>
            <scope>test</scope>
        </dependency>
```



```
    private final KafkaTemplate<String, OrderEvent> kafkaTemplate;
    private static final String TOPIC_ORDERS = "orders";
  
    /**
     * 发送消息（异步）
     */
    public String sendOrder(OrderEvent order) {
        CompletableFuture<SendResult<String, OrderEvent>> future =
            kafkaTemplate.send(TOPIC_ORDERS, order.getUserId(), order);
        future.whenComplete((result, ex) -> {
            if (ex == null) {
                log.info("消息发送成功: orderId={}, partition={}, offset={}",
                    order.getOrderId(),
                    result.getRecordMetadata().partition(),
                    result.getRecordMetadata().offset());
            } else {
                log.error("消息发送失败: orderId={}", order.getOrderId(), ex);
            }
        });
        return null;
    }
```

**解释**：
- `kafkaTemplate.send(topic, key, data)` 发送一条消息到指定主题。key 用于决定消息进入哪个分区（相同 key 进同一分区）。
- 发送是异步的，默认会立即返回，实际发送在后台完成。


```
    @KafkaListener(
        topics = "orders",
        groupId = "order-group"
    )
    public void consumeOrder(ConsumerRecord<String, OrderEvent> record,
                             Acknowledgment ack) {
        try {
            OrderEvent order = record.value();
            log.info("收到订单消息: orderId={}, userId={}, amount={}, partition={}, offset={}",
                order.getOrderId(),
                order.getUserId(),
                order.getAmount(),
                record.partition(),
                record.offset());
            // 模拟业务处理
            processOrder(order);
            // 手动确认消息
            ack.acknowledge();
            log.info("订单处理完成: orderId={}", order.getOrderId());
        } catch (Exception e) {
            log.error("订单处理失败: {}", e.getMessage(), e);

            // 不确认消息，会触发重试机制
            // 注意：不调用 ack.acknowledge() 即可
        }
    }
```

**解释**：
- `@KafkaListener` 指定要监听的主题（`topics`）和消费者组（`groupId`）。同一个组内的消费者会分摊分区消费。
- 方法参数可以是 `ConsumerRecord`，它包含了消息的元数据（如分区、偏移量）和值。也可以直接写 `Order order`，但这样会丢失元数据，一般用 `ConsumerRecord`。
- 当消息到达时，该方法被自动调用。