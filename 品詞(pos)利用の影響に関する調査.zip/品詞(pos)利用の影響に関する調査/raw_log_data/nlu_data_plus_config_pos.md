POSを使用し、学習データで中国語の人名を含む
# models/nlu_data_plus_config_pos
```
limeng@DESKTOP-7QBIGNU:~/rasa-opensource/rasa-has-pos-or-not$ rasa shell nlu --model models/nlu_data_plus_config_pos
/usr/local/lib/python3.10/dist-packages/rasa/core/tracker_store.py:1044: MovedIn20Warning: Deprecated API features detected! These feature(s) are not compatible with SQLAlchemy 2.0. To prevent incompatible upgrades prior to updating applications, ensure requirements files are pinned to "sqlalchemy<2.0". Set environment variable SQLALCHEMY_WARN_20=1 to show all deprecation warnings.  Set environment variable SQLALCHEMY_SILENCE_UBER_WARNING=1 to silence this message. (Background on SQLAlchemy 2.0 at: https://sqlalche.me/e/b8d9)
  Base: DeclarativeMeta = declarative_base()
/usr/local/lib/python3.10/dist-packages/rasa/shared/utils/validation.py:134: DeprecationWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html
  import pkg_resources
/usr/local/lib/python3.10/dist-packages/pkg_resources/__init__.py:3117: DeprecationWarning: Deprecated call to `pkg_resources.declare_namespace('mpl_toolkits')`.
Implementing implicit namespace packages (as specified in PEP 420) is preferred to `pkg_resources.declare_namespace`. See https://setuptools.pypa.io/en/latest/references/keywords.html#keyword-namespace-packages
  declare_namespace(pkg)
/usr/local/lib/python3.10/dist-packages/pkg_resources/__init__.py:3117: DeprecationWarning: Deprecated call to `pkg_resources.declare_namespace('ruamel')`.
Implementing implicit namespace packages (as specified in PEP 420) is preferred to `pkg_resources.declare_namespace`. See https://setuptools.pypa.io/en/latest/references/keywords.html#keyword-namespace-packages
  declare_namespace(pkg)
/usr/local/lib/python3.10/dist-packages/pkg_resources/__init__.py:3117: DeprecationWarning: Deprecated call to `pkg_resources.declare_namespace('zope')`.
Implementing implicit namespace packages (as specified in PEP 420) is preferred to `pkg_resources.declare_namespace`. See https://setuptools.pypa.io/en/latest/references/keywords.html#keyword-namespace-packages
  declare_namespace(pkg)
/usr/local/lib/python3.10/dist-packages/tensorflow/lite/python/util.py:52: DeprecationWarning: jax.xla_computation is deprecated. Please use the AOT APIs.
  from jax import xla_computation as _xla_computation
2025-10-20 10:59:20 INFO     rasa.core.processor  - Loading model models/nlu_data_plus_config_pos/nlu-20251020-104712-heather-transit.tar.gz...
2025-10-20 10:59:20 INFO     rasa.nlu.utils.spacy_utils  - Trying to load SpaCy model with name 'ja_ginza'.
/usr/local/lib/python3.10/dist-packages/typer/completion.py:122: DeprecationWarning: 'BaseCommand' is deprecated and will be removed in Click 9.0. Use 'Command' instead.
  cli: click.BaseCommand,
/home/limeng/.local/lib/python3.10/site-packages/spacy/cli/_util.py:23: DeprecationWarning: Importing 'parser.split_arg_string' is deprecated, it will only be available in 'shell_completion' in Click 9.0.
  from click.parser import split_arg_string
/home/limeng/.local/lib/python3.10/site-packages/weasel/util/config.py:8: DeprecationWarning: Importing 'parser.split_arg_string' is deprecated, it will only be available in 'shell_completion' in Click 9.0.
  from click.parser import split_arg_string
2025-10-20 10:59:22 INFO     rasa.nlu.utils.spacy_utils  - Trying to load SpaCy model with name 'ja_ginza'.
/usr/local/lib/python3.10/dist-packages/rasa/utils/train_utils.py:530: UserWarning: constrain_similarities is set to `False`. It is recommended to set it to `True` when using cross-entropy loss.
  rasa.shared.utils.io.raise_warning(
NLU model loaded. Type a message and press enter to parse it.
Next message:
木村 光一さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "木村",
  "start": 0,
  "end": 2,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "木村"
}
--- Token 2 ---
{
  "text": "光一",
  "start": 3,
  "end": 5,
  "data": {
    "pos": "名詞-固有名詞-人名-名"
  },
  "lemma": "光一"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 5,
  "end": 7,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 7,
  "end": 8,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 8,
  "end": 10,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 10,
  "end": 11,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 11,
  "end": 13,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 13,
  "end": 15,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 15,
  "end": 16,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "木村 光一さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999996423721313
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 5,
      "confidence_entity": 0.9747660160064697,
      "value": "木村 光一",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      2
    ],
    [
      3,
      5
    ],
    [
      5,
      7
    ],
    [
      7,
      8
    ],
    [
      8,
      10
    ],
    [
      10,
      11
    ],
    [
      11,
      13
    ],
    [
      13,
      15
    ],
    [
      15,
      16
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999996423721313
    },
    {
      "name": "deny",
      "confidence": 2.2034191715647466e-07
    },
    {
      "name": "affirm",
      "confidence": 1.3500249451681157e-07
    }
  ]
}
Next message:
徐 丹さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "徐",
  "start": 0,
  "end": 1,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "徐"
}
--- Token 2 ---
{
  "text": "丹",
  "start": 2,
  "end": 3,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "丹"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 3,
  "end": 5,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 5,
  "end": 6,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 6,
  "end": 8,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 8,
  "end": 9,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 9,
  "end": 11,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 11,
  "end": 13,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 13,
  "end": 14,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "徐 丹さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999998807907104
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 1,
      "confidence_entity": 0.8015062212944031,
      "value": "徐",
      "extractor": "DIETClassifier"
    },
    {
      "entity": "recipient",
      "start": 2,
      "end": 3,
      "confidence_entity": 0.6070417761802673,
      "value": "丹",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      1
    ],
    [
      2,
      3
    ],
    [
      3,
      5
    ],
    [
      5,
      6
    ],
    [
      6,
      8
    ],
    [
      8,
      9
    ],
    [
      9,
      11
    ],
    [
      11,
      13
    ],
    [
      13,
      14
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999998807907104
    },
    {
      "name": "affirm",
      "confidence": 9.247008136981094e-08
    },
    {
      "name": "deny",
      "confidence": 1.7266419405359557e-08
    }
  ]
}
Next message:
Jimに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "jim",
  "start": 0,
  "end": 3,
  "data": {
    "pos": "名詞-普通名詞-一般"
  },
  "lemma": "jim"
}
--- Token 2 ---
{
  "text": "に",
  "start": 3,
  "end": 4,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 3 ---
{
  "text": "送金",
  "start": 4,
  "end": 6,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 4 ---
{
  "text": "し",
  "start": 6,
  "end": 7,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 5 ---
{
  "text": "たい",
  "start": 7,
  "end": 9,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 6 ---
{
  "text": "です",
  "start": 9,
  "end": 11,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 7 ---
{
  "text": "。",
  "start": 11,
  "end": 12,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "Jimに送金したいです。",
  "intent": {
    "name": "deny",
    "confidence": 0.7546175718307495
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 3,
      "confidence_entity": 0.7976717352867126,
      "value": "Jim",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      3
    ],
    [
      3,
      4
    ],
    [
      4,
      6
    ],
    [
      6,
      7
    ],
    [
      7,
      9
    ],
    [
      9,
      11
    ],
    [
      11,
      12
    ]
  ],
  "intent_ranking": [
    {
      "name": "deny",
      "confidence": 0.7546175718307495
    },
    {
      "name": "transfer_money",
      "confidence": 0.24497516453266144
    },
    {
      "name": "affirm",
      "confidence": 0.00040729239117354155
    }
  ]
}
Next message:
100に送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "100",
  "start": 0,
  "end": 3,
  "data": {
    "pos": "名詞-数詞"
  },
  "lemma": "100"
}
--- Token 2 ---
{
  "text": "に",
  "start": 3,
  "end": 4,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 3 ---
{
  "text": "送金",
  "start": 4,
  "end": 6,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 4 ---
{
  "text": "し",
  "start": 6,
  "end": 7,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 5 ---
{
  "text": "たい",
  "start": 7,
  "end": 9,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 6 ---
{
  "text": "です",
  "start": 9,
  "end": 11,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 7 ---
{
  "text": "。",
  "start": 11,
  "end": 12,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "100に送金したいです。",
  "intent": {
    "name": "deny",
    "confidence": 0.8509508371353149
  },
  "entities": [],
  "text_tokens": [
    [
      0,
      3
    ],
    [
      3,
      4
    ],
    [
      4,
      6
    ],
    [
      6,
      7
    ],
    [
      7,
      9
    ],
    [
      9,
      11
    ],
    [
      11,
      12
    ]
  ],
  "intent_ranking": [
    {
      "name": "deny",
      "confidence": 0.8509508371353149
    },
    {
      "name": "transfer_money",
      "confidence": 0.14842452108860016
    },
    {
      "name": "affirm",
      "confidence": 0.0006246131961233914
    }
  ]
}
Next message:
Nancy Davisさんに送金したく思っています。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "nancy",
  "start": 0,
  "end": 5,
  "data": {
    "pos": "名詞-普通名詞-一般"
  },
  "lemma": "nancy"
}
--- Token 2 ---
{
  "text": "davis",
  "start": 6,
  "end": 11,
  "data": {
    "pos": "名詞-固有名詞-人名-一般"
  },
  "lemma": "Davis"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 11,
  "end": 13,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 13,
  "end": 14,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 14,
  "end": 16,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 16,
  "end": 17,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たく",
  "start": 17,
  "end": 19,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "思っ",
  "start": 19,
  "end": 21,
  "data": {
    "pos": "動詞-一般"
  },
  "lemma": "思う"
}
--- Token 9 ---
{
  "text": "て",
  "start": 21,
  "end": 22,
  "data": {
    "pos": "助詞-接続助詞"
  },
  "lemma": "て"
}
--- Token 10 ---
{
  "text": "い",
  "start": 22,
  "end": 23,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "いる"
}
--- Token 11 ---
{
  "text": "ます",
  "start": 23,
  "end": 25,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "ます"
}
--- Token 12 ---
{
  "text": "。",
  "start": 25,
  "end": 26,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "Nancy Davisさんに送金したく思っています。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999997615814209
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 11,
      "confidence_entity": 0.596095085144043,
      "value": "Nancy Davis",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      5
    ],
    [
      6,
      11
    ],
    [
      11,
      13
    ],
    [
      13,
      14
    ],
    [
      14,
      16
    ],
    [
      16,
      17
    ],
    [
      17,
      19
    ],
    [
      19,
      21
    ],
    [
      21,
      22
    ],
    [
      22,
      23
    ],
    [
      23,
      25
    ],
    [
      25,
      26
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999997615814209
    },
    {
      "name": "affirm",
      "confidence": 1.858137466115295e-07
    },
    {
      "name": "deny",
      "confidence": 5.9515908645835225e-08
    }
  ]
}
Next message:

```

##### 补充实验
```
Next message:
方志文さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "方",
  "start": 0,
  "end": 1,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "方"
}
--- Token 2 ---
{
  "text": "志文",
  "start": 1,
  "end": 3,
  "data": {
    "pos": "名詞-固有名詞-人名-名"
  },
  "lemma": "志文"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 3,
  "end": 5,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 5,
  "end": 6,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 6,
  "end": 8,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 8,
  "end": 9,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 9,
  "end": 11,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 11,
  "end": 13,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 13,
  "end": 14,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "方志文さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999997615814209
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 1,
      "end": 3,
      "confidence_entity": 0.9669386744499207,
      "value": "志文",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      1
    ],
    [
      1,
      3
    ],
    [
      3,
      5
    ],
    [
      5,
      6
    ],
    [
      6,
      8
    ],
    [
      8,
      9
    ],
    [
      9,
      11
    ],
    [
      11,
      13
    ],
    [
      13,
      14
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999997615814209
    },
    {
      "name": "affirm",
      "confidence": 1.3198250314871984e-07
    },
    {
      "name": "deny",
      "confidence": 6.95122963634276e-08
    }
  ]
}
Next message:
潘智さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "潘",
  "start": 0,
  "end": 1,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "潘"
}
--- Token 2 ---
{
  "text": "智",
  "start": 1,
  "end": 2,
  "data": {
    "pos": "名詞-固有名詞-人名-名"
  },
  "lemma": "智"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 2,
  "end": 4,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 4,
  "end": 5,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 5,
  "end": 7,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 7,
  "end": 8,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 8,
  "end": 10,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 10,
  "end": 12,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 12,
  "end": 13,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "潘智さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999997615814209
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 2,
      "confidence_entity": 0.994026780128479,
      "value": "潘智",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      1
    ],
    [
      1,
      2
    ],
    [
      2,
      4
    ],
    [
      4,
      5
    ],
    [
      5,
      7
    ],
    [
      7,
      8
    ],
    [
      8,
      10
    ],
    [
      10,
      12
    ],
    [
      12,
      13
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999997615814209
    },
    {
      "name": "affirm",
      "confidence": 1.194674439375376e-07
    },
    {
      "name": "deny",
      "confidence": 7.998986006896303e-08
    }
  ]
}
Next message:
董　辰氷さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "董",
  "start": 0,
  "end": 1,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "董"
}
--- Token 2 ---
{
  "text": "辰",
  "start": 2,
  "end": 3,
  "data": {
    "pos": "名詞-普通名詞-一般"
  },
  "lemma": "辰"
}
--- Token 3 ---
{
  "text": "氷",
  "start": 3,
  "end": 4,
  "data": {
    "pos": "名詞-普通名詞-一般"
  },
  "lemma": "氷"
}
--- Token 4 ---
{
  "text": "さん",
  "start": 4,
  "end": 6,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 5 ---
{
  "text": "に",
  "start": 6,
  "end": 7,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 6 ---
{
  "text": "送金",
  "start": 7,
  "end": 9,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 7 ---
{
  "text": "し",
  "start": 9,
  "end": 10,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 8 ---
{
  "text": "たい",
  "start": 10,
  "end": 12,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 9 ---
{
  "text": "です",
  "start": 12,
  "end": 14,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 10 ---
{
  "text": "。",
  "start": 14,
  "end": 15,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "董　辰氷さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 1.0
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 4,
      "confidence_entity": 0.7000789046287537,
      "value": "董　辰氷",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      1
    ],
    [
      2,
      3
    ],
    [
      3,
      4
    ],
    [
      4,
      6
    ],
    [
      6,
      7
    ],
    [
      7,
      9
    ],
    [
      9,
      10
    ],
    [
      10,
      12
    ],
    [
      12,
      14
    ],
    [
      14,
      15
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 1.0
    },
    {
      "name": "affirm",
      "confidence": 5.255277457649754e-08
    },
    {
      "name": "deny",
      "confidence": 5.8063069907632325e-09
    }
  ]
}
Next message:
王 岩さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "王",
  "start": 0,
  "end": 1,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "王"
}
--- Token 2 ---
{
  "text": "岩",
  "start": 2,
  "end": 3,
  "data": {
    "pos": "名詞-固有名詞-人名-名"
  },
  "lemma": "岩"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 3,
  "end": 5,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 5,
  "end": 6,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 6,
  "end": 8,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 8,
  "end": 9,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 9,
  "end": 11,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 11,
  "end": 13,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 13,
  "end": 14,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "王 岩さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999997615814209
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 3,
      "confidence_entity": 0.9663116931915283,
      "value": "王 岩",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      1
    ],
    [
      2,
      3
    ],
    [
      3,
      5
    ],
    [
      5,
      6
    ],
    [
      6,
      8
    ],
    [
      8,
      9
    ],
    [
      9,
      11
    ],
    [
      11,
      13
    ],
    [
      13,
      14
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999997615814209
    },
    {
      "name": "affirm",
      "confidence": 1.5395410457585967e-07
    },
    {
      "name": "deny",
      "confidence": 9.890247554267262e-08
    }
  ]
}
Next message:
王健さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "王",
  "start": 0,
  "end": 1,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "王"
}
--- Token 2 ---
{
  "text": "健",
  "start": 1,
  "end": 2,
  "data": {
    "pos": "名詞-固有名詞-人名-名"
  },
  "lemma": "健"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 2,
  "end": 4,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 4,
  "end": 5,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 5,
  "end": 7,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 7,
  "end": 8,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 8,
  "end": 10,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 10,
  "end": 12,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 12,
  "end": 13,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "王健さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999997615814209
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 2,
      "confidence_entity": 0.9957417249679565,
      "value": "王健",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      1
    ],
    [
      1,
      2
    ],
    [
      2,
      4
    ],
    [
      4,
      5
    ],
    [
      5,
      7
    ],
    [
      7,
      8
    ],
    [
      8,
      10
    ],
    [
      10,
      12
    ],
    [
      12,
      13
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999997615814209
    },
    {
      "name": "deny",
      "confidence": 1.4576109208519483e-07
    },
    {
      "name": "affirm",
      "confidence": 1.2494888323999476e-07
    }
  ]
}
Next message:
```

