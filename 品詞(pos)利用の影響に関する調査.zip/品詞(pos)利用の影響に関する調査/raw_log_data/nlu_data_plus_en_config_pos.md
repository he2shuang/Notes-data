POSを使用し、学習データで中国語の人名と英語の人名を含む
# models/nlu_data_plus_en_config_pos

```
limeng@DESKTOP-7QBIGNU:~/rasa-opensource/rasa-has-pos-or-not$ rasa shell nlu --model models/nlu_data_plus_en_config_pos
/usr/local/lib/python3.10/dist-packages/rasa/core/tracker_store.py:1044: MovedIn20Warning: Deprecated API features detected! These feature(s) are not compatible with SQLAlchemy 2.0. To prevent incompatible upgrades prior to updating applications, ensure requirements files are pinned to "sqlalchemy<2.0". Set environment variable SQLALCHEMY_WARN_20=1 to show all deprecation warnings.  Set environment variable SQLALCHEMY_SILENCE_UBER_WARNING=1 to silence this message. (Background on SQLAlchemy 2.0 at: https://sqlalche.me/e/b8d9)
  Base: DeclarativeMeta = declarative_base()
/usr/local/lib/python3.10/dist-packages/rasa/shared/utils/validation.py:134: DeprecationWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html
  import pkg_resources
/usr/local/lib/python3.10/dist-packages/pkg_resources/__init__.py:3117: DeprecationWarning: Deprecated call to `pkg_resources.declare_namespace('mpl_toolkits')`.
Implementing implicit namespace packages (as specified in PEP 420) is preferred to `pkg_resources.declare_namespace`. See https://setuptools.pypa.io/en/latest/references/keywords.html#keyword-namespace-packages
  declare_namespace(pkg)
/usr/local/lib/python3.10/dist-packages/pkg_resources/__init__.py:3117: DeprecationWarning: Deprecated call to `pkg_resources.declare_namespace('ruamel')`.
Implementing implicit namespace packages (as specified in PEP 420) is preferred to `pkg_resources.declare_namespace`. See https://setuptools.pypa.io/en/latest/references/keywords.html#keyword-namespace-packages
  declare_namespace(pkg)
/usr/local/lib/python3.10/dist-packages/pkg_resources/__init__.py:3117: DeprecationWarning: Deprecated call to `pkg_resources.declare_namespace('zope')`.
Implementing implicit namespace packages (as specified in PEP 420) is preferred to `pkg_resources.declare_namespace`. See https://setuptools.pypa.io/en/latest/references/keywords.html#keyword-namespace-packages
  declare_namespace(pkg)
/usr/local/lib/python3.10/dist-packages/tensorflow/lite/python/util.py:52: DeprecationWarning: jax.xla_computation is deprecated. Please use the AOT APIs.
  from jax import xla_computation as _xla_computation
2025-10-31 11:05:35 INFO     rasa.core.processor  - Loading model models/nlu_data_plus_en_config_pos/nlu-20251031-110329-faded-appraisal.tar.gz...
2025-10-31 11:05:35 INFO     rasa.nlu.utils.spacy_utils  - Trying to load SpaCy model with name 'ja_ginza'.
/usr/local/lib/python3.10/dist-packages/typer/completion.py:122: DeprecationWarning: 'BaseCommand' is deprecated and will be removed in Click 9.0. Use 'Command' instead.
  cli: click.BaseCommand,
/home/limeng/.local/lib/python3.10/site-packages/spacy/cli/_util.py:23: DeprecationWarning: Importing 'parser.split_arg_string' is deprecated, it will only be available in 'shell_completion' in Click 9.0.
  from click.parser import split_arg_string
/home/limeng/.local/lib/python3.10/site-packages/weasel/util/config.py:8: DeprecationWarning: Importing 'parser.split_arg_string' is deprecated, it will only be available in 'shell_completion' in Click 9.0.
  from click.parser import split_arg_string
2025-10-31 11:05:37 INFO     rasa.nlu.utils.spacy_utils  - Trying to load SpaCy model with name 'ja_ginza'.
/usr/local/lib/python3.10/dist-packages/rasa/utils/train_utils.py:530: UserWarning: constrain_similarities is set to `False`. It is recommended to set it to `True` when using cross-entropy loss.
  rasa.shared.utils.io.raise_warning(
NLU model loaded. Type a message and press enter to parse it.
Next message:
木村 光一さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "木村",
  "start": 0,
  "end": 2,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "木村"
}
--- Token 2 ---
{
  "text": "光一",
  "start": 3,
  "end": 5,
  "data": {
    "pos": "名詞-固有名詞-人名-名"
  },
  "lemma": "光一"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 5,
  "end": 7,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 7,
  "end": 8,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 8,
  "end": 10,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 10,
  "end": 11,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 11,
  "end": 13,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 13,
  "end": 15,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 15,
  "end": 16,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "木村 光一さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999998807907104
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 5,
      "confidence_entity": 0.9969766139984131,
      "value": "木村 光一",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      2
    ],
    [
      3,
      5
    ],
    [
      5,
      7
    ],
    [
      7,
      8
    ],
    [
      8,
      10
    ],
    [
      10,
      11
    ],
    [
      11,
      13
    ],
    [
      13,
      15
    ],
    [
      15,
      16
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999998807907104
    },
    {
      "name": "deny",
      "confidence": 1.2982273744910344e-07
    },
    {
      "name": "affirm",
      "confidence": 5.9443873823283866e-08
    }
  ]
}
Next message:
潘智さんに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "潘",
  "start": 0,
  "end": 1,
  "data": {
    "pos": "名詞-固有名詞-人名-姓"
  },
  "lemma": "潘"
}
--- Token 2 ---
{
  "text": "智",
  "start": 1,
  "end": 2,
  "data": {
    "pos": "名詞-固有名詞-人名-名"
  },
  "lemma": "智"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 2,
  "end": 4,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 4,
  "end": 5,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 5,
  "end": 7,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 7,
  "end": 8,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たい",
  "start": 8,
  "end": 10,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "です",
  "start": 10,
  "end": 12,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 9 ---
{
  "text": "。",
  "start": 12,
  "end": 13,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "潘智さんに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999997615814209
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 2,
      "confidence_entity": 0.9952529668807983,
      "value": "潘智",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      1
    ],
    [
      1,
      2
    ],
    [
      2,
      4
    ],
    [
      4,
      5
    ],
    [
      5,
      7
    ],
    [
      7,
      8
    ],
    [
      8,
      10
    ],
    [
      10,
      12
    ],
    [
      12,
      13
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999997615814209
    },
    {
      "name": "affirm",
      "confidence": 7.06400911099081e-08
    },
    {
      "name": "deny",
      "confidence": 7.05720850646685e-08
    }
  ]
}
Next message:
Jimに送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "jim",
  "start": 0,
  "end": 3,
  "data": {
    "pos": "名詞-普通名詞-一般"
  },
  "lemma": "jim"
}
--- Token 2 ---
{
  "text": "に",
  "start": 3,
  "end": 4,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 3 ---
{
  "text": "送金",
  "start": 4,
  "end": 6,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 4 ---
{
  "text": "し",
  "start": 6,
  "end": 7,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 5 ---
{
  "text": "たい",
  "start": 7,
  "end": 9,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 6 ---
{
  "text": "です",
  "start": 9,
  "end": 11,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 7 ---
{
  "text": "。",
  "start": 11,
  "end": 12,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "Jimに送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.915153980255127
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 3,
      "confidence_entity": 0.9098818898200989,
      "value": "Jim",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      3
    ],
    [
      3,
      4
    ],
    [
      4,
      6
    ],
    [
      6,
      7
    ],
    [
      7,
      9
    ],
    [
      9,
      11
    ],
    [
      11,
      12
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.915153980255127
    },
    {
      "name": "deny",
      "confidence": 0.0846269354224205
    },
    {
      "name": "affirm",
      "confidence": 0.00021905507310293615
    }
  ]
}
Next message:

{
  "text": "",
  "intent": {
    "name": null,
    "confidence": 0.0
  },
  "entities": [],
  "text_tokens": [],
  "intent_ranking": []
}
Next message:
100に送金したいです。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "100",
  "start": 0,
  "end": 3,
  "data": {
    "pos": "名詞-数詞"
  },
  "lemma": "100"
}
--- Token 2 ---
{
  "text": "に",
  "start": 3,
  "end": 4,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 3 ---
{
  "text": "送金",
  "start": 4,
  "end": 6,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 4 ---
{
  "text": "し",
  "start": 6,
  "end": 7,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 5 ---
{
  "text": "たい",
  "start": 7,
  "end": 9,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 6 ---
{
  "text": "です",
  "start": 9,
  "end": 11,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "です"
}
--- Token 7 ---
{
  "text": "。",
  "start": 11,
  "end": 12,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "100に送金したいです。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9212759137153625
  },
  "entities": [],
  "text_tokens": [
    [
      0,
      3
    ],
    [
      3,
      4
    ],
    [
      4,
      6
    ],
    [
      6,
      7
    ],
    [
      7,
      9
    ],
    [
      9,
      11
    ],
    [
      11,
      12
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9212759137153625
    },
    {
      "name": "deny",
      "confidence": 0.07842010259628296
    },
    {
      "name": "affirm",
      "confidence": 0.00030397510272450745
    }
  ]
}
Next message:
Nancy Davisさんに送金したく思っています。


--- DETAILED SPACYTOKENIZER OUTPUT (from tokenize method) ---
--- Token 1 ---
{
  "text": "nancy",
  "start": 0,
  "end": 5,
  "data": {
    "pos": "名詞-普通名詞-一般"
  },
  "lemma": "nancy"
}
--- Token 2 ---
{
  "text": "davis",
  "start": 6,
  "end": 11,
  "data": {
    "pos": "名詞-固有名詞-人名-一般"
  },
  "lemma": "Davis"
}
--- Token 3 ---
{
  "text": "さん",
  "start": 11,
  "end": 13,
  "data": {
    "pos": "接尾辞-名詞的-一般"
  },
  "lemma": "さん"
}
--- Token 4 ---
{
  "text": "に",
  "start": 13,
  "end": 14,
  "data": {
    "pos": "助詞-格助詞"
  },
  "lemma": "に"
}
--- Token 5 ---
{
  "text": "送金",
  "start": 14,
  "end": 16,
  "data": {
    "pos": "名詞-普通名詞-サ変可能"
  },
  "lemma": "送金"
}
--- Token 6 ---
{
  "text": "し",
  "start": 16,
  "end": 17,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "する"
}
--- Token 7 ---
{
  "text": "たく",
  "start": 17,
  "end": 19,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "たい"
}
--- Token 8 ---
{
  "text": "思っ",
  "start": 19,
  "end": 21,
  "data": {
    "pos": "動詞-一般"
  },
  "lemma": "思う"
}
--- Token 9 ---
{
  "text": "て",
  "start": 21,
  "end": 22,
  "data": {
    "pos": "助詞-接続助詞"
  },
  "lemma": "て"
}
--- Token 10 ---
{
  "text": "い",
  "start": 22,
  "end": 23,
  "data": {
    "pos": "動詞-非自立可能"
  },
  "lemma": "いる"
}
--- Token 11 ---
{
  "text": "ます",
  "start": 23,
  "end": 25,
  "data": {
    "pos": "助動詞"
  },
  "lemma": "ます"
}
--- Token 12 ---
{
  "text": "。",
  "start": 25,
  "end": 26,
  "data": {
    "pos": "補助記号-句点"
  },
  "lemma": "。"
}
--- END OF SPACYTOKENIZER OUTPUT ---


{
  "text": "Nancy Davisさんに送金したく思っています。",
  "intent": {
    "name": "transfer_money",
    "confidence": 0.9999997615814209
  },
  "entities": [
    {
      "entity": "recipient",
      "start": 0,
      "end": 11,
      "confidence_entity": 0.9889418482780457,
      "value": "Nancy Davis",
      "extractor": "DIETClassifier"
    }
  ],
  "text_tokens": [
    [
      0,
      5
    ],
    [
      6,
      11
    ],
    [
      11,
      13
    ],
    [
      13,
      14
    ],
    [
      14,
      16
    ],
    [
      16,
      17
    ],
    [
      17,
      19
    ],
    [
      19,
      21
    ],
    [
      21,
      22
    ],
    [
      22,
      23
    ],
    [
      23,
      25
    ],
    [
      25,
      26
    ]
  ],
  "intent_ranking": [
    {
      "name": "transfer_money",
      "confidence": 0.9999997615814209
    },
    {
      "name": "affirm",
      "confidence": 1.1444159753182248e-07
    },
    {
      "name": "deny",
      "confidence": 6.347724479383032e-08
    }
  ]
}
Next message:

```