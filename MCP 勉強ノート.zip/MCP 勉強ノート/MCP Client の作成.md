# 第一次尝试

[[環境構築#MCP Clientの作成に必要な環境|MCP Client 環境]] を整えた後、`FStdioServerParameters`、`stdio_client` などのライブラリを使用してMCPクライアントを素早く構築することができます。

以下のステップでMCPサーバーを使用するMCPクライアントを構築してテストします：

1. APIキーの設定
    
2. 基本的なクライアント構造の作成
    
3. サーバー接続管理の実装
    
4. クエリ処理ロジックの補完
    
5. 対話型チャット機能の追加
    
6. 実行とテスト


## 设置API密钥

[[環境構築#MCP Clientの作成に必要な環境|MCP Client 環境]] と同じように仮想環境に直接追加することもできますが、より良い方法は `.env` ファイルを使用して管理することです。

`.env` ファイルを作成して保存します：
```
# 実際に使用するLLMに応じて設定方法を決定
# echo "ANTHROPIC_BASE_URL=https://api.deepseek.com/anthropic" > .env
echo "ANTHROPIC_API_KEY=your-api-key-goes-here" > .env
```

`.env` を `.gitignore` に追加します：
```
echo ".env" >> .gitignore
```


## 基本的なクライアント構造の作成

まず、インポートを設定し、基本的なクライアントクラスを作成しましょう：

```
from dotenv import load_dotenv
from anthropic import Anthropic
from mcp import ClientSession, StdioServerParameters, types
from mcp.client.stdio import stdio_client
from typing import List
import asyncio
import nest_asyncio
  
nest_asyncio.apply()
  
load_dotenv()
  
class MCP_ChatBot:
  
    def __init__(self):
        # Initialize session and client objects
        self.session: ClientSession = None
        self.anthropic = Anthropic()
        self.available_tools: List[dict] = []
    # methods will go here
```


## サーバー接続管理の実装

次に、MCPサーバーに接続するメソッドを実装します：

```
async def connect_to_server_and_run(self):
        # Create server parameters for stdio connection
        server_params = StdioServerParameters(
            command="uv",  # Executable
            args=["run", "research_server.py"],  # Optional command line arguments
            env=None,  # Optional environment variables
        )
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                self.session = session
                # Initialize the connection
                await session.initialize()
                # List available tools
                response = await session.list_tools()
                tools = response.tools
                print("\nConnected to server with tools:", [tool.name for tool in tools])
                self.available_tools = [{
                    "name": tool.name,
                    "description": tool.description,
                    "input_schema": tool.inputSchema
                } for tool in response.tools]
                await self.chat_loop()
```

## クエリ処理ロジックの補完

次に、クエリの処理とツール呼び出しの処理を行うコア機能を補完します：

```
    async def process_query(self, query):
        messages = [{'role':'user', 'content':query}]
        response = self.anthropic.messages.create(max_tokens = 2024,
                                      model = 'deepseek-chat',
                                      tools = self.available_tools, # tools exposed to the LLM
                                      messages = messages)
        process_query = True
        while process_query:
            assistant_content = []
            for content in response.content:
                if content.type =='text':
                    print(content.text)
                    assistant_content.append(content)
                    if(len(response.content) == 1):
                        process_query= False
                elif content.type == 'tool_use':
                    assistant_content.append(content)
                    messages.append({'role':'assistant', 'content':assistant_content})
                    tool_id = content.id
                    tool_args = content.input
                    tool_name = content.name
                    print(f"Calling tool {tool_name} with args {tool_args}")
                    # Call a tool
                    #result = execute_tool(tool_name, tool_args): not anymore needed
                    # tool invocation through the client session
                    result = await self.session.call_tool(tool_name, arguments=tool_args)
                    messages.append({"role": "user",
                                      "content": [
                                          {
                                              "type": "tool_result",
                                              "tool_use_id":tool_id,
                                              "content": result.content
                                          }
                                      ]
                                    })
                    response = self.anthropic.messages.create(max_tokens = 2024,
                                      model = 'deepseek-chat',
                                      tools = self.available_tools,
                                      messages = messages)
                    if(len(response.content) == 1 and response.content[0].type == "text"):
                        print(response.content[0].text)
                        process_query= False
```

## 対話型チャット機能の追加

次に、チャットループ機能を追加します：

```
    async def chat_loop(self):
        """Run an interactive chat loop"""
        print("\nMCP Chatbot Started!")
        print("Type your queries or 'quit' to exit.")
        while True:
            try:
                query = input("\nQuery: ").strip()
                if query.lower() == 'quit':
                    break
                await self.process_query(query)
                print("\n")
            except Exception as e:
                print(f"\nError: {str(e)}")
```

最後に、メインの実行ロジックを追加します：
```
async def main():
    chatbot = MCP_ChatBot()
    await chatbot.connect_to_server_and_run()
if __name__ == "__main__":
    asyncio.run(main())
```


## 実行とテスト

上記の内容を整理して `mcp_chatbot.py` ファイルに保存し、以下のコマンドを実行します

```
uv run mcp_chatbot.py
```


以下は実行結果で、ユーザーとの対話プロセスを含みます：  
実行結果から、MCPクライアントはMCPサーバーのツールを正常に使用できます。3と5でそれぞれMCPサーバー内でカスタマイズしたツール「search_papers」と「extract_info」を使用し、正常に結果を返しました。これはMCPクライアントとMCPサーバーを正常に使用できたことを示しています。

|     |         |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| --- | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | chatbot | MCP Chatbot Started!<br>Type your queries or 'quit' to exit.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2   | user    | give me some papers about "AI Agent", 3 is enough                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| 3   | chatbot | I'll search for papers about "AI Agent" and retrieve 3 results for you.<br>Calling tool search_papers with args {'topic': 'AI Agent', 'max_results': 3}<br>Here are 3 papers about "AI Agent" that I found:<br><br>1. **Paper ID: 2501.02842v1**<br>2. **Paper ID: 2503.12687v1** <br>3. **Paper ID: 2509.00961v1**<br><br>Would you like me to get more detailed information about any of these specific papers? I can extract their titles, abstracts, and other metadata for you.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 4   | user    | i want to get information about 2509.00961v1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 5   | chatbot | I'll help you get information about paper 2509.00961v1. Let me search for it across the available directories.<br>Calling tool extract_info with args {'paper_id': '2509.00961v1'}<br>Here's the information about paper 2509.00961v1:<br><br>**Title:** Ultra Strong Machine Learning: Teaching Humans Active Learning Strategies via Automated AI Explanations<br><br>**Authors:** Lun Ai, Johannes Langer, Ute Schmid, Stephen Muggleton<br><br>**Published:** August 31, 2025<br><br>**Summary:** This paper introduces LENS (Logic Programming Explanation via Neural Summarisation), a neuro-symbolic method that combines symbolic program synthesis with large language models (LLMs) to automate the explanation of machine-learned logic programs in natural language. The research focuses on Ultra Strong Machine Learning (USML) systems that can teach their acquired knowledge to improve human performance. The authors conducted systematic evaluations showing that LENS generates superior explanations compared to direct LLM prompting and hand-crafted templates. However, human learning experiments across three domains showed no significant performance improvements, suggesting that comprehensive LLM responses may overwhelm users for simpler problems.<br><br>**PDF URL:** https://arxiv.org/pdf/2509.00961v1<br><br>The source code for this research is available at: https://github.com/lun-ai/LENS.git<br> |
| 6   | user    | quit                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |


```
(first_mcp_project) PS C:\limeng\MCP\workspace\first_mcp_project> uv run mcp_chatbot.py

Connected to server with tools: ['search_papers', 'extract_info']

MCP Chatbot Started!
Type your queries or 'quit' to exit.

Query: give me some papers about "AI Agent", 3 is enough
I'll search for papers about "AI Agent" and retrieve 3 results for you.
Calling tool search_papers with args {'topic': 'AI Agent', 'max_results': 3}
Here are 3 papers about "AI Agent" that I found:

1. **Paper ID: 2501.02842v1**
2. **Paper ID: 2503.12687v1** 
3. **Paper ID: 2509.00961v1**

Would you like me to get more detailed information about any of these specific papers? I can extract their titles, abstracts, and other metadata for you.



Query: i want to get information about 2509.00961v1
I'll help you get information about paper 2509.00961v1. Let me search for it across the available directories.
Calling tool extract_info with args {'paper_id': '2509.00961v1'}
Here's the information about paper 2509.00961v1:

**Title:** Ultra Strong Machine Learning: Teaching Humans Active Learning Strategies via Automated AI Explanations

**Authors:** Lun Ai, Johannes Langer, Ute Schmid, Stephen Muggleton

**Published:** August 31, 2025

**Summary:** This paper introduces LENS (Logic Programming Explanation via Neural Summarisation), a neuro-symbolic method that combines symbolic program synthesis with large language models (LLMs) to automate the explanation of machine-learned logic programs in natural language. The research focuses on Ultra Strong Machine Learning (USML) systems that can teach their acquired knowledge to improve human performance. The authors conducted systematic evaluations showing that LENS generates superior explanations compared to direct LLM prompting and hand-crafted templates. However, human learning experiments across three domains showed no significant performance improvements, suggesting that comprehensive LLM responses may overwhelm users for simpler problems.

**PDF URL:** https://arxiv.org/pdf/2509.00961v1

The source code for this research is available at: https://github.com/lun-ai/LENS.git



Query:quit
```

## 仕組み

クエリを送信すると：

1. クライアントはサーバーから利用可能なツールのリストを取得します
    
2. クエリはツールの説明とともにClaudeに送信されます
    
3. Claudeは使用するツール（ある場合）を決定します
    
4. クライアントはサーバーを通じて要求されたツール呼び出しを実行します
    
5. 結果はClaudeに送り返されます
    
6. Claudeは自然言語による応答を提供します
    
7. 回答があなたに表示されます


# resourcesとpromptの使用

```
from dotenv import load_dotenv
from anthropic import Anthropic
from mcp import ClientSession, StdioServerParameters, types
from mcp.client.stdio import stdio_client
from typing import List, Dict, TypedDict
from contextlib import AsyncExitStack
import json
import asyncio
import nest_asyncio
  
nest_asyncio.apply()
  
load_dotenv()
  

class MCP_ChatBot:
  
    def __init__(self):
        # 初始化会话和客户端对象
        self.exit_stack = AsyncExitStack()
        self.anthropic = Anthropic()
        self.available_tools = []
        self.available_prompts = []
        self.sessions = {}
  
  
    async def connect_to_server(self, server_name: str, server_config: dict) -> None:
        """Connect to a single MCP server."""
        try:
            server_params = StdioServerParameters(**server_config)
            stdio_transport = await self.exit_stack.enter_async_context(
                stdio_client(server_params)
            )
            read, write = stdio_transport
            session = await self.exit_stack.enter_async_context(
                ClientSession(read, write)
            )
            await session.initialize()
  
            # List available tools
            try:
                response = await session.list_tools()
                for tool in response.tools:
                    self.sessions[tool.name] = session
                    self.available_tools.append({
                        "name": tool.name,
                        "description": tool.description,
                        "input_schema": tool.inputSchema
                    })
            # List available prompts
                prompts_response = await session.list_prompts()
                if prompts_response and prompts_response.prompts:
                    for prompt in prompts_response.prompts:
                        self.sessions[prompt.name] = session
                        self.available_prompts.append({
                            "name": prompt.name,
                            "description": prompt.description,
                            "arguments": prompt.arguments
                        })
            # List available resources
                resources_response = await session.list_resources()
                if resources_response and resources_response.resources:
                    for resource in resources_response.resources:
                        resource_uri = str(resource.uri)
                        self.sessions[resource_uri] = session
            except Exception as e:
                print(f"Failed to list tools, prompts, or resources at {server_name}: {e}")
  
        except Exception as e:
            print(f"Failed to connect to {server_name}: {e}")
  
    async def connect_to_servers(self): # new
        """Connect to all configured MCP servers."""
        try:
            with open("server_config.json", "r") as file:
                data = json.load(file)
            servers = data.get("mcpServers", {})
            for server_name, server_config in servers.items():
                await self.connect_to_server(server_name, server_config)
        except Exception as e:
            print(f"Error loading server configuration: {e}")
            raise
    async def process_query(self, query):
        messages = [{'role':'user', 'content':query}]
  
        while True:
            response = self.anthropic.messages.create(max_tokens = 2024,
                                        model = 'deepseek-chat',
                                        tools = self.available_tools,
                                        messages = messages)
            assistant_content = []
            has_tool_use = False
  
            for content in response.content:
                if content.type =='text':
                    print(content.text)
                    assistant_content.append(content)
                elif content.type == 'tool_use':
                    has_tool_use = True
                    assistant_content.append(content)
                    messages.append({'role':'assistant', 'content':assistant_content})
                    # Get session and call tool
                    session = self.sessions.get(content.name)
                    if not session:
                        print(f"Tool {content.name} not found in sessions")
                        break
  
                    result = await session.call_tool(content.name, arguments=content.input)
                    messages.append({"role": "user",
                                    "content": [
                                        {
                                            "type": "tool_result",
                                            "tool_use_id":content.id,
                                            "content": result.content
                                        }
                                    ]
                                    })

            # Exit loop if no tool was used
            if not has_tool_use:
                break                      
  
    async def get_resource(self, resource_uri):
        """Get a resource from the server."""
        session = self.sessions.get(resource_uri)
  
        # Fallback for papers URIS - try any papers resource session
        if not session and resource_uri.startswith("papers://"):
            for uri, sess in self.sessions.items():
                if uri.startswith("papers://"):
                    session = sess
                    break
  
        if not session:
            print(f"Resource {resource_uri} not found in sessions")
            return
        try:
            result = await session.read_resource(uri=resource_uri)
            if result and result.contents:
                print(f"\nResource {resource_uri}")
                print("Content:")
                print(result.contents[0].text)
            else:
                print(f"No content found for resource {resource_uri}")
  
        except Exception as e:
            print(f"Failed to get resource {resource_uri}: {e}")
  
    async def list_prompt(self):
        """List available prompts."""
        if not self.available_prompts:
            print("No prompts available.")
            return
        print("\nAvailable Prompts:")
        for prompt in self.available_prompts:
            # print(f"{prompt.name}: {prompt.description}")
            print(f"{prompt['name']}: {prompt['description']}")
            if prompt['arguments']:
                print(f" Arguments:")
                for arg in prompt['arguments']:
                    arg_name = arg.name if hasattr(arg, 'name') else arg.get('name', '')
                    print(f"  -{arg_name}")
    async def execute_prompt(self, prompt_name, args):
        """Execute a prompt with given arguments."""
        session = self.sessions.get(prompt_name)
        if not session:
            print(f"Prompt {prompt_name} not found in sessions")
            return
        try:
            result = await session.get_prompt(prompt_name, arguments=args)
            if result and result.messages:
                prompt_content = result.messages[0].content

                # Extract text from content (handles different formats)
                if isinstance(prompt_content, str):
                    text = prompt_content
                elif hasattr(prompt_content, 'text'):
                    text = prompt_content.text
                else:
                    # Handle list of content items
                    text = " ".join(item.text if hasattr(item, 'text') else str(item) for item in prompt_content)
                print(f"\nExecuting Prompt '{prompt_name}' ...")
                print(f"\nPrompt Content: {text}")
                await self.process_query(text)  
        except Exception as e:
            print(f"Failed to execute prompt {prompt_name}: {e}")
  
    async def chat_loop(self):
        """Run an interactive chat loop"""
        print("\nMCP Chatbot Started!")
        print("Type your queries or 'quit' to exit.")
        print("Use @folders to see available prompts.")
        print("Use @<topic> to search papers in that topic.")
        print("Use /prompts to lies available prompts.")
        print("Use /prompt <name> <arg1=value1> to execute a prompt.")
        while True:
            try:
                query = input("\nQuery: ").strip()        
  
                if not query:
                    continue
  
                if query.lower() == 'quit':
                    break
  
                # Check for @resource syntax first
                if query.startswith("@"):
                    # remove @ sign
                    topic = query[1:]
                    if topic == "folders":
                        resource_uri = "papers://folders"
                    else:
                        resource_uri = f"papers://{topic}"
                    await self.get_resource(resource_uri)
                    continue
  
                # Check for /command syntax
                if query.startswith('/'):
                    parts = query.split()
                    command = parts[0].lower()
  
                    if command == '/prompts':
                        await self.list_prompt()
                    elif command == '/prompt':
                        if len(parts) < 2:
                            print("Usage: /prompt <name> <arg1=value1> ...")
                            continue
                        prompt_name = parts[1]
                        args = {}
                        # Parse arguments
                        for arg in parts[2:]:
                            if '=' in arg:
                                key, value = arg.split('=', 1)
                                args[key] = value
                        await self.execute_prompt(prompt_name, args)
                    else:
                        print(f"Unknown command: {command}")
                    continue
  
                await self.process_query(query)
                print("\n")
            except Exception as e:
                print(f"\nError: {str(e)}")
    async def cleanup(self): # new
        """Cleanly close all resources using AsyncExitStack."""
        await self.exit_stack.aclose()
  
  
async def main():
    chatbot = MCP_ChatBot()
    try:
        # the mcp clients and sessions are not initialized using "with"
        # like in the previous lesson
        # so the cleanup should be manually handled
        await chatbot.connect_to_servers() # new!
        await chatbot.chat_loop()
    finally:
        await chatbot.cleanup() #new!
  
  
if __name__ == "__main__":
    asyncio.run(main())
```

![[Pasted image 20251223145804.png]]
![[Pasted image 20251223150721.png]]
![[Pasted image 20251223150807.png]]