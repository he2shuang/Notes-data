https://modelcontextprotocol.io/docs/tutorials/security/authorization


## Keycloak

実用的な実装を始めるために、Dockerコンテナでホストされた[Keycloak](https://www.keycloak.org/)認可サーバーを使用します。Keycloakはオープンソースの認可サーバーであり、ローカルで簡単にデプロイしてテストや実験を行うことができます。

Dockerイメージを実行：
```
docker run -p 127.0.0.1:8080:8080 -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin quay.io/keycloak/keycloak start-dev
```

ローカルで`http://localhost:8080`を開き、ユーザー名`admin`、パスワード`admin`でログイン

```
# 停止，删除

docker stop <容器ID>
docker rm <容器ID>
```

## フロー詳細

#### 第一段階：認可コードの取得 (ユーザーログインと認可)

この段階は主に**ブラウザ**と**Keycloak**の間で発生し、VS Code拡張機能によって開始されます。

**ステップ 1: クライアントが認証リクエストを開始**

- **アクション**: VS Codeで認証が必要な操作（例：APIツールの呼び出し）を実行します。
    
- **内部**: VS Code拡張機能はアクセストークンを持っていないことを検知し、バックグラウンドで認証を開始する準備をします。まず秘密の`code_verifier`を生成し、次に`S256`アルゴリズムを使用して`code_challenge`を計算します。
    
- **結果**: 拡張機能が長いURLを構築し、デフォルトブラウザで開きます。
    - **URL**: `http://localhost:8080/.../auth?client_id=vscode-mcp-client&...&code_challenge=...&redirect_uri=...`
    - **意図**: 「こんにちはKeycloak、私は`vscode-mcp-client`です。ユーザーにログインさせ、いくつかの権限をリクエストしたいです。これが私のチャレンジコード(`code_challenge`)です。ユーザーを検証した後、このアドレス(`redirect_uri`)にリダイレクトしてください。」”

**步骤 2: 用户认证与授权**

- **动作**: 浏览器显示出Keycloak的登录页面。你输入用户名和密码。
- **幕后**: 登录成功后，Keycloak可能会显示一个“同意授权”页面，询问你是否允许`vscode-mcp-client`访问你的`mcp:tools`权限。你点击“同意”。
- **结果**: Keycloak确认了你的身份和你的许可。

**步骤 3: Keycloak返回授权码**

- **动作**: Keycloak将你的浏览器重定向到VS Code扩展指定的`redirect_uri`（比如`http://127.0.0.1:33418/`）。
- **幕后**: 在重定向的URL中，Keycloak附上了一个一次性的**授权码 (Authorization Code)** 和之前收到的`state`参数。
- **结果**: 浏览器跳转，VS Code扩展的本地服务器捕获了这个带有授权码的请求。
    - **URL**: `http://127.0.0.1:33418/?code=...&state=...`

**ステップ 2: ユーザー認証と認可**

- **アクション**: ブラウザにKeycloakのログインページが表示されます。ユーザー名とパスワードを入力します。
    
- **内部**: ログイン成功後、Keycloakは「同意して認可する」ページを表示し、`vscode-mcp-client`があなたの`mcp:tools`権限にアクセスすることを許可するかどうかを尋ねます。「同意」をクリックします。
    
- **結果**: Keycloakがあなたの身元と許可を確認します。
    

**ステップ 3: Keycloakが認可コードを返す**

- **アクション**: KeycloakがブラウザをVS Code拡張機能が指定した`redirect_uri`（例：`http://127.0.0.1:33418/`）にリダイレクトします。
    
- **内部**: リダイレクトURLの中で、Keycloakは一回限りの**認可コード (Authorization Code)** と以前に受信した`state`パラメータを添付します。
    
- **結果**: ブラウザがリダイレクトし、VS Code拡張機能のローカルサーバーがこの認可コード付きのリクエストを捕捉します。
    
    - **URL**: `http://127.0.0.1:33418/?code=...&state=...`
        

#### 第二段階：トークンの交換とリソースへのアクセス

この段階は主に**VS Code拡張機能のバックグラウンド**と**Pythonサーバー**の間で発生し、ユーザーは感知しません。

**ステップ 4: クライアントが認可コードでアクセストークンを交換**

- **アクション**: VS Code拡張機能のバックグラウンドプロセスが、Keycloakの**トークンエンドポイント (Token Endpoint)** に`POST`リクエストを送信します。
    
- **内部**: このリクエストはバックグラウンドで送信され、ブラウザには見えません。リクエストには以下が含まれます：
    
    - 今受け取った`authorization_code`
        
    - 自身の`client_id` (`vscode-mcp-client`)
        
    - 最初に生成した秘密の`code_verifier` (これがPKCEセキュリティメカニズムの鍵であり、リクエストを開始したクライアントであることを証明します)
        
- **結果**: Keycloakが`code_verifier`と以前の`code_challenge`が一致するか検証します。一致に成功すると、**アクセストークン (Access Token)** を含むJSONを返します。
    

**ステップ 5: クライアントがトークンを持ってリソースサーバーにアクセス**

- **アクション**: VS Code拡張機能は`Access Token`を手にし、ついにあなたのPython APIにアクセスできます。`http://localhost:3000/`にAPIリクエスト（例：`add_numbers`の呼び出し）を送信します。
    
- **内部**: リクエストの`Authorization`ヘッダーにトークンを添付します。
    
    - **ヘッダー**: `Authorization: Bearer eyJhbGciOiJSUzI1...`
        
- **結果**: あなたのPythonサーバーがこのリクエストを受け取ります。
    

#### 第三段階：リソースサーバーによるトークンの検証

この段階はあなたの**Pythonサーバー**と**Keycloak**の間で発生します。

**ステップ 6: リソースサーバーによるトークンの内省 (Introspection)**

- **アクション**: あなたのPythonサーバー(`IntrospectionTokenVerifier`)がトークンを受け取りますが、このトークンを信頼しません。Keycloakに行ってトークンの真偽を確認する必要があります。
    
- **内部**: あなたのサーバーがKeycloakの**内省エンドポイント (Introspection Endpoint)** に`POST`リクエストを送信します。このリクエストには以下が含まれます：
    
    - 検証する`token`
        
    - **自身の身元情報**: `client_id=mcp-first-client` と `client_secret=...` (これが`confidential`クライアントとそのパスワードが必要な理由です)
        
- **結果**: Keycloakが`mcp-first-client`の情報を検証し、そのサービスアカウントに`read-token`などの権限があるかどうかをチェックします。
    

**ステップ 7: Keycloakが内省結果を返す**

- **アクション**: Keycloakがトークンを検証した後、あなたのPythonサーバーにJSONレスポンスを返します。
    
- **内部**: トークンが有効で、かつ`mcp-first-client`に内省する権限がある場合、Keycloakは`HTTP 200 OK`を返し、レスポンス本文は`{"active": true, ...}`です。
    
- **結果**: あなたのPythonサーバーが`{"active": true}`を受け取ります。
    

**ステップ 8: リソースサーバーが保護されたリソースを返す**

- **アクション**: あなたのPythonサーバーがトークンが有効であることを確認し、`add_numbers`のロジックを実行します。
    
- **内部**: 計算結果をパッケージ化し、JSONレスポンスにします。
    
- **結果**: あなたのサーバーがVS Code拡張機能に`HTTP 200 OK`と計算結果を返します。最終的に、VS CodeのUI上でAPI呼び出しの成功結果が表示されます。

## MCP サーバー設定

実際のサーバーを書く前に、まず`config.py`で設定を行う必要があります——内容は完全にローカルサーバーの設定に基づいています：

```
"""Configuration settings for the MCP auth server."""
  
import os
from typing import Optional
  
  
class Config:
    """Configuration class that loads from environment variables with sensible defaults."""
  
    # Server settings
    HOST: str = os.getenv("HOST", "localhost")
    PORT: int = int(os.getenv("PORT", "3000"))
  
    # Auth server settings
    AUTH_HOST: str = os.getenv("AUTH_HOST", "localhost")
    AUTH_PORT: int = int(os.getenv("AUTH_PORT", "8080"))
    AUTH_REALM: str = os.getenv("AUTH_REALM", "master")
  
    # OAuth client settings
    OAUTH_CLIENT_ID: str = os.getenv("OAUTH_CLIENT_ID", "mcp-first-client")
    OAUTH_CLIENT_SECRET: str = os.getenv("OAUTH_CLIENT_SECRET", "OxZDlvEqeJkludCd3zMEACgzM4LXIayE")
  
    # Server settings
    MCP_SCOPE: str = os.getenv("MCP_SCOPE", "mcp:tools")
    OAUTH_STRICT: bool = os.getenv("OAUTH_STRICT", "false").lower() in ("true", "1", "yes")
    TRANSPORT: str = os.getenv("TRANSPORT", "streamable-http")
  
    @property
    def server_url(self) -> str:
        """Build the server URL."""
        return f"http://{self.HOST}:{self.PORT}"
  
    @property
    def auth_base_url(self) -> str:
        """Build the auth server base URL."""
        return f"http://{self.AUTH_HOST}:{self.AUTH_PORT}/realms/{self.AUTH_REALM}/"
  
    def validate(self) -> None:
        """Validate configuration."""
        if self.TRANSPORT not in ["sse", "streamable-http"]:
            raise ValueError(f"Invalid transport: {self.TRANSPORT}. Must be 'sse' or 'streamable-http'")
  
  
# Global configuration instance
config = Config()
```

サーバーの実装は以下の通りです：

```
import datetime
import logging
from typing import Any
  
from pydantic import AnyHttpUrl
  
from mcp.server.auth.settings import AuthSettings
from mcp.server.fastmcp.server import FastMCP
  
from config import config
from token_verifier import IntrospectionTokenVerifier
  
logger = logging.getLogger(__name__)
  
  
def create_oauth_urls() -> dict[str, str]:
    """Create OAuth URLs based on configuration (Keycloak-style)."""
    from urllib.parse import urljoin
  
    auth_base_url = config.auth_base_url
  
    return {
        "issuer": auth_base_url,
        "introspection_endpoint": urljoin(auth_base_url, "protocol/openid-connect/token/introspect"),
        "authorization_endpoint": urljoin(auth_base_url, "protocol/openid-connect/auth"),
        "token_endpoint": urljoin(auth_base_url, "protocol/openid-connect/token"),
    }
  
  
def create_server() -> FastMCP:
    """Create and configure the FastMCP server."""
  
    config.validate()
  
    oauth_urls = create_oauth_urls()
  
    token_verifier = IntrospectionTokenVerifier(
        introspection_endpoint=oauth_urls["introspection_endpoint"],
        server_url=config.server_url,
        client_id=config.OAUTH_CLIENT_ID,
        client_secret=config.OAUTH_CLIENT_SECRET,
    )
  
    app = FastMCP(
        name="MCP Resource Server",
        instructions="Resource Server that validates tokens via Authorization Server introspection",
        host=config.HOST,
        port=config.PORT,
        debug=True,
        streamable_http_path="/",
        token_verifier=token_verifier,
        auth=AuthSettings(
            issuer_url=AnyHttpUrl(oauth_urls["issuer"]),
            required_scopes=[config.MCP_SCOPE],
            resource_server_url=AnyHttpUrl(config.server_url),
            client_id=config.OAUTH_CLIENT_ID,
        ),
    )
  
    @app.tool()
    async def add_numbers(a: float, b: float) -> dict[str, Any]:
        """
        Add two numbers together.
        This tool demonstrates basic arithmetic operations with OAuth authentication.
  
        Args:
            a: The first number to add
            b: The second number to add
        """
        result = a + b
        return {
            "operation": "addition",
            "operand_a": a,
            "operand_b": b,
            "result": result,
            "timestamp": datetime.datetime.now().isoformat()
        }
  
    @app.tool()
    async def multiply_numbers(x: float, y: float) -> dict[str, Any]:
        """
        Multiply two numbers together.
        This tool demonstrates basic arithmetic operations with OAuth authentication.
  
        Args:
            x: The first number to multiply
            y: The second number to multiply
        """
        result = x * y
        return {
            "operation": "multiplication",
            "operand_x": x,
            "operand_y": y,
            "result": result,
            "timestamp": datetime.datetime.now().isoformat()
        }
  
    return app
  
  
def main() -> int:
    """
    Run the MCP Resource Server.
  
    This server:
    - Provides RFC 9728 Protected Resource Metadata
    - Validates tokens via Authorization Server introspection
    - Serves MCP tools requiring authentication
  
    Configuration is loaded from config.py and environment variables.
    """
    logging.basicConfig(level=logging.INFO)
  
    try:
        config.validate()
        oauth_urls = create_oauth_urls()

    except ValueError as e:
        logger.error("Configuration error: %s", e)
        return 1
  
    try:
        mcp_server = create_server()
  
        logger.info("Starting MCP Server on %s:%s", config.HOST, config.PORT)
        logger.info("Authorization Server: %s", oauth_urls["issuer"])
        logger.info("Transport: %s", config.TRANSPORT)
  
        mcp_server.run(transport=config.TRANSPORT)
        return 0
  
    except Exception:
        logger.exception("Server error")
        return 1
  
  
if __name__ == "__main__":
    exit(main())
```

最後に、トークン検証ロジックは完全に `token_verifier.py` に委任され、Keycloakの内省エンドポイントを利用して任意の資格情報偽造物の有効性を確実に検証できます。
```
"""Token verifier implementation using OAuth 2.0 Token Introspection (RFC 7662)."""
  
import logging
from typing import Any
  
from mcp.server.auth.provider import AccessToken, TokenVerifier
from mcp.shared.auth_utils import check_resource_allowed, resource_url_from_server_url
  
logger = logging.getLogger(__name__)
  
  
class IntrospectionTokenVerifier(TokenVerifier):
    """Token verifier that uses OAuth 2.0 Token Introspection (RFC 7662).
    """
  
    def __init__(
        self,
        introspection_endpoint: str,
        server_url: str,
        client_id: str,
        client_secret: str,
    ):
        self.introspection_endpoint = introspection_endpoint
        self.server_url = server_url
        self.client_id = client_id
        self.client_secret = client_secret
        self.resource_url = resource_url_from_server_url(server_url)
  
    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify token via introspection endpoint."""
        import httpx
  
        # --- 新增的打印点 1: 打印传入的原始令牌 ---
        # print("--- RAW TOKEN RECEIVED BY VERIFIER ---")
        # print(token)
        # print("------------------------------------")
        if not self.introspection_endpoint.startswith(("https://", "http://localhost", "http://127.0.0.1")):
            return None

  
        timeout = httpx.Timeout(10.0, connect=5.0)
        limits = httpx.Limits(max_connections=10, max_keepalive_connections=5)
  
        async with httpx.AsyncClient(
            timeout=timeout,
            limits=limits,
            verify=True,
        ) as client:
            try:
                form_data = {
                    "token": token,
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                }
                headers = {"Content-Type": "application/x-www-form-urlencoded"}
  
                # --- 你已有的打印点: 打印将要发送的请求 ---
                # print("--- DEBUG: Introspection Request ---")
                # print(f"URL: {self.introspection_endpoint}")
                # print(f"Headers: {headers}")
                # print(f"Data: {form_data}")
                # print("------------------------------------")
  
                response = await client.post(
                    self.introspection_endpoint,
                    data=form_data,
                    headers=headers,
                )
                # --- 新增的打印点 2: 打印收到的原始响应 ---
                # print("--- DEBUG: Introspection Response ---")
                # print(f"Status Code: {response.status_code}")
                # try:
                #     # 尝试解析为JSON并打印
                #     response_data = response.json()
                #     print(f"Response JSON: {response_data}")
                # except Exception as json_error:
                #     # 如果不是JSON，打印原始文本
                #     print(f"Response Text: {response.text}")
                #     print(f"JSON Parsing Error: {json_error}")
                # print("-------------------------------------")
  
                if response.status_code != 200:
                    print("DEBUG: Introspection failed due to non-200 status code.")
                    return None
  
                data = response.json()
                if not data.get("active", False):
                    print("DEBUG: Introspection successful, but token is NOT active.")
                    return None
  
                if not self._validate_resource(data):
                    print("DEBUG: Token is active, but resource/audience validation failed.")
                    return None
  
                # 如果一切正常，也会打印一条成功日志
                print("DEBUG: Token is active and resource validation successful. Proceeding.")
                return AccessToken(
                    token=token,
                    client_id=data.get("client_id", "unknown"),
                    scopes=data.get("scope", "").split() if data.get("scope") else [],
                    expires_at=data.get("exp"),
                    # resource=data.get("aud"),  # Include resource in token
                    resource=self.resource_url, # <--- 直接使用我们自己的resource_url
                )
  
            except Exception as e:
                print(f"DEBUG: An exception occurred during token verification: {e}")
                return None
  
    def _validate_resource(self, token_data: dict[str, Any]) -> bool:
        """Validate token was issued for this resource server.
  
        Rules:
        - Reject if 'aud' missing.
        - Accept if any audience entry matches the derived resource URL.
        - Supports string or list forms per JWT spec.
        """
        if not self.server_url or not self.resource_url:
            return False
  
        aud: list[str] | str | None = token_data.get("aud")
        if isinstance(aud, list):
            return any(self._is_valid_resource(a) for a in aud)
        if isinstance(aud, str):
            return self._is_valid_resource(aud)
        return False
  
    def _is_valid_resource(self, resource: str) -> bool:
        """Check if the given resource matches our server."""
        return check_resource_allowed(self.resource_url, resource)
```


### 注意事項

`https://modelcontextprotocol.io/docs/tutorials/security/authorization#implementation-example` に従ってトークン内省用のクライアントを作成する他に、VSCodeが認証時にClient IDを入力するためのパブリッククライアントも作成する必要があります。また、このクライアントがVSCodeプラグインの要求に応じて、対応する `Valid Redirect URIs` を設定していることを確認してください。
![[Pasted image 20251223143640.png]]

![[Pasted image 20251223143802.png]]