## 构建DMN
![[Pasted image 20251110090222.png]]
![[Pasted image 20251110090248.png]]

决策表本身的标题分为两个部分;蓝色和绿色。蓝色部分是**输入表达式** ;绿色的**输出表达式** 。

在输入表达式中，您可以定义将在规则输入条目的表达式中使用的变量（如下所述）。可以通过选择 **“添加输入”**（右键单击选项菜单或单击加号图标）来定义多个输入表达式。

在输出表达式中，您可以定义将创建哪些变量来形成决策表执行的结果（变量的值将由输出条目表达式确定，如下所述）。可以通过选择**添加输出（** 右键单击选项菜单或单击加号图标）来定义多个输出表达式。

要输入表达式，请双击相应的单元格。在此示例中，输入表达式 _== BRONZE_。与相应输入表达式（列标题）中定义的变量相结合，这将在运行时产生完整的表达式 _customerCat == “BRONZE”_。

![[Pasted image 20251110090632.png]]

## 构建并发布App
![[Pasted image 20251110091259.png]]
![[Pasted image 20251110090955.png]]

![[Pasted image 20251110091329.png]]
![[Pasted image 20251110091411.png]]
![[Pasted image 20251110091430.png]]
![[Pasted image 20251110091504.png]]
## 使用DMN展示

![[Pasted image 20251106182726.png]]
![[Pasted image 20251106182742.png]]


![[Pasted image 20251106182756.png]]


![[Pasted image 20251106182815.png]]

![[Pasted image 20251106182833.png]]


![[Pasted image 20251106182910.png]]![[Pasted image 20251106182856.png]]


![[Pasted image 20251106182932.png]]




## Link

[DMN 1.1 Introduction · Flowable Open Source Documentation](https://www.flowable.com/open-source/docs/dmn/ch06-DMN-Introduction)