
# 1. 使用REST API 启动流程并传参
#### 发送POST请求，启动一个流程

![[Pasted image 20251105144258.png]]

body中填入流程启动流程时需要的变量，如下

```
{
  "processDefinitionKey": "testbpmn",
  "variables": [
    {
      "name": "start",
      "value": "chinese"
    }
  ],
  "returnVariables": true
}
```

其中 `processDefinitionKey` 的值就是创建流程时定义的，你可以用以下方法查看到

1、点击进入 “Admin App”
![[Pasted image 20251105144908.png]]

2、点击 “Process Engine” 下的 “Definitions”，即可看到所有定义的流程，找到你需要的流程点击即可查看其详细信息
![[Pasted image 20251105144950.png]]
3、这里展示了该流程的详细信息，包括 Key、ID、Name等
![[Pasted image 20251105145030.png]]

>[!note]
>注意这里的URL，是 `http://<your-flowable-host>:<port>/flowable-rest/service/runtime/process-instances`。尤其注意，不要把 `http` 错写成 `https`。

#### 响应
没有在headers中添加用户信息，在点击send后有弹窗提醒填写验证信息
![[Pasted image 20251110092118.png]]

响应结果如下

![[Pasted image 20251110092145.png]]

在flowable控制台中也能看到已经启动的流程
![[Pasted image 20251110092708.png]]
![[Pasted image 20251110092638.png]]
登录admin账户（因为在启动时我填入的是admin账户）可以看到，流程已经正常运行起来了。
![[Pasted image 20251110093935.png]]

# 2. 常见的api

详细可选参数等配置信息见网址：[REST API · Flowable Open Source Documentation](https://www.flowable.com/open-source/docs/bpmn/ch14-REST#general-flowable-rest-principles)

## 1.Deployment

### 1.GET Deployment List

获取所有部署的process app（PBMN app）
使用GET，`http://localhost:8081/flowable-rest/service/repository/deployments`

![[Pasted image 20251110100230.png]]

其中可以有一些查询参数，如：name, size, sort。详情见：(https://www.flowable.com/open-source/docs/bpmn/ch14-REST#list-of-deployments)
![[Pasted image 20251110101232.png]]

### 2.get a deployment

获取某一个部署的process app（PBMN app）的信息
使用GET，`http://localhost:8081/flowable-rest/service/repository/deployments/{deploymentId}`
![[Pasted image 20251110101632.png]]
### 3.List resources in a deployment

列出部署中的资源

使用GET，`http://localhost:8081/flowable-rest/service/repository/deployments/{deploymentId}/resources`

![[Pasted image 20251110102015.png]]

## 2.Process

### 1.List of process definitions

![[Pasted image 20251110102742.png]]

可以看到用REST API获取到的结果和在UI中控制台中看到的是一样的
![[Pasted image 20251110102845.png]]

## 3. create-a-new-deployment
创建新部署
POST 
`http://localhost:8081/flowable-rest/service/repository/deployments`
`http://localhost:8080/flowable-ui/process-api/repository/deployments`
![[Pasted image 20251110154122.png]]

![[Pasted image 20251110154353.png]]
## 4.start-a-process-instance

POST
`http://localhost:8080/flowable-ui/process-api/runtime/process-instances`
`http://localhost:8081/flowable-rest/service/runtime/process-instances`
![[Pasted image 20251110160318.png]]
## 5. list-of-tasks
任务列表
GET
`http://localhost:8080/flowable-ui/process-api/runtime/tasks`

![[Pasted image 20251110160624.png]]

任务查询（获取？）
POST
`http://localhost:8080/flowable-ui/process-api/query/tasks`

![[Pasted image 20251110162223.png]]
## 6. task-action

做任务

POST
`http://localhost:8080/flowable-ui/process-api/runtime/tasks/{taskId}`
![[Pasted image 20251110163528.png]]
![[Pasted image 20251110163632.png]]

![[Pasted image 20251110163842.png]]

![[Pasted image 20251110171333.png]]

- 首先尝试通过RestAPI的定义上传BPMN的定义以及部署BPMN，然后在Web画面中启动它
- 之后再尝试通过RestAPI来启动BPMN的流程，再通过RestAPI来完成其中的UserTask
- 尝试在通过REST API启动process以及完成task时传递变量，并在response中或者在其他地方确认这些变量的情况