
# 1. 使用REST API 启动流程并传参
发送POST请求，启动一个流程

![[Pasted image 20251105144258.png]]

```
{
  "processDefinitionKey": "testbpmn",
  "variables": [
    {
      "name": "start",
      "value": "chinese"
    }
  ],
  "returnVariables": true
}
```

其中 `processDefinitionKey` 的值就是创建流程时定义的，你可以用以下方法查看到

1、点击进入 “Admin App”
![[Pasted image 20251105144908.png]]

2、点击 “Process Engine” 下的 “Definitions”，即可看到所有定义的流程，找到你需要的流程点击即可查看其详细信息
![[Pasted image 20251105144950.png]]
3、这里展示了该流程的详细信息，包括 Key、ID、Name等
![[Pasted image 20251105145030.png]]

>[!note]
>注意这里的URL，是 `http://<your-flowable-host>:<port>/flowable-rest/service/runtime/process-instances`。尤其注意，不要把 `http` 错写成 `https`。