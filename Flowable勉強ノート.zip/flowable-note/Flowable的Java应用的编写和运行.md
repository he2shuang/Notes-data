### 创建流程引擎

我们现在有一个空的 Maven 项目，我们将向其添加两个依赖项：
- Flowable 流程引擎，它将允许我们创建一个 ProcessEngine 对象并访问 Flowable API。
- 内存数据库，在本例中为 H2，因为 Flowable 引擎需要一个数据库来存储运行流程实例时的执行和历史数据。请注意，H2 依赖项包括数据库和驱动程序。如果您使用其他数据库（例如 PostgresQL、MySQL 等），则需要添加特定的数据库驱动程序依赖项。

```
<dependencies>
  <dependency>
    <groupId>org.flowable</groupId>
    <artifactId>flowable-engine</artifactId>
    <version>7.0.0</version>
  </dependency>
  <dependency>
    <groupId>com.h2database</groupId>
    <artifactId>h2</artifactId>
    <version>2.1.214</version>
  </dependency>
</dependencies>
```

我们需要做的第一件事是实例化一个 **ProcessEngine** 实例。这是一个线程安全对象，通常只需在应用程序中实例化一次。_ProcessEngine_ 是从 **ProcessEngineConfiguration** 实例创建的，它允许您配置和调整流程引擎的设置。通常，_ProcessEngineConfiguration_ 是使用配置 XML 文件创建的，但（就像我们在这里所做的那样）您也可以以编程方式创建它。_ProcessEngineConfiguration_ 所需的最低配置是与数据库的 JDBC 连接：

```java
package org.flowable;
  
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngineConfiguration;
import org.flowable.engine.impl.cfg.StandaloneProcessEngineConfiguration;
  
public class HolidayRequest {
  
	public static void main(String[] args) {
		ProcessEngineConfiguration cfg = new StandaloneProcessEngineConfiguration()
			.setJdbcUrl("jdbc:h2:mem:flowable;DB_CLOSE_DELAY=-1")
			.setJdbcUsername("sa")
			.setJdbcPassword("")
			.setJdbcDriver("org.h2.Driver")
			.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);
  
		ProcessEngine processEngine = cfg.buildProcessEngine();
	}
}
```

在上面的代码中，在第 10 行上，创建了一个独立的配置对象。这里的 _“独立”_ 是指引擎完全由自身创建和使用的事实（例如，在 Spring 环境中，您会使用 _SpringProcessEngineConfiguration_ 类）。在第 11 行到第 14 行，将 JDBC 连接参数传递到内存中 H2 数据库实例。重要提示： 请注意，此类数据库在 JVM 重新启动后无法幸存。如果您希望数据持久化，则需要切换到持久化数据库并相应地切换连接参数。在第 15 行，我们将一个标志设置为 _true_，以确保如果数据库模式在 JDBC 参数指向的数据库中尚不存在，则会创建数据库模式。或者，Flowable 附带了一组 SQL 文件，可用于手动创建包含所有表的数据库模式。

然后使用此配置创建 **ProcessEngine** 对象（第 17 行）。

您现在可以运行它。在 Eclipse 中，最简单的方法是右键单击类文件并选择 _Run As → Java 应用程序_ ：

应用程序运行没有问题，但是，控制台中没有显示任何有用的信息，除了一条消息指出日志记录未正确配置：

![[Pasted image 20251111142652.png]]

Flowable 在内部使用 [SLF4J](http://www.slf4j.org/) 作为其日志记录框架。对于此示例，我们将在 SLF4j 上使用 log4j 记录器，因此将以下依赖项添加到 pom.xml 文件中：
```
<dependency> 
  <groupId>org.slf4j</groupId> 
  <artifactId>slf4j-api</artifactId> 
  <version>2.0.7</version> 
</dependency> 
<dependency> 
  <groupId>org.slf4j</groupId> 
  <artifactId>slf4j-log4j12</artifactId> 
  <version>2.0.7</version> 
</dependency>
```
Log4j 需要一个属性文件进行配置。将 _log4j.properties_ 文件添加到 _src/main/resources_ 文件夹，内容如下：

```
log4j.rootLogger=DEBUG, CA 

log4j.appender.CA=org.apache.log4j.ConsoleAppender
log4j.appender.CA.layout=org.apache.log4j.PatternLayout
log4j.appender.CA.layout.ConversionPattern= %d{hh:mm:ss,SSS} [%t] %-5p %c %x - %m%n
```

重新运行应用程序。现在，您应该会看到有关引擎启动和在数据库中创建的数据库架构的信息日志记录：

![[Pasted image 20251111143340.png]]

我们现在已经启动了一个流程引擎并准备就绪。是时候给它喂一个过程了！

### 部署流程定义

我们将构建的流程是一个非常简单的假期申请流程。Flowable 引擎期望流程以 BPMN 2.0 格式定义，这是业界广泛接受的 XML 标准。在可流动术语中，我们将其称为**过程定义** 。从 _流程定义_ 中，可以启动许多**流程实例** 。将 _流程定义_ 视为流程的许多执行的蓝图。在这种特殊情况下， _流程定义_ 定义了请求假期所涉及的不同步骤，而一个 _流程实例_ 匹配一个特定员工的假期请求。

BPMN 2.0 存储为 XML，但它也有一个可视化部分：它以标准方式定义了如何表示每种不同的步骤类型（人工任务、自动服务调用等）以及如何将这些不同的步骤相互连接。通过这种方式，BPMN 2.0 标准允许技术人员和业务人员以双方都能理解的方式就业务流程进行沟通。

我们将使用的流程定义如下：
![[Pasted image 20251111143457.png]]
这个过程应该是不言自明的，但为了清楚起见，让我们描述一下不同的部分：
- 我们假设该过程是通过提供一些信息开始的，例如员工姓名、请求的假期和描述。当然，这可以建模为该过程中单独的第一步。但是，通过将其作为流程的“输入数据”，只有在发出实际请求时才会实际创建流程实例。在另一种情况下，用户可以在提交之前改变主意并取消，但流程实例现在将在那里。在某些情况下，这可能是有价值的信息（例如，请求启动但未完成的次数），具体取决于业务目标。
- 左边的圆圈称为**开始事件** 。它是流程实例的起点。
- 第一个矩形是**用户任务** 。这是人类用户必须执行的过程中的一个步骤。在这种情况下，经理需要批准或拒绝请求。
- 根据经理的决定， **排他网关** （带有十字的菱形）会将流程实例路由到批准或拒绝路径。
- 如果获得批准，我们必须在某个外部系统中注册请求，然后再次为原始员工执行用户任务，通知他们该决定。当然，这可以用电子邮件代替。
- 如果被拒绝，将向员工发送一封电子邮件，通知他们这一点。

通常，此类_流程定义_是使用可视化建模工具进行建模的，例如 Flowable Designer （Eclipse） 或 Flowable Modeler （Web 应用程序）。但是，在这里，我们将直接编写 XML 以熟悉 BPMN 2.0 及其概念。

与上图对应的 BPMN 2.0 XML 如下所示。请注意，这只是“过程部分”。如果您使用了图形建模工具，则底层 XML 文件还包含描述图形信息的“可视化”部分，例如流程定义的各个元素的坐标（所有图形信息都包含在 XML 中的 _BPMNDiagram_ 标记中，它是 _definitions_ 标记的子元素）。

将以下 XML 保存在 _src/main/resources_ 文件夹中名为 _holiday-request.bpmn20.xml_ 的文件中。
![[Pasted image 20251111144337.png]]
第 2 行到第 11 行看起来有点令人生畏，但它与您在几乎每个流程定义中看到的相同。这是一种 _样板_ 内容，需要与 BPMN 2.0 标准规范完全兼容。

每个步骤（在 BPMN 2.0 术语中，**“activity”）** 都有一个 _id_ 属性，该属性在 XML 文件中为其提供唯一标识符。当然，所有 _活动_ 也可以有一个可选的名称，这增加了可视化图表的可读性。

_这些活动_ 通过序列流连接， **序列流**是可视化图中的一个有向箭头。执行流程实例时，执行将按照 _序列流_ 从 _开始事件_ 流向下一个 _活动_  。


离开 _排他网关_ 的 _序列流_  显然是特殊的：两者都有一个以 _表达式_ 形式定义的 _条件_  （参见第 25 行和第 32 行）。当流程实例执行到达此 _网关_ 时，将评估 _条件_ ，并采用第一个解析为 _true_ 的条件。这就是这里的独家代表：只选择一个。当然，如果需要不同的路由行为，其他类型的网关也是可能的。

此处写为 _表达式_ 的条件形式为  _${approved}_ ， 它是 _${approved == true}_ 的简写。变量“approved”称为**过程变量** 。 _进程变量_ 是与进程实例一起存储的持久性数据位，可以在进程实例的生存期内使用。在这种情况下，这确实意味着我们必须在流程实例中的某个点（当管理器用户任务提交时，或者用 Flowable 术语来说， _完成_ 时）设置此 _流程变量_ ，因为它不是流程实例启动时可用的数据。

现在我们有了流程 BPMN 2.0 XML 文件，接下来我们需要将其 **“部署”** 到引擎中。部署流程定义意味着 ：
- 流程引擎会将 XML 文件存储在数据库中，以便可以在需要时检索它
- 流程定义被解析为内部可执行对象模型，以便可以从中启动 _流程实例_ 

要将流程定义 _部署_ 到 Flowable 引擎，请使用 _RepositoryService_，它可以从 _ProcessEngine_ 对象中检索。使用 _RepositoryService_，通过传递 XML 文件的位置并调用 _deploy（）_ 方法来实际执行它，从而创建一个新的 _Deployment_：
```
RepositoryService repositoryService = processEngine.getRepositoryService(); 
Deployment deployment = repositoryService.createDeployment()
	.addClasspathResource("holiday-request.bpmn20.xml")
	.deploy();
```
我们现在可以通过 API 查询来验证引擎是否知道流程定义（并了解一些关于 API 的信息）。这是通过 _RepositoryService_ 创建新的 _ProcessDefinitionQuery_ 对象来完成的。
```
ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
	.deploymentId(deployment.getId()) 
	.singleResult(); 
System.out.println("Found process definition : " + processDefinition.getName());
```

### 启动流程实例
我们现在已将流程定义_部署_到流程引擎，因此可以使用此_流程定义_作为“蓝图”来启动_流程实例_ 。

要启动流程实例，我们需要提供一些初始_流程变量_ 。通常，您将通过向用户显示的表单或在进程由某些自动触发时通过 REST API 获取这些信息。在此示例中，我们将保持简单，并使用 java.util.Scanner 类在命令行上简单地输入一些数据：

```
Scanner scanner= new Scanner(System.in); 

System.out.println("Who are you?"); 
String employee = scanner.nextLine(); 

System.out.println("How many holidays do you want to request?"); 
Integer nrOfHolidays = Integer.valueOf(scanner.nextLine()); 

System.out.println("Why do you need them?"); 
String description = scanner.nextLine();
```

接下来，我们可以通过 _RuntimeService_ 启动一个_进程实例_ 。收集的数据作为 _java.util.Map_ 实例传递，其中键是稍后将用于检索变量的标识符。进程实例使用_密钥_启动。此_键_与 BPMN 2.0 XML 文件中设置的 _id_ 属性匹配，在本例中为 _holidayRequest_。
（注意：除了使用 key 之外，您稍后还将学习启动流程实例的方法很多）
```
<process id="holidayRequest" name="Holiday Request" isExecutable="true"> 

RuntimeService runtimeService = processEngine.getRuntimeService(); 

Map<String, Object> variables = new HashMap<String, Object>(); 
variables.put("employee", employee); 
variables.put("nrOfHolidays", nrOfHolidays); 
variables.put("description", description); 
ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("holidayRequest", variables);
```

启动流程实例时，将创建一个**执行**并将其放入启动事件中。从那里，此_执行_遵循序列流到用户任务以供经理批准，并执行用户任务行为。此行为将在数据库中创建一个任务，稍后可以使用查询找到该任务。用户任务处于_等待状态_ ，引擎将停止执行任何进一步的作，并返回 API 调用。

### Sidetrack：事务性

在 Flowable 中，数据库事务在保证数据一致性和解决并发问题方面发挥着至关重要的作用。当您进行 Flowable API 调用时，默认情况下，所有内容都是同步的，并且是同一事务的一部分。这意味着，当方法调用返回时，将启动并提交事务。

当一个进程实例启动时，从进程实例开始到下一个 _等待状态_  ，将有一个**数据库事务** 。在此示例中，这是第一个用户任务。当引擎到达此用户任务时，状态将持久化到数据库，并提交事务并返回 API 调用。

在 Flowable 中，当继续一个进程实例时，总会有一个数据库事务从上一个 _等待状态_ 进入下一个 _等待状态_ 。一旦持久化，数据可以在数据库中保留很长时间，如果必须保留，甚至可以在数据库中保存数年，直到执行 API 调用以进一步执行流程实例。请注意，当进程实例处于等待状态，等待下一个 API 调用时，不会消耗任何计算或内存资源。

在此示例中，当第一个用户任务完成时，将使用一个数据库事务从用户任务通过独占网关（自动逻辑）直到第二个用户任务。或者用另一条路直接走到尽头。

### 查询和完成任务

在更现实的应用程序中，将有一个用户界面，员工和经理可以在其中登录并查看他们的任务列表。有了这些，他们可以检查存储为_流程变量_的流程实例数据，并决定他们想要对任务执行什么作。在此示例中，我们将通过执行 API 调用来模拟任务列表，这些调用通常位于驱动 UI 的服务调用后面。

我们尚未为用户任务配置分配。我们希望第一个任务进入“经理”组，第二个用户任务分配给假期的原始请求者。为此，请将 _candidateGroups_ 属性添加到第一个任务：

```
<userTask id="approveTask" name="Approve or reject request" flowable:candidateGroups="managers"/>
```

以及第二个任务的 _assignee_ 属性，如下所示。请注意，我们使用的不是像上面的 'managers' 值那样的静态值，而是基于流程实例启动时传递的流程变量的动态赋值：

```
<userTask id="holidayApprovedTask" name="Holiday approved" flowable:assignee="${employee}"/>
```

为了获得实际的任务列表，我们通过 _TaskService_ 创建一个 _TaskQuery_，并将查询配置为仅返回 'managers' 组的任务：

```
TaskService taskService = processEngine.getTaskService(); 
List<Task> tasks = taskService.createTaskQuery().taskCandidateGroup("managers").list();
System.out.println("You have " + tasks.size() + " tasks:"); 
for (int i=0; i<tasks.size(); i++) { 
	System.out.println((i+1) + ") " + tasks.get(i).getName());
}
```

使用任务标识符，我们现在可以获取特定的流程实例变量，并在屏幕上显示实际请求：

```
System.out.println("Which task would you like to complete?"); 
int taskIndex = Integer.valueOf(scanner.nextLine()); 
Task task = tasks.get(taskIndex - 1); 
Map<String, Object> processVariables = taskService.getVariables(task.getId());
System.out.println(processVariables.get("employee") + " wants " + 
	processVariables.get("nrOfHolidays") + " of holidays. Do you approve this?");
```

如果您运行此作，则应如下所示：
![[Pasted image 20251111165603.png]]

经理现在可以**完成任务**了。实际上，这通常意味着表单是由用户提交的。然后，表单中的数据将作为_流程变量_传递。在这里，我们将通过在任务完成时传递带有“approved”变量的映射（名称很重要，因为它稍后在序列流的条件下使用！

```
boolean approved = scanner.nextLine().toLowerCase().equals("y"); 
variables = new HashMap<String, Object>(); 
variables.put("approved", approved); 
taskService.complete(task.getId(), variables);
```

任务现已完成，并且根据“已批准”进程变量选择离开独占网关的两条路径之一。

### 编写 JavaDelegate

还有最后一块拼图还缺失：我们还没有实现请求获得批准时将执行的自动逻辑。在 BPMN 2.0 XML 中，这是一个**服务任务** ，上面看起来像：

```
<serviceTask id="externalSystemCall" name="Enter holidays in external system" flowable:class="org.flowable.CallExternalSystemDelegate"/>
```

实际上，这种逻辑可以是任何东西，从使用 HTTP REST 调用服务，到对组织已经使用了几十年的系统执行一些遗留代码调用。我们不会在这里实现实际的逻辑，而只是记录_处理_ 。

创建一个新类（文件→ Eclipse 中的_新→类_ ），填写 _org.flowable_ 作为包名，_CallExternalSystemDelegate_ 作为类名。让该类实现 _org.flowable.engine.delegate.JavaDelegate_ 接口并实现 _execute_ 方法：

```
package org.flowable; 

import org.flowable.engine.delegate.DelegateExecution; 
import org.flowable.engine.delegate.JavaDelegate; 

public class CallExternalSystemDelegate implements JavaDelegate { 

	public void execute(DelegateExecution execution) { 
		System.out.println("Calling the external system for employee " + execution.getVariable("employee")); 
	} 
}
```

当_执行_到达_服务任务_时，将实例化并调用 BPMN 2.0 XML 中引用的类。

现在运行示例时，将显示日志记录消息，演示确实执行了自定义逻辑：
![[Pasted image 20251111165800.png]]
### 使用历史数据

选择使用 Flowable 等流程引擎的众多原因之一是因为它会自动存储所有流程实例的**审计数据**或**历史数据** 。这些数据允许创建丰富的报告，深入了解组织的运作方式、瓶颈在哪里等。

例如，假设我们想要显示到目前为止我们一直在执行的流程实例的持续时间。为此，我们从 _ProcessEngine_ 获取 _HistoryService_ 并为_历史活动_创建查询。在下面的代码片段中，您可以看到我们添加了一些额外的过滤：

- 仅一个特定流程实例的活动
- 仅已完成的活动

结果也按结束时间排序，这意味着我们将按执行顺序获取它们。

```
HistoryService historyService = processEngine.getHistoryService();
 List<HistoricActivityInstance> activities = historyService.createHistoricActivityInstanceQuery() .processInstanceId(processInstance.getId()) .finished() .orderByHistoricActivityInstanceEndTime().asc() .list(); 
 for (HistoricActivityInstance activity : activities) { 
	 System.out.println(activity.getActivityId() + " took " + activity.getDurationInMillis() + " milliseconds"); 
 }
```

再次运行示例，我们现在在控制台中看到类似如下内容：

```
startEvent took 1 milliseconds 
approveTask took 2638 milliseconds 
decision took 3 milliseconds 
externalSystemCall took 1 milliseconds
```

![[Pasted image 20251111155254.png]]
## Link

[Getting Started · Flowable Open Source Documentation](https://www.flowable.com/open-source/docs/bpmn/ch02-GettingStarted/#building-a-command-line-application)