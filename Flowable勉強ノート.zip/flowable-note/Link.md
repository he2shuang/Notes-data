**官方文档地址：** https://www.flowable.com/open-source/docs/

**Flowable在线教程：** https://www.flowable.com/open-source/docs/bpmn/ch02-GettingStarted/

**社区论坛：** https://forum.flowable.org/


[Hello World | Flowable Enterprise Documentation](https://documentation.flowable.com/latest/reactmodel/dmn/introduction/hello-world)