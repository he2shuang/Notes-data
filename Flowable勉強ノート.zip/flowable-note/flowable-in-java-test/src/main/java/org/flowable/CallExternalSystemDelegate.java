package org.flowable;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;

public class CallExternalSystemDelegate implements JavaDelegate {

	// 这是 JavaDelegate 接口唯一需要实现的方法。当流程执行到引用了这个类的服务任务时，Flowable 引擎会自动调用这个 execute 方法。
	public void execute(DelegateExecution execution) { 
		System.out.println("Calling the external system for employee " + execution.getVariable("employee")); 
	} 
}
