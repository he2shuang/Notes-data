package org.flowable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.flowable.engine.HistoryService;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngineConfiguration;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricActivityInstance;
import org.flowable.engine.impl.cfg.StandaloneProcessEngineConfiguration;
import org.flowable.engine.repository.Deployment;
import org.flowable.engine.repository.ProcessDefinition;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;

public class HolidayRequest {

	public static void main(String[] args) {
		
// 第一部分：初始化流程引擎
		
		// 创建一个独立的流程引擎配置对象。设置数据库连接 URL、用户名、密码、驱动程序类名和表结构更新策略。
		ProcessEngineConfiguration cfg = new StandaloneProcessEngineConfiguration()
				.setJdbcUrl("jdbc:h2:mem:flowable;DB_CLOSE_DELAY=-1")
				.setJdbcUsername("sa")
				.setJdbcPassword("")
				.setJdbcDriver("org.h2.Driver")
				.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);

		// 根据上面所有的配置，Flowable 会连接数据库、创建表结构，并最终构建并返回一个 ProcessEngine 实例。
		// 这个 processEngine 对象是我们与流程引擎所有功能交互的总入口。
		ProcessEngine processEngine = cfg.buildProcessEngine();
		
		
// 第二部分：部署流程定义
		
		// 从流程引擎中获取 RepositoryService。这个服务专门负责管理静态的流程资源，比如流程定义文件（BPMN 文件）、表单定义等。
		RepositoryService repositoryService = processEngine.getRepositoryService(); 
		// 创建一个新的“部署”操作。部署是将流程模型发布到引擎中的过程。
		Deployment deployment = repositoryService.createDeployment()
				.addClasspathResource("holiday-request.bpmn20.xml")
				.deploy();
		
		
// 第三部分：查询流程定义
		
		// 创建一个查询，用于从“流程仓库”中查找流程定义 (ProcessDefinition)。只查找刚才那次部署所包含的流程定义。
		ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
				.deploymentId(deployment.getId()) 
				.singleResult(); 
		System.out.println("Found process definition : " + processDefinition.getName());
		
		
// 第四部分：收集用户输入以启动流程
		
		Scanner scanner= new Scanner(System.in); 

		System.out.println("Who are you?"); 
		String employee = scanner.nextLine(); 

		System.out.println("How many holidays do you want to request?"); 
		Integer nrOfHolidays = Integer.valueOf(scanner.nextLine()); 

		System.out.println("Why do you need them?"); 
		String description = scanner.nextLine();
		
		
// 第五部分：启动流程实例

		// 获取 RuntimeService。这个服务负责管理正在运行的流程实例和执行。你可以把它看作是“流程运行调度员”。
		RuntimeService runtimeService = processEngine.getRuntimeService(); 

		// 创建一个 Map 来存放流程变量 (Process Variables)。流程变量是流程实例在整个生命周期中携带的数据，可以在不同节点间传递和使用。
		Map<String, Object> variables = new HashMap<String, Object>(); 
		variables.put("employee", employee); 
		variables.put("nrOfHolidays", nrOfHolidays); 
		variables.put("description", description); 
		
		// 启动一个新的流程实例。
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("holidayRequest", variables);
		
		
// 第六部分：查询并处理任务
		
		// 获取 TaskService。这个服务专门用于处理人工任务 (User Task)，如查询、认领、完成任务等。
		TaskService taskService = processEngine.getTaskService(); 
		
		// 查询所有分配给 managers 候选组的待办任务。这模拟了经理登录系统后看到自己团队需要处理的任务列表。
		List<Task> tasks = taskService.createTaskQuery().taskCandidateGroup("managers").list(); 
		System.out.println("You have " + tasks.size() + " tasks:"); 
		for (int i=0; i<tasks.size(); i++) { 
			System.out.println((i+1) + ") " + tasks.get(i).getName());
		}
		
		// 与用户交互，让其选择要处理哪一个任务。
		System.out.println("Which task would you like to complete?"); 
		int taskIndex = Integer.valueOf(scanner.nextLine()); 
		Task task = tasks.get(taskIndex - 1); 
		
		// 获取指定任务关联的流程实例的所有流程变量。这样经理在审批时就能看到员工的请假申请详情。
		Map<String, Object> processVariables = taskService.getVariables(task.getId());
		System.out.println(processVariables.get("employee") + " wants " + 
			processVariables.get("nrOfHolidays") + " of holidays. Do you approve this?");
		
		// 模拟经理审批。程序获取用户的输入（'y' 表示同意），并创建一个新的 Map 来存放审批结果。
		boolean approved = scanner.nextLine().toLowerCase().equals("y"); 
		variables = new HashMap<String, Object>(); 
		variables.put("approved", approved); 
		
		//  完成任务。
		taskService.complete(task.getId(), variables);
		
		
// 第七部分：查询历史数据
		
		// 获取 HistoryService。这个服务用于查询所有已经完成的历史数据，比如已完成的流程实例、活动节点、任务等。
		HistoryService historyService = processEngine.getHistoryService();
		
		// 创建一个查询，用于查找历史活动实例 (HistoricActivityInstance)。流程中经过的每一个节点（开始事件、任务、网关等）都会留下一条历史活动记录。
		List<HistoricActivityInstance> activities = historyService.createHistoricActivityInstanceQuery() 
				.processInstanceId(processInstance.getId()) 
				.finished() 
				.orderByHistoricActivityInstanceEndTime().asc() 
				.list(); 
		
		// 遍历查询到的历史活动记录，并打印出每个活动节点的 ID（如 approveTask）以及它执行所花费的时间
		for (HistoricActivityInstance activity : activities) { 
			System.out.println(activity.getActivityId() + " took " + activity.getDurationInMillis() + " milliseconds"); 
		}
	}

}
