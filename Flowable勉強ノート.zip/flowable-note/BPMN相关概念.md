
## 1. BPMN 基础概念

#### **1. 什么是 BPMN？**

BPMN，全称 **Business Process Model and Notation**，即“业务流程建模与标注”，是用于描述业务流程的国际标准。它是一种可视化的语言，允许业务分析人员、技术开发人员以及管理层通过统一的图表直观表达业务流程逻辑。

BPMN 是 Flowable 的核心标准之一，支持复杂的流程建模，并允许用户以图形化的方式构建、执行和管理流程。

------

#### **2. BPMN 的核心元素**

BPMN 的模型由以下四种主要元素组成：

1. **事件（Events）**：
   - **起始事件**：流程的起点，标志流程从哪里开始。
   - **中间事件**：在流程中表示某些事件（如定时器、消息等）。
   - **结束事件**：标志流程的结束。
2. **活动（Activities）**：
   - **任务（Task）**：表示单个活动，如用户任务、服务任务、脚本任务等。
   - **子流程（Sub-Process）**：封装一组相关任务的流程模块。
3. **网关（Gateways）**：
   - 用于定义流程的分支和合并。
   - 常见类型：
     - **并行网关**：同时执行多个路径。
     - **条件网关**：根据条件决定下一步。
     - **排他网关**：多个分支中只能选择一个。
     - **事件网关**：基于事件触发流程路径。
4. **连接器（Connectors）**：
   - 用于连接流程中的不同元素。
   - **序列流**：定义活动之间的执行顺序。
   - **消息流**：定义不同参与者之间的信息传递。
   - **关联线**：表示附加信息或注释。

------

#### **3. BPMN 的优点**

1. **图形化表达**：
   - 使用直观的图表，易于业务人员和技术开发者理解。
2. **跨团队协作**：
   - BPMN 提供了统一的标准，能够让业务和技术团队用同一种语言沟通需求和实现。
3. **可执行性**：
   - 在 Flowable 中，BPMN 模型不仅仅是设计文档，还可以直接部署并运行。
4. **支持复杂业务逻辑**：
   - 通过条件网关、事件触发、子流程等特性，能够轻松应对复杂的业务流程。

------

#### **4. Flowable 中的 BPMN 应用**

1. **创建 BPMN 流程模型**：
   - 使用 **Flowable Modeler** 进行流程设计。
   - 通过拖拽图形组件（如任务、事件、网关等）快速构建流程。
2. **流程部署**：
   - 在 Flowable 引擎中部署 BPMN 文件（通常为 XML 格式）。
   - 部署后，流程可以被触发并运行。
3. **执行与监控**：
   - 使用 **Flowable Task** 管理流程实例。
   - 通过 **Flowable Admin** 监控流程的运行状态。

------

#### **5. 常见 BPMN 示例**

以下是一些常见的 BPMN 使用场景：

1. **审批流程**：
   - 起始事件触发，用户任务用于填写表单，条件网关根据审批结果决定下一步。
2. **订单处理**：
   - 并行网关分支出多个路径，例如检查库存、发送发票等，所有路径完成后合并到下一步。
3. **异常处理流程**：
   - 中间事件捕获异常（如服务调用失败），触发补偿逻辑。


## 2. 网关

#### 1.网关的分类

**排他网关（Exclusive Gateway, XOR）**

- **用途：** 实现流程的条件分支，只允许一条路径执行。
- 配置：
  - 添加一个排他网关。
  - 为每条输出路径设置条件表达式。
  - 条件示例：

    ```
    ${库存 > 0}  // 如果库存大于0
    ${库存 <= 0} // 如果库存小于等于0
    ```

  - 确保所有可能的分支都能覆盖条件，避免流程中断。

**并行网关（Parallel Gateway, AND）**

- **用途：** 同时执行多个路径。
- 配置：
  - 添加一个并行网关。
  - 从并行网关拖拽多条顺序流到目标任务。
  - 不需要条件表达式，所有路径都会被激活。
  - 示例场景：同时通知多个部门。

**包含网关（Inclusive Gateway, OR）**

- **用途：** 根据条件决定一个或多个路径可以被执行。

- 配置：
  - 添加一个包含网关。
  - 为每条输出路径设置条件表达式。
  - 示例条件：

    ```
    ${订单金额 > 1000} // 金额大于1000的订单
    ${紧急标记 == true} // 如果标记为紧急
    ```

  - 包含网关会评估所有条件，选择满足条件的所有路径。

**事件网关（Event-based Gateway）**

- **用途：** 等待特定事件后再决定流程流向。
- 配置：
  - 添加一个事件网关。
  - 连接到事件（如定时器事件、消息事件等）。
  - 流程将根据第一个发生的事件选择路径。
  - 示例场景：等待客户响应。

## 3. 常用task
###  User Task

**图标**：左上角有一个小人图标。  
**描述**：这是最核心、最常用的任务类型。当流程执行到 User Task 时，会暂停执行，并在数据库中创建一个任务实例，等待一个或多个人工用户来“认领”（Claim）并“完成”（Complete）这个任务。  
**核心配置**：

- **办理人 (Assignee)**：直接指定该任务由谁来处理。例如 `flowable:assignee="zhangsan"`。
- **候选人 (Candidate Users)**：指定多个可以处理该任务的候选人。例如 `flowable:candidateUsers="lisi,wangwu"`。
- **候选组 (Candidate Groups)**：指定一个或多个角色/用户组可以处理该任务。例如 `flowable:candidateGroups="managers,hr"`。
- **表单 (Form Key)**：关联一个表单，用于用户在处理任务时查看和提交数据。

**使用场景**：

- 请假流程中的“经理审批”。
- 报销流程中的“财务审核”。
- 订单流程中的“客服确认订单”。

**XML 示例**：

```
<userTask id="approveTask" 
          name="经理审批" 
          flowable:assignee="${managerId}">
  <documentation>请经理审批请假申请。</documentation>
</userTask>
```

在这个例子中，`flowable:assignee="${managerId}"` 表示任务的办理人是一个名为 `managerId` 的流程变量。

### http task

**图标**: 左上角有一个地球/网络图标。

**HTTP 任务** 是一个自动化的系统任务，它允许你在流程中直接、声明式地调用一个外部的 HTTP/HTTPS 服务（通常是 REST API），而**无需编写任何 Java 代码**。

当流程执行到 HTTP 任务时，Flowable 引擎会：

1. 构造一个 HTTP 请求（包括 URL、方法、请求头、请求体）。
2. 发送这个请求到指定的外部服务。
3. 等待并接收外部服务的响应。
4. 将响应结果（状态码、响应头、响应体）保存到一个流程变量中。
5. 然后自动流转到下一个节点。

它与 **服务任务 (Service Task)** 的主要区别在于：

- **HTTP 任务**: **配置驱动**。你只需要在 Flowable Modeler 的属性面板上填写参数，引擎会帮你处理所有 HTTP 客户端的细节。
- **服务任务**: **代码驱动**。你需要编写一个实现了 `JavaDelegate` 接口的 Java 类来处理 HTTP 请求，灵活性更高，但工作量也更大。


**HTTP 任务** 是实现流程与外部世界（特别是微服务）集成的强大而便捷的工具。

**何时使用 HTTP 任务？**

- 当你需要调用的 API 比较简单、直接。
- 认证方式是简单的 Header 或 Basic Auth。
- 你不想为此编写和维护 Java 代码，希望通过可视化配置快速实现。

**何时考虑使用 Service Task (JavaDelegate) 代替？**

- 需要复杂的认证逻辑，如 OAuth2 token 的获取和刷新。
- 在发送请求前或接收响应后，需要进行复杂的数据转换或处理。
- 需要实现复杂的重试、熔断、降级等错误处理逻辑。
- API 调用本身是公司内部一个需要复用的通用能力。

通过合理选择和使用 HTTP 任务，你可以极大地提高流程开发的效率和灵活性。

 **配置核心属性**

选中这个 HTTP 任务，右侧的属性面板会出现专门用于 HTTP 配置的区域。

1. **Request method (请求方法)**
    - 选择 `POST`，与我们的 API 要求一致。
2. **Request URL (请求 URL)**
    - 填入 `https://api.creditservice.com/v1/score`。
3. **Request headers (请求头)**
    - API 调用通常需要指定内容类型。点击 "New" 添加一个头：
        - **Name**: `Content-Type`
        - **Value**: `application/json`
    - 如果 API 需要认证（如 Bearer Token），也可以在这里添加 `Authorization` 头。
4. **Request body (请求体)**
    - 这里是关键，我们需要将流程变量动态地填入请求体。假设在流程启动时，我们已经有了一个名为 `applicantId` 的流程变量。
    - 在文本框中输入以下内容，使用 `${...}` 语法来引用流程变量：
        ```
        {
          "applicantId": "${applicantId}"
        }
        ```

    - Flowable 在执行时会自动将 `${applicantId}` 替换为当前流程实例中该变量的实际值。
5. **Result variable name (结果变量名)**
    - 这是最重要的配置之一！它指定了 Flowable 将把 HTTP 响应存储在哪一个流程变量中。
    - 我们填入 `creditScoreResponse`。

**配置其他可选属性 (高级)**

- **Response timeout (响应超时)**: 设置等待外部 API 响应的最长时间，例如 `PT30S` (30秒)。
- **Ignore exception (忽略异常)**: 如果勾选，当 HTTP 请求失败时（如 4xx/5xx 错误、超时），流程不会抛出异常并停止，而是会继续。
- **Save request variables (保存请求变量)**: 如果勾选，Flowable 会将最终发出的请求（URL、Headers、Body）也保存到变量中，便于调试。
- **Save response as transient variable (将响应保存为瞬时变量)**: 如果勾选，响应变量不会被持久化到历史数据库中。
- **Save response variables prefix (响应变量前缀)**: 如果不使用 `Result variable name`，可以设置一个前缀，Flowable 会将响应的 `statusCode`, `headers`, `body` 分别存为 `prefix_statusCode`, `prefix_headers`, `prefix_body`。**推荐使用 `Result variable name`**，因为它更整洁。

xml 示例：
```
<httpTask id="callCreditService" name="调用征信服务">
  <extensionElements>
    <flowable:field name="method">
      <flowable:string><![CDATA[POST]]></flowable:string>
    </flowable:field>
    <flowable:field name="url">
      <flowable:string><![CDATA[https://api.creditservice.com/v1/score]]></flowable:string>
    </flowable:field>
    <flowable:field name="headers">
      <flowable:string><![CDATA[Content-Type: application/json]]></flowable:string>
    </flowable:field>
    <flowable:field name="requestBody">
      <flowable:string>
        <![CDATA[{ "applicantId": "${applicantId}" }]]>
      </flowable:string>
    </flowable:field>
    <flowable:field name="resultVariable">
      <flowable:string><![CDATA[creditScoreResponse]]></flowable:string>
    </flowable:field>
    <flowable:field name="responseTimeout">
      <flowable:string><![CDATA[PT30S]]></flowable:string>
    </flowable:field>
  </extensionElements>
</httpTask>
```

### service task

**图标**：左上角有几个齿轮图标。  
**描述**：用于执行自动化的逻辑，通常是调用一段 Java 代码、执行一个表达式或调用外部服务。当流程执行到 Service Task 时，它会自动、同步地执行所配置的逻辑，然后立即流转到下一个节点。  
**核心配置 (实现方式)**：

- **Java 类 (Class)**：执行一个实现了 `JavaDelegate` 或 `ActivityBehavior` 接口的 Java 类。
- `flowable:class="com.example.MyJavaDelegate"`
- **表达式 (Expression)**：调用一个 Spring Bean 的方法或执行一个 JUEL 表达式。
- `flowable:expression="${myBean.myMethod(execution)}"`
- **委托表达式 (Delegate Expression)**：与表达式类似，但它引用的 Spring Bean 必须实现 `JavaDelegate` 接口。
- `flowable:delegateExpression="${myDelegateBean}"`
- **类型 (Type)**：Flowable 内置的一些特殊服务任务，如 `mail` (发送邮件), `shell` (执行 shell 命令) 等。

**使用场景**：

- 审批通过后，自动调用外部 API 更新系统状态。
- 根据表单数据，自动计算费用并存入流程变量。
- 流程结束后，自动发送一封通知邮件。

**xml示例**：
```
<serviceTask id="updateStatusTask" 
             name="更新订单状态" 
             flowable:class="com.mycompany.flowable.UpdateOrderStatusDelegate">
</serviceTask>
```
### script task

**图标**：左上角有一个卷轴/纸张图标。  
**描述**：用于在流程中直接执行一小段脚本。Flowable 支持多种脚本语言，如 Groovy（默认）、JavaScript 等。它适用于那些逻辑比较简单，不值得专门创建一个 Java 类的场景。  
**核心配置**：

- **脚本格式 (Script Format)**：指定脚本的语言，如 `groovy`。
- **脚本内容**：在 `<script>` 标签内编写具体的脚本代码。

**使用场景**：

- 对流程变量进行简单的格式化或转换。
- 基于已有变量，通过简单计算生成新的流程变量。
- 在日志中打印调试信息。

**xml 示例**：
```
<scriptTask id="calculateTotal" 
            name="计算总价" 
            scriptFormat="groovy">
  <script>
    // 从流程变量中获取单价和数量
    def price = execution.getVariable("price")
    def quantity = execution.getVariable("quantity")
    
    // 计算总价并设置到新的流程变量中
    def total = price * quantity
    execution.setVariable("totalPrice", total)
  </script>
</scriptTask>
```