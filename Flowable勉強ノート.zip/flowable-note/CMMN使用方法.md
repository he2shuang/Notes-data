## 构建CMMN图

构建一个简单的案例模型，构建的案例模型是一个简化的_员工入职_案例，有两个阶段：潜在员工入职前的阶段和之后的阶段。在第一阶段，人力资源部门的人员将完成任务，而在第二阶段，则由员工完成任务。此外，在任何时间点，潜在员工都可以拒绝工作并停止整个案例实例。请注意，仅使用阶段和人工任务。在真实案例模型中，很可能还会有其他计划项类型，例如里程碑、嵌套阶段、自动化任务等。

![[Pasted image 20251105165217.png]]

![[Pasted image 20251105165238.png]]


![[Pasted image 20251105165327.png]]
## 构建并发布App

![[Pasted image 20251105165434.png]]

![[Pasted image 20251105165510.png]]
![[Pasted image 20251105165535.png]]
![[Pasted image 20251105165555.png]]
![[Pasted image 20251105165628.png]]
![[Pasted image 20251105165653.png]]

## 使用CMMN展示

0、开始一个case

![[Pasted image 20251105164644.png]]

![[Pasted image 20251105164705.png]]

![[Pasted image 20251105164722.png]]


1、正常流程

![[Pasted image 20251105164741.png]]

![[Pasted image 20251105164805.png]]

![[Pasted image 20251105164836.png]]

![[Pasted image 20251105164854.png]]
![[Pasted image 20251105164909.png]]

![[Pasted image 20251105164929.png]]

![[Pasted image 20251105164957.png]]
![[Pasted image 20251105165026.png]]
![[Pasted image 20251105165058.png]]

2、展示随时拒绝
![[Pasted image 20251105164420.png]]

![[Pasted image 20251105164442.png]]

![[Pasted image 20251105164457.png]]![[Pasted image 20251105164517.png]]
## 带条件的sentries的例子

先如图所示创建好模板

![[Pasted image 20251105172428.png]]
之后，点击输入表单任务，关联一个表单：
![[Pasted image 20251105172437.png]]


在表单中添加一个复选框
![[Pasted image 20251105172451.png]]

**注：如果出现识别不到变量，可以给全局关联表**

之后，点击Entry criterion，设置条件：

```
${activatetaskb == true}
```

**然后，将trigger mode 设置为 on event。**
![[Pasted image 20251105172537.png]]

### trigger mode
触发模式(trigger mode)：这里有两个选项，事件延迟（Event deferred）或按事件触发（On event）。我们先从较简单的开始：**按事件触发**。每当连接器(即连接虚线)触发时（complete，start等），条件（如果有的话）会被评估，如果评估结果为真，条件就满足，计划项会被激活。如果没有连接器，条件会在其父项（例如阶段）激活时进行评估。如果使用了按事件触发的条件，请确保评估条件时，正是您希望在条件满足的时刻触发并激活计划项。如果此时条件评估结果为假，那么条件将永远无法满足！

如果这种行为不符合您的需求，您可能需要使用**事件延迟模式**，因为它会为条件提供“记忆”，即使条件尚未满足，它会等待直到满足条件后再激活计划项。或者，如果条件已经满足，但连接器尚未触发，这种情况也会被记住，因此在连接器触发时，计划项会被激活，即使此时条件已经不再为真！

完成之后对模板进行保存，启动流程后正常运行。

### 注：！！！

对于普通的activity而言， 触发Sentry 是用complete（完成任务）， 对于 event listener而言，应该用occur（事件发生）
## Link
[CMMN 1.1 · Flowable Open Source Documentation](https://www.flowable.com/open-source/docs/cmmn/ch06-cmmn)