## 构建流程图
点击“Modeler App”
![[Pasted image 20251105100501.png]]
在“Process”中点击“create Process”
![[Pasted image 20251105100527.png]]
填写名称等相关信息后点击“create new model”
![[Pasted image 20251105100608.png]]

在工作台中画出流程图
![[Pasted image 20251105100810.png]]

## 关联form表单
![[Pasted image 20251105101340.png]]
![[Pasted image 20251105101434.png]]
#### 设置form表单

![[Pasted image 20251105101510.png]]

![[Pasted image 20251105101844.png]]

![[Pasted image 20251105102043.png]]

![[Pasted image 20251105102120.png]]

![[Pasted image 20251105102221.png]]

![[Pasted image 20251105102237.png]]

![[Pasted image 20251105102650.png]]

![[Pasted image 20251105102722.png]]![[Pasted image 20251105103114.png]]


## 将任务分配给人员
![[Pasted image 20251105103632.png]]![[Pasted image 20251105103702.png]]

![[Pasted image 20251105103850.png]]
![[Pasted image 20251105103831.png]]
![[Pasted image 20251105103914.png]]

![[Pasted image 20251105104035.png]]
定义流条件
![[Pasted image 20251105104223.png]]![[Pasted image 20251105104243.png]]

![[Pasted image 20251105104448.png]]

## 创建并发布应用程序

![[Pasted image 20251105104528.png]]

![[Pasted image 20251105104600.png]]

![[Pasted image 20251105104619.png]]

![[Pasted image 20251105104644.png]]![[Pasted image 20251105104711.png]]

![[Pasted image 20251105104725.png]]

![[Pasted image 20251105104748.png]]
![[Pasted image 20251105104804.png]]

## 尝试使用这个新建的流程

![[Pasted image 20251105104846.png]]

![[Pasted image 20251105104912.png]]

![[Pasted image 20251105104937.png]]

![[Pasted image 20251105105007.png]]

![[Pasted image 20251105105043.png]]

![[Pasted image 20251105105111.png]]![[Pasted image 20251105105135.png]]

![[Pasted image 20251105105208.png]]

![[Pasted image 20251105105314.png]]

![[Pasted image 20251105105354.png]]


![[Pasted image 20251105105516.png]]

![[Pasted image 20251105105534.png]]![[Pasted image 20251105105553.png]]

![[Pasted image 20251105105624.png]]![[Pasted image 20251105105634.png]]

![[Pasted image 20251105105713.png]]

![[Pasted image 20251105105816.png]]
![[Pasted image 20251105110043.png]]

![[Pasted image 20251105105927.png]]

![[Pasted image 20251105105945.png]]


## link

[Instant Gratification with Flowable 6 | These are my principles](https://paulhh.wordpress.com/2017/01/31/flowable-6-instant-gratification/)