# 1. 拉取 zookeeper 镜像

使用命令 `docker pull zookeeper:3.8.6` 拉取镜像。

![[pull zookeeper image.png]]

由于官方源在国外，国内网络访问时速度慢、易超时，甚至被屏蔽。因此拉取镜像前需要换源，在 Docker 的设置中选择 Docker Engine，配置右侧的 json 区域，修改或添加：
```
"registry-mirrors": [
    "https://docker.1ms.run"
  ]
```

# 2. 启动 zookeeper 容器

使用命令 `docker run -d --name zookeeper -p 2181:2181 zookeeper:3.8.6` 启动容器。

![[run zookeeper container.png]]

# 3. 拉取 kafka 镜像

使用命令 `docker pull apache/kafka:4.2.0` 拉取镜像。

![[pull kafka image.png]]

# 4. 启动 kafka 容器

使用命令 `docker run -d --name kafka -p 9092:9092 apache/kafka:4.2.0` 启动容器。

![[run kafka container.png]]

# 5. 验证容器启动状态

使用命令 `docker ps` 查看容器启动状态。

![[verify container status.png]]

# 6. 进入 kafka 容器

使用命令 `docker exec -it kafka /bin/bash` 进入容器。

![[enter kafka container.png]]

# 7. 创建主题

使用命令 `/opt/kafka/bin/kafka-topics.sh --create --topic test --bootstrap-server localhost:9092` 创建一个名为 test 的主题。

![[create topic.png]]

# 8. 写入事件

使用命令 `/opt/kafka/bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic test` 在主题 test 中写入事件。

![[write some events into the topic.png]]

用 Ctrl + C 可退出命令行。

# 9. 读事件

打开另一个终端会话，使用命令 `/opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic test --from-beginning` 读事件。

![[read the events.png]]

用 Ctrl + C 可退出命令行。